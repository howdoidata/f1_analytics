# Championship Leader Follow-Up: Comebacks And Recovery Factors

## Data Sources

This follow-up uses the existing Kaggle-baseline curated DuckDB tables:

* `races`
* `results`
* `driver_standings_by_round`
* `constructor_standings_by_round`
* `final_driver_standings`
* `final_constructor_standings`

Jolpica/Ergast is loaded separately for current-season coverage comparison, but it is not merged into the Kaggle curated analysis in this report.

## Current Cutoff

The cutoff is the latest completed round available in local Kaggle `f1_results.csv`, not the latest Jolpica round and not the full scheduled calendar.

* Target season: 2026
* Cutoff round: 3
* Cutoff race: Japanese Grand Prix
* Cutoff race date: 2026-03-29
* Scheduled target-season races: 22
* Completed Kaggle result rounds: 3

## Current Conversion Answers

Driver championship leaders after round 3 became champion in 40 of 76 historical seasons, a 52.6% conversion rate.

Current 2026 driver leader at the cutoff:

| leader_name | leader_points | leader_wins |
| --- | --- | --- |
| Andrea Kimi Antonelli | 68.0 | 2 |

Constructor championship leaders after round 3 became champion in 38 of 68 historical seasons, a 55.9% conversion rate.

Current 2026 constructor leader at the cutoff:

| leader_name | leader_points | leader_wins |
| --- | --- | --- |
| Mercedes | 123.0 | 3 |

## Largest Constructor Comeback

The largest historical constructor points deficit overcome after round 3 was 49 points: 2022 Red Bull trailed the cutoff leader 104 to 55 and still won the constructors' championship.

Top historical constructor comeback cases at this same cutoff:

| season | champion_constructor | cutoff_points | cutoff_leader_points | points_deficit_overcome | cutoff_rank | final_points | final_wins |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 2022 | Red Bull | 55.0 | 104.0 | 49.0 | 3 | 759.0 | 17 |
| 2024 | McLaren | 55.0 | 97.0 | 42.0 | 3 | 666.0 | 6 |
| 2012 | Red Bull | 64.0 | 88.0 | 24.0 | 2 | 460.0 | 7 |
| 2003 | Ferrari | 16.0 | 39.0 | 23.0 | 3 | 158.0 | 8 |
| 1994 | Williams | 7.0 | 30.0 | 23.0 | 3 | 118.0 | 7 |
| 1964 | Ferrari | 6.0 | 29.0 | 23.0 | 4 | 45.0 | 3 |
| 1982 | Ferrari | 1.0 | 22.0 | 21.0 | 7 | 74.0 | 3 |
| 2010 | Red Bull | 61.0 | 76.0 | 15.0 | 3 | 498.0 | 9 |
| 1987 | Williams | 16.0 | 31.0 | 15.0 | 2 | 137.0 | 9 |
| 1958 | Vanwall | 9.0 | 23.0 | 14.0 | 4 | 48.0 | 6 |

## Candidate Recovery Features

These candidate features can help explain whether a points recovery is plausible or how it happened historically. They are definitions for future explanatory analysis or modeling, not a trained model.

| feature | plain_language_definition | current_status |
| --- | --- | --- |
| points deficit at cutoff | How many championship points the team trails the cutoff leader by. | Available from constructor_standings_by_round. |
| remaining races | Number of scheduled races after the cutoff round. | Available from races and the cutoff round. |
| remaining points available | Approximate maximum constructor points still available after the cutoff. | Requires rules-aware feature engineering for points systems and sprint seasons. |
| wins/podium trend after cutoff | Whether wins and podium-level finishes improve after the cutoff. | Wins are available from results; podium trend can be engineered from finishing position. |
| teammate contribution | How much the second car contributes to constructor points after the cutoff. | Available from results and constructor/team grouping. |
| qualifying position trend | Whether starting positions improve or decline over later rounds. | Available from qualifying for Kaggle-covered rounds; Jolpica can compare fresher current-season rounds. |
| reliability/DNF rate | How often cars fail to finish or lose classification after the cutoff. | Can be engineered from results status fields if exposed consistently in the source data. |
| pit stop loss or gain where available | Time or position impact from pit stops during remaining races. | Available only from Jolpica pit stop data currently loaded separately. |
| lap pace consistency where available | How stable and competitive lap times are across race stints. | Available only from Jolpica lap data currently loaded separately. |
| sprint availability where applicable | Whether sprint weekends remain after the cutoff. | Requires explicit sprint calendar and points-system handling. |
| circuit mix after cutoff | The types of circuits left after the cutoff, such as street, high-speed, or high-downforce tracks. | Requires track attribute enrichment beyond the current curated tables. |
| field concentration/points spread | How tightly points are clustered among top teams at the cutoff. | Available from constructor_standings_by_round. |

## Outputs

* `outputs/reports/championship_leader_conversion.md`
* `outputs/reports/championship_leader_followup.md`
* `outputs/tables/driver_leader_conversion.csv`
* `outputs/tables/constructor_leader_conversion.csv`
* `outputs/tables/current_season_leaders.csv`
* `outputs/tables/data_coverage_summary.csv`
* `outputs/tables/constructor_comeback_cases.csv`
* `outputs/tables/recovery_feature_candidates.csv`
* `outputs/figures/constructor_comeback_cases.html`

## Limitations

* The cutoff remains Kaggle-baseline round 3; Jolpica currently extends current-season coverage but is not merged into Kaggle curated tables.
* Constructor comeback calculations use historical seasons with constructor championship final standings and cutoff-round constructor standings.
* The points systems, sprint formats, and season lengths vary across eras, so raw point deficits are useful for narrative comparison but should be normalized before heavier modeling.
* Candidate recovery features describe analytical directions; several require additional feature engineering or source enrichment before they can be used in a model-ready table.
