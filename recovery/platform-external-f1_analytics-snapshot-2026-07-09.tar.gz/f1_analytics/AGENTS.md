# AGENTS.md

## Universal Project Rules

- The repo is the source of truth.
- Read `PROJECT.md` and `docs/active_context.md` before making project changes.
- Prefer simple, maintainable solutions.
- Do not create unnecessary abstractions.
- Record durable decisions in `docs/decisions.md`.
- Record commands and validation results in `docs/run_log.md`.
- Do not rely on chat history when repo context exists.