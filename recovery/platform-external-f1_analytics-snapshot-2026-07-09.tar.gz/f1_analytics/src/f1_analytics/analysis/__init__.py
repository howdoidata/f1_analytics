"""Reusable analysis routines."""

