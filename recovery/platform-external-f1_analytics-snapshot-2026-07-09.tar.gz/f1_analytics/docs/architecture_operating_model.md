# Architecture Operating Model

## Purpose

This document defines how architecture changes happen in this project. It turns architecture observations into explicit outcomes without adding a heavy governance process.

The operating question is:

Can this project keep changing safely, visibly, and intentionally while staying lightweight?

## Scope

This model covers architecture and administration for project assets, including documentation, data sources, scripts, reusable modules, SQL, generated outputs, handoffs, validation, and workflow controls.

It does not replace:

* `docs/terminal_protocol.md`
* `docs/terminal_roles/`
* `docs/decisions.md`
* `docs/questions.md`
* `docs/backlog.md`
* handoffs
* implementation notes

It explains how those existing artifacts work together.

## Roles

Planning terminal:

* Evaluates architecture, scope, tradeoffs, open questions, inbox items, backlog direction, and draft handoffs.
* Records durable decisions, questions, backlog items, and state updates when explicitly in scope.
* Does not implement approved handoffs.

Execution terminal:

* Implements approved handoffs only.
* Updates expected files, writes implementation notes, and records implementation outcomes.
* Does not revisit architecture decisions or expand scope.

Command terminal:

* Runs commands, installs, data pulls, and validation steps.
* Records validation results in `docs/run_log.md`.
* Does not make project design decisions.

## Principles Versus Source/Tool Decisions

The `docs/architecture_principles.md` principles document and `docs/decisions.md` serve different, non-overlapping purposes:

* architecture-level principles (`docs/architecture_principles.md`): reusable, source-name-generic, revised rarely. They should read the same regardless of which specific source, tool, or vendor is in use at the time.
* Project-specific source/tool decisions (`docs/decisions.md`, `docs/data_sources.md`): concrete, name specific vendors, sources, or tools, and are revised whenever sources or tools change.

If a principle needs a specific source or tool name to make sense, that is a sign the content belongs in a decision or topic doc instead, not in the source-name-generic principles document.

## Decision Flow

Use `docs/decisions.md` when a finding changes durable project policy, architecture, tool direction, data-source treatment, lifecycle rules, or governance behavior.

Decision entries must include:

* `Decision:`
* `Rationale:`
* `Tradeoffs:`
* `Status:`

Accepted decision bodies are frozen records. If a new decision replaces an accepted decision, use the supersede convention described in `docs/terminal_protocol.md`.

## Handoff Flow

Use handoffs when a change is specific enough for execution.

1. Planning creates or updates a draft handoff in `docs/handoffs/drafts/` only when explicitly instructed.
2. The user reviews and approves the draft.
3. Approved handoffs move to `docs/handoffs/approved/`.
4. Execution implements only the approved handoff.
5. Command validates with the handoff's validation commands.
6. Execution records implementation notes.
7. Project state is updated in the appropriate durable docs.

## Validation Flow

Validation is part of every meaningful change.

Required process validation:

* Run `python3 scripts/fitness_check.py` when a handoff or process change touches standing project structure.
* The fitness check records its own run in `docs/run_log.md`.

Other validation:

* Build, data pull, analysis, or report commands must be recorded manually in `docs/run_log.md`.
* Failed validation should produce a clear blocker, follow-up question, backlog item, or superseding handoff depending on the cause.

## Inbox Triage Flow

Raw inbox items under `docs/inbox/` must be triaged by planning before planning work proceeds.

Triage destinations:

* `docs/questions.md`
* `docs/decisions.md`
* draft handoff edits
* a new superseding handoff
* `data/raw/<source>/` for analytical datasets
* `docs/inbox/processed/` for retained reference material
* no-action or follow-up-needed landing notes

Execution and command terminals may use processed inbox material only when an approved handoff or validation instruction references it.

## Backlog Entry Rules

Use `docs/backlog.md` for concrete deferred work, risks, cleanup, validation gaps, documentation gaps, retirement candidates, and future enhancements.

Use backlog entries when:

* the item is real but not ready for execution.
* the item does not require an immediate decision.
* the item identifies a gap found during inventory or validation review.
* the item should be revisited during monthly or quarterly review.

Do not use backlog entries to replace decisions, questions, or handoffs.

## Architecture Finding Routing

Every architecture finding should land in one clear destination.

| Finding type | Destination |
|---|---|
| Durable policy, tool, source, or lifecycle choice | `docs/decisions.md` |
| Unresolved blocker or answer needed before action | `docs/questions.md` |
| Concrete deferred task, risk, cleanup, or validation gap | `docs/backlog.md` |
| Execution-ready implementation work | `docs/handoffs/drafts/` |
| Asset metadata correction | `docs/asset_inventory.md` |
| External retained reference | `docs/inbox/processed/` |
| Not worth action | No-action note in the relevant record |

## Asset Lifecycle

Use these lifecycle values in `docs/asset_inventory.md`:

* `Draft` - being explored or designed.
* `Active` - currently used and supported.
* `Deprecated` - still available but should not receive new investment.
* `Superseded` - replaced by another asset.
* `Retired` - no longer used.
* `Unknown` - discovered but not yet assessed.

Unknown is a valid audit finding. Do not hide it.

## Asset Disposition

Use these disposition values during inventory or architecture review:

* `Keep` - asset is aligned, used, owned, documented, and validated.
* `Improve` - asset has value but needs documentation, validation, ownership, or structure.
* `Merge` - asset overlaps with another asset and should be consolidated.
* `Deprecate` - asset remains temporarily available but should not be expanded.
* `Supersede` - asset should be replaced by a better governed asset.
* `Retire` - asset is unused, stale, risky, duplicated, or replaced.
* `Investigate` - asset requires more information before disposition.

Disposition findings should produce a decision, question, backlog item, handoff, inventory update, or no-action note.

## Review Cadence

Per-change review:

* Confirm the change has a purpose.
* Identify impacted assets.
* Identify validation commands.
* Update documentation and inventory where needed.
* Record decisions when policy, source treatment, tooling, or lifecycle behavior changes.

Monthly inventory/backlog review:

* Review new or changed assets.
* Review assets with `Unknown` values.
* Review validation gaps.
* Review deprecated, superseded, or stale assets.
* Convert findings into backlog items, questions, decisions, or handoffs.

Quarterly architecture direction review:

* Review tool fit for dbt, Airflow, dashboards, and ML.
* Review source boundaries and data freshness.
* Review whether manual controls should become automated fitness checks.
* Review whether a separate roadmap document is now justified.

## Operating Rule

Architecture review is only useful when it changes the project record. Observations should become decisions, questions, backlog items, handoffs, inventory updates, or explicit no-action notes.
