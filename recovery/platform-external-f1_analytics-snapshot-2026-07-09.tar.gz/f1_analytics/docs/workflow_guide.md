# Workflow Guide

Use this guide to choose a terminal by intent. The repo remains the source of
truth; this page routes work into the existing three-terminal workflow.
`docs/terminal_roles/*.md` are authoritative for exact responsibilities and
input requirements.

## Decision Tree

1. Are you deciding architecture, project scope, data models, tools, or
   tradeoffs?
   - Use the planning terminal for architecture and scope with
     `docs/prompts/planning/session_prompt.txt`.
   - Use `docs/architecture_principles.md`,
     `docs/architecture_operating_model.md`, and
     `docs/asset_inventory.md` to keep architecture guidance, change routing,
     and asset context consistent.
2. Are you asking a new analysis or feature question?
   - Use the planning terminal first for scoping and handoff drafting.
3. Are you providing external files, corrections, short specs, questions, or reference material?
   - Add them to `docs/inbox/` using the convention in `docs/inbox/README.md`.
   - If the target handoff is still a draft, the planning terminal can revise the draft directly.
   - If the target handoff is approved or completed, do not rewrite it; file the correction through the inbox so planning can create a superseding handoff when needed.
   - Execution and command terminals may use processed inbox material only when an approved handoff or validation instruction references it.
4. Are you implementing an approved handoff?
   - Use the execution terminal with `docs/prompts/execution_prompt.txt`.
5. Are you running commands, tests, installation, data pulls, or validation?
   - Use the command terminal for validation and command output with
     `docs/prompts/command_prompt.txt`.
6. Do you need to change an existing handoff?
   - Follow "Revising vs. superseding a handoff" in
     `docs/terminal_protocol.md`. Whether execution has started determines
     whether to revise or supersede.
7. Are you asking "what do I do now"?
   - Run `python3 scripts/workflow.py`. It reports process fitness, current
     focus, next action, pending handoffs, and the latest implementation note.

For a direct recommendation, run:

```bash
python3 scripts/workflow.py --intent architecture
python3 scripts/workflow.py --intent analysis
python3 scripts/workflow.py --intent execution
python3 scripts/workflow.py --intent command
python3 scripts/workflow.py --intent revise
```
