# Processed Inbox

Processed inbox items live here only after planning triage.

Each retained item must include a landing note that records where the durable conclusion landed and whether the material was retained, superseded, moved to data, closed with no action, or left for follow-up.
