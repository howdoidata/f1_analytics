Triaged Date: 2026-07-09
Triaged By: Planning terminal
Landing: Routed to `docs/questions.md` ("Project-agnostic platform scope") as an open scope question, and to `docs/backlog.md` (Architecture Governance) as a large, multi-phase future initiative pending that scope decision.
Retention: retained
Superseded By: N/A
Notes: Not yet a decision or handoff. Requires scope decisions (monorepo-vs-separate-repos, how to split mixed governance docs, whether fitness/workflow scripts become project-aware, and what the security/isolation boundary restricts) before any handoff can be drafted. Source item's own `Constraints:` field flags it as risky.

```markdown
Date: 2026-07-09
Intent: reference-material
Related: implementation_notes/015-generalize-architecture-principles.md, docs/terminal_protocol.md
Summary: Attached markdown describes a complete seperation of architecture and project
Requested Use: Command and Planning to use for context
Retention Guidance: Retain
Source/Origin: User-provided Markdown
Constraints: Will affect architecture and decision making, should be classified as risky and handled as such
```

**Goal** : Isolating project(s) from architecture, ability to use tools, processes, documenation, and assets across projects safely, securely, and with efficiency. Should hold safety, risk, and architecture as highest priorities. 


**Background** 
*This is a task that is similar to ideas in implementation_notes/015-generalize-architecture-principles.md but more encompassing*

The seperation between architecture and projects, building common use tools, workflows, and documentation (that works with AI) has been a challenge for quite awhile. The progress I have seen in this project has been some of the best I have seen yet from my own work. I want to understand what is needed to complete removal all "project-specific" related information from architecture. My goal is to be able to work multiple projects out of the environment, sharing operational and administrative assets like rules, guidelines, standards but holding specific information contained within its own project. It does not need to be full enterprise-level but more for scaling my work, each in completely different areas but using similar tools, processes and resources. 

A few things that should be seen:

0. Solidified plan for handling multiple projects, context, and absolutely zero drift or security framework to impose.  

1. All f1 and f1 related information/asets out of main folder and out of main folder items and into a project/f1_analytics folder (or something of that nature)
- with approved/016-combined-dataset-championship-leader-notebook.md still able to be re-run
- this includes historical information. I understand that this is more "rule-breaking" but not really when evaluated at the correct level (and is the overwhelming theme in the project). There needs to be migration methods for this kind of thing for these kinds of areas

2. A template for normalizing other projects and data to easily recreate or migrate into this architecture 



3. A simplified way to get there fast since we are in early stages of architecture. 



4. If I can provide locations to other projects or information/template I can have directories create to help understand what we are dealing with.
