# Inbox

`docs/inbox/` is a supplemental intake area for external files, corrections, short specs, questions, and reference material that need to influence planning or execution.

It is not a replacement for `docs/questions.md`, `docs/decisions.md`, handoffs, implementation notes, analytical data folders, or generated outputs. After triage, the durable conclusion must land in the correct existing project artifact.

## Supported Inputs

Use one of two shapes:

* Single Markdown intake note: `docs/inbox/YYYY-MM-DD-short-slug.md`
* File bundle: `docs/inbox/YYYY-MM-DD-short-slug/` with a `README.md` cover sheet plus attached files

Use a short lowercase slug with hyphens, for example `2026-07-09-handoff-correction.md` or `2026-07-09-reference-pdf/`.

## Cover Sheet

Every intake note or bundle `README.md` must include these required fields:

```markdown
Date:
Intent:
Summary:
Requested Use:
```

Allowed `Intent:` values:

* `correction`
* `new-context`
* `question`
* `data-spec`
* `reference-material`

Optional fields:

```markdown
Related:
Retention Guidance:
Source/Origin:
Constraints:
```

Field guidance:

* `Date:` when the user added the item.
* `Intent:` one allowed value from the list above.
* `Related:` optional link to a handoff, decision, question, implementation note, report, data source, or file path.
* `Summary:` what the file or context says in plain language.
* `Requested Use:` what the user wants the project to do with it.
* `Retention Guidance:` whether the source file should be retained for later reference, can be superseded after triage, or should move to a data/source location.
* `Source/Origin:` where the material came from.
* `Constraints:` usage limits, privacy notes, expiration, or assumptions.

## Examples

Correcting a draft handoff:

```markdown
Date: 2026-07-09
Intent: correction
Related: docs/handoffs/drafts/014-example.md
Summary: The draft assumes the wrong validation command.
Requested Use: Revise the draft handoff before approval.
Retention Guidance: superseded after the draft is corrected
```

Providing a PDF or reference file for planning:

```markdown
Date: 2026-07-09
Intent: reference-material
Related: docs/questions.md
Summary: Attached PDF describes a dashboard style the project may use later.
Requested Use: Planning should decide whether it affects future dashboard handoffs.
Retention Guidance: retain if useful for future reference
Source/Origin: User-provided PDF
Constraints: Use only for this project.
```

Providing a file needed by an approved execution handoff:

```markdown
Date: 2026-07-09
Intent: new-context
Related: docs/handoffs/approved/015-example.md
Summary: Attached CSV defines accepted field names for the approved task.
Requested Use: Execution may use this only if the approved handoff references the processed inbox item.
Retention Guidance: move-to-data if it is an analytical dataset; otherwise retain as processed reference
```

## Ownership And Access

Planning owns raw inbox triage. Before planning work begins, planning checks `docs/inbox/` for untriaged items and routes each item to the correct durable destination.

Execution and command terminals may use inbox material only after planning has triaged it and an approved handoff or validation instruction references the processed item.

## Triage Destinations

After triage, route the durable conclusion to one of:

* `docs/questions.md`
* `docs/decisions.md`, using supersession when the item contradicts an accepted decision
* direct edits to a draft handoff
* a new handoff that supersedes an approved or completed handoff
* `data/raw/<source>/` when the item is actually an analytical dataset
* `docs/inbox/processed/` as retained reference material when the source file should remain available

## Processed Landing Note

Every processed item retained under `docs/inbox/processed/` must include a landing note with:

```markdown
Triaged Date:
Triaged By:
Landing:
Retention:
Superseded By:
Notes:
```

Allowed `Retention:` values:

* `retained`
* `superseded`
* `moved-to-data`
* `no-action`
* `follow-up-needed`

Use `Superseded By:` when applicable. If it is not applicable, write `N/A`.
