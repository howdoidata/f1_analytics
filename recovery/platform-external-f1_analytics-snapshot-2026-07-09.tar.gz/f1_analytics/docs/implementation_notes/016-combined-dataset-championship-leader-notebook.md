# Implementation Note 016: Combined-Dataset Championship Leader Notebook

Handoff:
`docs/handoffs/approved/016-combined-dataset-championship-leader-notebook.md`, `Status: Approved` at the time of implementation.

## Summary

Built the scoped, precedence-ruled combined Kaggle+Jolpica dataset defined by the 2026-07-09 decision (`docs/decisions.md`) and used it to find the true current-season cutoff for the 2026 season: round 9, not the stale Kaggle-only round 3. Delivered the first notebook, `notebooks/championship_leader_combined_analysis.ipynb`, which states both cutoff answers side by side, shows both are different at both driver and constructor grain, shows current-season leaders at the combined cutoff, and shows the per-round Kaggle-vs-Jolpica deviation table for the current season. All primary analysis logic is imported from `src/f1_analytics/analysis/`; the notebook only calls reusable functions and formats output. The existing Kaggle-only report and its outputs are byte-for-byte unchanged (checksums verified before/after).

## Id-Convention Check Result

Per the handoff's "Open Decision To Resolve Before Execution": Jolpica's `driver_id`/`constructor_id` values were checked at the row level against Kaggle's `drivers.driver_id`/`constructors.constructor_id` for season 2026, rounds 4-9 (the live Jolpica-only gap at build time). **Result: ids matched directly** — all 22 distinct Jolpica driver ids and all 11 distinct Jolpica constructor ids in that range were already present in the Kaggle `drivers`/`constructors` tables. No reconciliation mapping was needed; proceeded per the first branch of the open decision.

## Combined Cutoff vs. Kaggle-Only Cutoff

* Kaggle-only cutoff: round 3 (Japanese Grand Prix, 2026-03-29) — unchanged from the existing reports.
* Combined cutoff: round 9 (the latest round Jolpica has real results for, as of this session).
* Driver leader-conversion answer: 40 of 76 historical seasons (52.6%) at the Kaggle-only cutoff vs. 50 of 69 historical seasons (72.5%) at the combined cutoff.
* Constructor leader-conversion answer: 38 of 68 historical seasons (55.9%) at the Kaggle-only cutoff vs. 51 of 67 historical seasons (76.1%) at the combined cutoff.
* Both the cutoff round and both conversion rates differ. The current-season leading driver (Andrea Kimi Antonelli) and constructor (Mercedes) are the same individuals at both cutoffs in this snapshot, but their points/wins totals and the historical seasons they are compared against differ, because round 9 excludes some short early F1 seasons that round 3 included and reflects a later, more-established point in the season.

## Deviation Rows Found (2026 Season)

`kaggle_jolpica_coverage` shows rounds 1-3 as `match` and rounds 4-9 as `jolpica_only` for the 2026 season. No `row_count_diverges` or `no_data` rows were found — every non-matching round is a genuine Kaggle gap that Jolpica cleanly fills, not a disagreement between the two sources.

## Files Changed

Refactor (shared logic, no output change):

* `src/f1_analytics/data_sources/kaggle_csv.py` — removed the local `add_standing_rank` definition and the duplicated groupby/cumsum blocks for driver/constructor round standings; both now call `compute_cumulative_standings` from the new shared module. Verified byte-identical output (see Commands Run).

Documentation:

* `docs/data_sources.md` — new "Combined Kaggle+Jolpica Dataset" section documenting the tables, precedence rule, scope, id-convention check result, and prerequisites.
* `docs/architecture.md` and `docs/diagrams/project_structure.mmd` — added the combined-dataset build step and the `notebooks/` directory to the layers description and diagram.
* `docs/questions.md` — updated the "Version 1 output format" answer to point at the completed (not draft) Handoff 016 and the delivered notebook.
* `docs/active_context.md` — updated repo-state summary, current focus, current decisions, generated-outputs list, and next action.
* `docs/run_log.md` — appended this session's commands and results.
* `requirements.txt` — added `jupyter` and `nbconvert`.

## Files Created

* `src/f1_analytics/data_sources/standings.py` — `add_standing_rank` and the new `compute_cumulative_standings` helper, factored out of `kaggle_csv.py` so the Kaggle-only and combined builders share one implementation instead of two.
* `src/f1_analytics/data_sources/combined_dataset.py` — builds `combined_results`, `combined_driver_standings_by_round`, and `combined_constructor_standings_by_round` under the precedence rule; requires and validates that Kaggle curated tables, `raw_jolpica_*` tables, and `kaggle_jolpica_coverage` already exist, erroring clearly if not.
* `src/f1_analytics/analysis/combined_championship_leaders.py` — `determine_cutoff_round` (works for both the Kaggle-only and combined standings tables), `build_combined_current_leaders`, `build_combined_conversion_tables` (reuses `build_conversion_table`, only parameterized by the combined cutoff round), and `extract_current_season_deviations` (reuses `kaggle_jolpica_coverage`, not a second view).
* `scripts/build_combined_dataset.py` — command-line wrapper around `build_combined_dataset()`.
* `notebooks/championship_leader_combined_analysis.ipynb` — the first notebook deliverable, committed with executed cell outputs.

## Commands Run

```bash
pwd
source .venv/bin/activate
pip install -r requirements.txt
python scripts/build_f1_dataset.py
python scripts/pull_jolpica_data.py
python scripts/build_combined_dataset.py
jupyter nbconvert --to notebook --execute --inplace notebooks/championship_leader_combined_analysis.ipynb
```

All passed. `python scripts/build_f1_dataset.py` reported `Validation checks: 11 run, 0 failed`, matching the pre-refactor baseline. `python scripts/build_combined_dataset.py` reported `combined_results: 26071 rows`, `combined_driver_standings_by_round: 25982 rows`, `combined_constructor_standings_by_round: 12839 rows`.

Regression check on the `kaggle_csv.py` refactor: MD5 checksums of `outputs/reports/championship_leader_conversion.md`, `outputs/reports/championship_leader_followup.md`, and all six `outputs/tables/*.csv` files were identical before and after the refactor (re-ran `scripts/analyze_championship_leaders.py`), confirming the existing Kaggle-only report and scripts are byte-for-byte unaffected.

Historical row-count check: `SELECT COUNT(*) FROM results WHERE season != 2026` and `SELECT COUNT(*) FROM combined_results WHERE season != 2026` both returned 25873, confirming the combined tables do not alter any pre-2026 season.

Final DuckDB check (from the handoff's Validation Commands):

```bash
python - <<'PY'
import duckdb
conn = duckdb.connect("data/processed/f1_analytics.duckdb", read_only=True)
for table in ["combined_results", "combined_driver_standings_by_round", "combined_constructor_standings_by_round"]:
    print(table, conn.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0])
print(conn.execute("SELECT * FROM kaggle_jolpica_coverage WHERE season = (SELECT MAX(season) FROM combined_results) AND results_coverage_status != 'match' ORDER BY round").fetchdf())
PY
```

Returned the expected row counts and the six `jolpica_only` rows for rounds 4-9.

## Generated Outputs

* DuckDB tables: `combined_results`, `combined_driver_standings_by_round`, `combined_constructor_standings_by_round` in `data/processed/f1_analytics.duckdb` (gitignored, regenerated by `scripts/build_combined_dataset.py`).
* `notebooks/championship_leader_combined_analysis.ipynb`, committed with its executed cell outputs (the repo's existing `.gitignore` does not exclude notebook outputs, so this follows the existing convention of tracking source/deliverable files rather than only generated data).
* No new files under `outputs/tables/` or `outputs/reports/` were created; the notebook prints its tables and narrative inline rather than writing new CSV/Markdown artifacts, since the handoff's "Files Expected To Be Generated" list this as optional ("Any new supporting CSVs the notebook writes") and the notebook's own inline output already satisfies "for user review."

## Data Assumptions And Cutoff Definitions

* Kaggle-only cutoff: the latest completed round in local `f1_results.csv` for the target season (unchanged definition).
* Combined cutoff: the max round present in `combined_driver_standings_by_round` / `combined_constructor_standings_by_round` for the target season.
* Precedence rule: Kaggle wins for any season/round with at least one Kaggle results row; Jolpica fills a season/round only where Kaggle has zero rows.
* Historical (pre-target-season) rows in the combined tables are Kaggle-derived only; Jolpica gap-fill is scoped to season/rounds Kaggle has zero rows for, which in this dataset only occurs in the current season.

## Limitations

* The combined dataset is scoped to `combined_results` and its two standings tables only; qualifying, laps, and pit-stop data remain separate-source-only (`raw_jolpica_qualifying`, `raw_jolpica_laps`, `raw_jolpica_pitstops`), not combined.
* The combined cutoff will change on the next Jolpica pull as more rounds complete; re-running `scripts/pull_jolpica_data.py` and `scripts/build_combined_dataset.py` is required to refresh it.
* Conversion-rate comparisons across cutoff rounds are not normalized for points-system or season-length differences across eras, consistent with the existing Kaggle-only report's stated limitations.

## Follow-Up Recommendations

* Command-terminal validation of this handoff (commands listed above).
* Command-terminal validation of the still-open Handoff 008 follow-up report remains a separate thread.
* Re-run this notebook periodically as Kaggle's snapshot catches up, to observe the Kaggle-only and combined cutoffs converge.
