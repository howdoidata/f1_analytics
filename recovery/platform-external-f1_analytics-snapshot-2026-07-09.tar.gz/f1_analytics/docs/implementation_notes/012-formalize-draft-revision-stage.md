# Implementation Note 012: Formalize the Draft-Revision Evaluation Stage

Handoff: `docs/handoffs/approved/012-formalize-draft-revision-stage.md`, Status: Completed.

## Summary

Closed the gap between draft review and approved-handoff revision by requiring
a dated Revision Note on any handoff in `Status: Needs Revision`. The existing
handoff-status fitness check now enforces that structural requirement, and
draft handoff 011 was updated retroactively with its first recorded note.

## Files Changed

Process rules:

* `docs/terminal_protocol.md` - defined draft evaluation and generalized the revision procedure to drafts that were never approved.
* `scripts/fitness_check.py` - extended `check_handoff_statuses()` in place with a Revision Note requirement for `Needs Revision`.
* `docs/handoffs/drafts/011-consolidate-terminal-role-duplication.md` - appended the dated retroactive Revision Note section only.

Project records:

* `docs/decisions.md` - appended the new process decision.
* `docs/questions.md`, `docs/active_context.md`, `docs/run_log.md` - updated current process state and recorded commands/results.
* `docs/implementation_notes/012-formalize-draft-revision-stage.md` - this note.

## Commands Run

* `python3 scripts/workflow.py --intent execution` before edits: `Fitness: 6 run, 0 failed`; confirmed handoff 012 was approved and execution was the correct route.
* `python3 scripts/fitness_check.py` after extending `check_handoff_statuses()` but before fixing handoff 011: `6 run, 1 failed`, with `docs/handoffs/drafts/011-consolidate-terminal-role-duplication.md: status 'Needs Revision' but no Revision Note section found`.
* `python3 scripts/fitness_check.py` after all edits: `6 run, 0 failed`.
* `python3 scripts/workflow.py`, the two `grep` validations against handoff 011, `grep -n "REVISION_NOTE_RE" scripts/fitness_check.py`, and `git status --short` completed successfully.

## Generated Outputs

None. This handoff only changed process documentation and validation logic.

## Data Assumptions / Source-Cutoff Definitions

Not applicable. No analytics code, data models, reports, outputs, or data
files were changed.

## Known Limitations

The fitness check only enforces the presence of a `## Revision Note` section.
It does not evaluate whether the note's reasoning is complete or adequate.

## Follow-Up Recommendations

Use the Revision Note requirement whenever a draft or unexecuted approved
handoff is sent back for clarification before approval or execution.
