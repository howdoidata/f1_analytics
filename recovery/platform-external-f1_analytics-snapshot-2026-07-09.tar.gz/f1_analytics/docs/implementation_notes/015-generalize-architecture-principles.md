# Handoff 015 Implementation Note

Handoff ID and status:
015 - Generalize Architecture Principles Away From Named Sources. Completed from `docs/handoffs/approved/015-generalize-architecture-principles.md`.

## Summary

Removed Kaggle/Jolpica/Ergast source names from `docs/architecture_principles.md`, replacing the two affected principle lines with generic language that preserves the same architectural point. Recorded the underlying policy (principles documents stay name-generic; concrete source/tool treatment lives only in decisions and topic docs) as a new decision in `docs/decisions.md`, and added a clarifying section to `docs/architecture_operating_model.md` distinguishing architecture-level principles from project-specific source/tool decisions.

## Files Changed

Architecture governance docs:

* `docs/architecture_principles.md`
* `docs/architecture_operating_model.md`

Project memory:

* `docs/decisions.md`
* `docs/active_context.md`
* `docs/run_log.md`

Lifecycle record:

* `docs/handoffs/approved/015-generalize-architecture-principles.md`
* `docs/implementation_notes/015-generalize-architecture-principles.md`

## Commands Run

```bash
pwd
python3 scripts/fitness_check.py
grep -niE "kaggle|jolpica|ergast" docs/architecture_principles.md
grep -n "Decision:" docs/decisions.md
sed -n '1,40p' docs/architecture_principles.md
grep -n "architecture-level principles\|principles document\|source-name-generic" docs/architecture_operating_model.md
git status --short
```

## Exact Wording Used

`docs/architecture_principles.md`, "Keep Source Boundaries Explicit" Rationale:

> Different sources may have different freshness, shape, and provenance characteristics.

`docs/architecture_principles.md`, "Do Not Merge Sources Without Precedence Rules" Practical implication:

> A newly added source stays comparison-only, separate from curated tables, until a decision explicitly defines precedence and merge rules.

## New Decision Entry

Added to `docs/decisions.md` (top of file): "2026-07-09 — Keep architecture-principles documents source/tool-name-generic", `Status: Accepted`. Records that `docs/architecture_principles.md` must stay generic and that concrete source/tool/vendor treatment belongs only in `docs/decisions.md` and topic docs such as `docs/data_sources.md`.

## New Operating Model Section

Added a "Principles Versus Source/Tool Decisions" section to `docs/architecture_operating_model.md`, immediately before "Decision Flow", distinguishing architecture-level principles (reusable, source-name-generic, revised rarely) from project-specific source/tool decisions (concrete, name specific vendors/sources/tools, revised whenever sources or tools change), and stating that a principle needing a specific source or tool name is a sign it belongs in a decision or topic doc instead.

## Validation

* First `python3 scripts/fitness_check.py` run after the principles/decision edits reported `Fitness checks: 13 run, 0 failed`.
* The operating-model section's initial wording ("Architecture-level principles", "source/tool-name-generic") did not satisfy the handoff's own case-sensitive validation grep (`architecture-level principles`, `principles document`, `source-name-generic`); the section text was adjusted to include those literal substrings, and the grep then returned matches.
* `grep -niE "kaggle|jolpica|ergast" docs/architecture_principles.md` returned no matches.
* Final `python3 scripts/fitness_check.py` reported `Fitness checks: 13 run, 0 failed`.

## Confirmation Of Untouched Files

`docs/decisions.md`'s existing 2026-07-08 Kaggle/Jolpica decision pair and `docs/data_sources.md` were not edited. `docs/asset_inventory.md`, `PROJECT.md`, `docs/project_profile.md`, `docs/questions.md`, `docs/backlog.md`, `scripts/fitness_check.py`, `scripts/workflow.py`, and existing handoffs 001-014 were not changed. No files under `src/f1_analytics/`, `sql/`, `data/`, or `outputs/` were changed.

## Generated Outputs

No analytics outputs were generated.

## Data Assumptions

No analytical data sources, cutoffs, models, reports, dashboards, or generated datasets were changed. Kaggle/Jolpica source treatment, precedence, and the `kaggle_jolpica_coverage` view are unchanged; only the generic-principle wording that previously named them was reworded.

## Known Limitations

No new fitness-check rule was added to detect source names in principles docs, per the handoff's explicit assumption that this is a backlog item if recurrence justifies automation later.

## Issues And Deviations

Marking `docs/handoffs/approved/015-generalize-architecture-principles.md` as `Status: Completed` was necessary because the existing `completed_handoffs_not_approved` fitness check fails when an implementation note exists for a handoff still marked `Approved`, consistent with the pattern in prior implementation notes (013, 014).

No git commit was introduced by this handoff.

## Follow-Up Recommendations

If source names leak into `docs/architecture_principles.md` again, consider a fitness-check rule to catch it mechanically rather than relying on manual review.
