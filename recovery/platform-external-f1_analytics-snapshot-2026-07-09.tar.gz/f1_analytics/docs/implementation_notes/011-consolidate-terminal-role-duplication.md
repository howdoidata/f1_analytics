# Implementation Note 011: Consolidate Terminal-Role and Handoff-Schema Duplication

Handoff: `docs/handoffs/approved/011-consolidate-terminal-role-duplication.md`, Status: Completed.

## Summary

Consolidated duplicated process facts into topic-local canonical documents and
trimmed the other living docs down to pointers or short summaries. Added six
new structural checks to the standing fitness script and wired them into the
workflow router so this drift class is detected mechanically.

## Files Changed

Canonical process docs:

* `docs/terminal_roles/execution.md` - made execution stop conditions canonical for execution gating.
* `docs/terminal_roles/command.md` - added the missing `## Required Inputs` section.
* `docs/handoffs/README.md` - made handoff status values canonical and replaced the duplicated required-fields sentence with a pointer.
* `docs/terminal_protocol.md` - trimmed per-terminal sections to summaries plus role-doc pointers and removed duplicated execution/status content.

Prompt and routing cleanup:

* `docs/prompts/execution_prompt.txt`, `docs/prompts/command_prompt.txt` - replaced duplicated reading lists with role-doc pointers.
* `docs/workflow_guide.md` - shortened routing descriptions and pointed to role docs as authoritative.
* `scripts/workflow.py` - shortened `INTENT_ROUTES` strings and included all new fitness checks.

Mechanical enforcement and repo records:

* `scripts/fitness_check.py` - added six new structural drift checks and expanded the main check list from 6 to 12.
* `docs/active_context.md`, `docs/decisions.md`, `docs/questions.md`, `docs/run_log.md` - updated current state and durable process records.

## Commands Run

* `python3 scripts/fitness_check.py` before edits: `6 run, 0 failed`.
* A pre-fix inline `python3` probe simulated the six new checks and showed each one failing against the unfixed docs.
* `python3 scripts/fitness_check.py` after edits: `12 run, 0 failed`.
* `python3 scripts/workflow.py` and `python3 scripts/workflow.py --intent architecture` both completed successfully with `Fitness: 12 run, 0 failed`.
* The handoff grep validations completed successfully, with the one path deviation noted below for the already-approved 011 handoff file.

## Generated Outputs

None. This handoff changed process documentation and validation scripts only.

## Data Assumptions / Source-Cutoff Definitions

Not applicable. No analytics code, data models, reports, outputs, or local data
artifacts were changed.

## Known Limitations

The new checks are intentionally structural. They catch regrown lists, missing
pointers, and enum/name mismatches, but they do not detect prose drift where
two documents describe the same fact differently without a structural cue.

## Follow-Up Recommendations

Use `python3 scripts/fitness_check.py` or `python3 scripts/workflow.py` after
future workflow-document edits to catch canonical-location drift immediately.
