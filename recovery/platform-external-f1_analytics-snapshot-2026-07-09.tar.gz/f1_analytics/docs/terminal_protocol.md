# Three-Terminal Project Workflow

## Purpose

This project uses three separate terminals to keep planning, implementation, and validation cleanly separated. The repo, not chat history, is the source of truth. Each terminal must read the correct project documents before acting and must write results back to the correct location.

## Source of Truth / Standing Fitness Check

The following files control project context. This list is also the project's **standing fitness check** in the sense used by *Building Evolutionary Architectures* (Ford/Parsons/Kua/Sadalage): a continual, recurring check of current repo state against intended state, not a one-time bootstrap step. Run it mechanically with `python3 scripts/fitness_check.py` rather than re-reading this list from memory each session.

For intent-based terminal selection and current status, see `docs/workflow_guide.md`
and run `python3 scripts/workflow.py`.

* `AGENTS.md`: Required rules for AI/coding agents.
* `PROJECT.md`: Stable project overview, goals, scope, stack, and non-goals.
* `docs/project_profile.md`: Extended project standards, output expectations, and evolution model.
* `docs/active_context.md`: Current project state, current focus, recent changes, and next expected action.
* `docs/decisions.md`: Durable decisions with rationale and tradeoffs.
* `docs/questions.md`: Open questions, answered questions, and blockers.
* `docs/backlog.md`: Deferred work.
* `docs/run_log.md`: Commands run, validation results, errors, and environment notes.
* `docs/inbox/README.md`: Supplemental intake convention for external files, corrections, specs, questions, and reference material.
* `docs/asset_inventory.md`: Lightweight inventory of important project assets, ownership roles, status, dependencies, consumers, validation, and review notes.
* `docs/architecture_operating_model.md`: Project-specific rules for routing architecture findings into decisions, questions, backlog items, handoffs, inventory updates, and validation.
* `docs/architecture_principles.md`: Project-specific principles that guide source treatment, validation, tooling, reproducibility, documentation, and change discipline.
* `docs/analysis_output_standards.md`: Standards for implementation notes, reports, and generated visuals.
* `docs/terminal_protocol.md`: Workflow, lifecycle, and completion rules for the three-terminal model.
* `docs/terminal_roles/`: Role contracts for planning, execution, and command terminals.
* `docs/handoffs/drafts/`: Proposed implementation instructions waiting for user review, edits, or approval.
* `docs/handoffs/approved/`: Execution-ready instructions approved by the user.
* `docs/implementation_notes/`: Results of completed handoffs.

Chat history is not the source of truth. If a decision or instruction matters, it must be written into one of the project documents above.

This list validates repo *structure*, not project topics. If the fitness check surfaces a finding about what this list itself should require (add/remove a required doc, change a lifecycle rule), that finding is a **process decision** and must be written into `docs/decisions.md` using the same supersede convention as any other decision (see Decision and Handoff Status below) — it must not be patched into a new copy of a planning prompt file.

## Terminal Roles

### Terminal 1: Planning

Use the planning terminal for architecture, scope, and draft-handoff work. The
authoritative role contract is `docs/terminal_roles/planning.md`.

This terminal must not edit application code. It may create or update files
under `docs/handoffs/drafts/` only when explicitly instructed by the user. It
should not place files in `docs/handoffs/approved/` unless the user explicitly
says the handoff is approved.

Planning output should usually become one of:

* A decision in `docs/decisions.md`
* An open question in `docs/questions.md`
* A draft task in `docs/handoffs/drafts/`
* A state update in `docs/active_context.md`

### Terminal 2: Execution

Use the execution terminal for approved-handoff implementation. The
authoritative role contract is `docs/terminal_roles/execution.md`.

### Terminal 3: Command

Use the command terminal for validation, scripts, installs, and command output.
The authoritative role contract is `docs/terminal_roles/command.md`.

The command terminal should not make project design decisions. It should record
important commands and results in `docs/run_log.md` before the command-terminal
turn ends.

## Handoff Lifecycle

Every implementation task should follow this lifecycle:

1. Planning terminal creates or updates a draft handoff file in `docs/handoffs/drafts/` only when explicitly instructed.
2. User reviews the draft, raising clarifying questions and checking its stated assumptions, and either approves it or, if it is not yet ready, marks it `Status: Needs Revision` and appends a dated Revision Note (see "Revising vs. superseding a handoff" below) describing the open question(s) or assumption(s) that must be resolved before approval.
3. An approved handoff is placed in `docs/handoffs/approved/`.
4. Execution terminal reads the approved handoff and implements only that task.
5. Command terminal runs validation commands from the approved handoff.
6. Execution results are recorded in `docs/implementation_notes/`, and the command terminal is responsible for recording command and validation results in `docs/run_log.md`.
7. Planning terminal updates `docs/active_context.md` and, if needed, `docs/decisions.md`, `docs/questions.md`, or `docs/backlog.md`.

## Handoff Requirements

Each handoff must include:

* Handoff ID
* Status
* Goal
* Success criteria
* Files expected to change
* Files that should not change
* Relevant project context
* Decisions already made
* Assumptions not to revisit
* Step-by-step implementation instructions
* Validation commands
* Expected outputs
* Stop conditions
* What to report back after completion

## Decision and Handoff Status

Both `docs/decisions.md` and handoffs use the standard ADR (Architecture Decision Record) status lifecycle: `Draft`/`Proposed` → `Approved`/`Accepted` → `Completed`, `Rejected`, or `Superseded`. Handoff status values are maintained in `docs/handoffs/README.md`. Decision status values are: `Accepted`, `Rejected`, `Superseded`.

**A frozen record's body is never rewritten.** Once a decision is `Accepted` or a handoff is `Approved`, its Rationale/Tradeoffs/Context or its implementation steps stay as originally written. Only the Status line may later be updated (for example, to add `Superseded by: <name or filename>`) — this is standard ADR practice, not a project-specific exception.

### Revising vs. superseding a handoff

The usual case is a human reviewer finding a problem while reviewing a handoff
for the first time. If the handoff is still a draft and nothing has been
executed, the next action is straightforward:

1. **Human reviewer:** Do not approve the handoff or send it to the execution
   terminal. Tell the planning terminal what is wrong, unclear, or based on an
   assumption that needs resolution.
2. **Planning terminal:** Keep the same file and handoff ID in
   `docs/handoffs/drafts/`. Set `Status: Needs Revision`, append a dated
   `## Revision Note` that records the review finding, and revise the draft to
   resolve it.
3. **Human reviewer:** Review the revised draft again. If the issue is resolved,
   explicitly approve it; otherwise return it to the planning terminal for
   another revision note and revision.
4. **Planning terminal:** After explicit human approval, set `Status: Approved`
   and move the same file to `docs/handoffs/approved/`.
5. **Command terminal:** Run `python3 scripts/fitness_check.py` and record the
   command and result in `docs/run_log.md`. A passing check confirms the
   handoff's status, folder, and required revision-note structure are valid; it
   does not replace human review.

The distinction between revision and supersession is whether any part of the
handoff has already been executed:

* **Revision means no execution has started.** The handoff is still a working
  instruction and may be corrected in place, using the same file and ID. For a
  draft, follow the first-review procedure above. For an approved but
  unexecuted handoff, the planning terminal first sets
  `Status: Needs Revision`, moves it back to `docs/handoffs/drafts/`, and
  appends the dated Revision Note before changing its body.
* **Supersession means execution has started.** The original handoff is now a
  historical record of instructions that were used and its body must not be
  rewritten. The planning terminal creates a new draft with the next
  sequential ID and `Supersedes: <original filename>`, describing the
  correction or replacement. It updates only the original handoff's status
  metadata to `Superseded` and adds the reciprocal reference. The human
  reviewer reviews and explicitly approves the new handoff through the normal
  lifecycle.

If the execution state is uncertain, the **human reviewer** pauses approval and
asks the **command terminal** to check `docs/run_log.md`,
`docs/implementation_notes/`, and other recorded command output for evidence
that any handoff step ran. The command terminal reports and records the result;
it does not choose revision or supersession and does not edit the handoff. The
**planning terminal** then applies the rule above from that evidence.

In practical terms: when you review a handoff and find something wrong or
unclear, stop before approval, state the finding to the planning terminal, and
keep the handoff in drafts. Revise the same handoff unless recorded evidence
shows that execution already started; only then create a superseding handoff.

## Stop Conditions

Execution stop conditions are maintained in
`docs/terminal_roles/execution.md`.

## Context Refresh Rule

Before starting any task, every terminal should confirm:

* Current branch or working directory
* Current repo state
* Current active handoff
* Relevant decisions
* Open blockers

No terminal should rely only on memory from previous chat messages.

## Completion Rule

A task is not complete until the following are true:

* The intended files were changed
* Validation commands were run or clearly marked as not run
* Results were recorded
* Any blockers were documented
* `docs/active_context.md` reflects the new project state
