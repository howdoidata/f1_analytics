# Analysis Output Standards

## Implementation Notes

Implementation notes should help a future reader understand what changed, why it matters, and how it was validated without reading the full handoff.

Each note should include:

* Handoff ID and status.
* User-facing summary in plain language.
* Files changed, grouped by purpose.
* Commands run and whether they passed.
* Generated outputs and where to inspect them.
* Data assumptions and source/cutoff definitions.
* Known limitations.
* Follow-up recommendations.

## Function And Resource Documentation

Public or reused functions should have docstrings that state:

* Purpose.
* Key inputs.
* Return value.
* Assumptions.
* Failure behavior when relevant.

One-off internal helpers can stay lightly documented when the code is clear.

Data resources should be documented in `docs/data_sources.md` or the relevant architecture document. Reusable SQL should include a short header comment explaining grain, source tables, and intended use. Generated outputs should be documented in the report or implementation note that creates them.

## Report Outputs

Reports should state:

* The question answered.
* Data sources used.
* Source and cutoff definitions.
* Main result in plain language.
* Supporting tables or generated artifacts.
* Limitations and assumptions.
* Useful follow-up analysis.

Generated Markdown reports belong under `outputs/reports/`. Supporting tabular exports belong under `outputs/tables/`.

## Visualization Rules

Use visuals when they reduce explanation burden or make comparison easier. Do not add charts for decoration.

Each visual should have:

* A clear title.
* Metric definition.
* Source/cutoff note.
* Output path documented in the related report or implementation note.

For Version 1, prefer simple charts such as bar charts, line charts, and small tables. Store generated chart artifacts under `outputs/figures/`. Keep chart code in analysis modules or scripts, not only in notebooks.

Do not add a dashboard until repeated reports justify it.
