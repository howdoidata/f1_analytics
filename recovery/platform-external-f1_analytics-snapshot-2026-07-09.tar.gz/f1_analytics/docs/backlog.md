# Backlog

## Architecture Governance

These architecture governance follow-ups keep asset review, operating-model gaps, and governance automation candidates visible without creating a separate roadmap yet.

* Multi-project platform separation: now scoped by the 2026-07-09 decision "Deliver the bootstrap specification as an incremental, phase-scoped handoff sequence starting with repository scaffold only" (which superseded the same-day all-phases-in-one-handoff decision; the six-handoff in-place migration attempt before that was withdrawn by the user before approval). Phases 0-3 (`017`-`020`) are executed and verified against `TARGET_DIR` (`/Users/antonio/Documents/howdoidata/projects/platform`): repository scaffold, platform governance documents (decisions/questions/backlog/run-log/asset-inventory/architecture-principles/architecture-operating-model/analysis-output-standards/multi-project-operating-model), the terminal workflow layer (role contracts, protocol, handoff lifecycle, implementation notes, inbox intake, workflow guide, prompts, active-context), and the mechanical `scripts/fitness_check.py`/`scripts/workflow.py` pair (direct verification on 2026-07-10: `python3 scripts/fitness_check.py` passes 10/10 against `TARGET_DIR`). See the 2026-07-10 decision "Accept Phase 3's Source-Of-Truth correction..." for a process finding raised during Phase 3 execution; an analogous delivery/precondition gap surfaced and was fixed during Phase 4's own revision cycle (see Handoff 021's Revision Note); a third occurrence (a self-referential placeholder-scan paradox in Handoff 022's own Gate text) surfaced during Phase 5 and was fixed in place rather than stopped-and-reported. Phases 4-5 are both `Status: Completed` and directly verified against `TARGET_DIR`. Phase 5 (Verification A) ran natively inside `TARGET_DIR` using its own planning/execution terminals (`TARGET_DIR/docs/handoffs/approved/022-platform-bootstrap-phase5-verification-a.md`) rather than as a handoff drafted in this repository — proof the platform can now plan and execute its own work independently. Two small unresolved items from Phase 5: `TARGET_DIR/PROJECT.md`'s `## Projects` section is stale (doesn't list the kept `verification_project`), and the fix-vs-stop-and-report pattern has now recurred three times (Phases 3, 4, 5) with three different root causes, which may warrant generalizing the 2026-07-10 decision rather than treating each occurrence as a one-off. Phase 6 (Verification B: onboarding this repository's own F1 workflow, combined-analysis notebook headless, as an external project through the generic onboarding procedure) is the last phase in the original 0-6 roadmap and has not been drafted; given Phase 5's precedent, it may also be requested via `TARGET_DIR`'s own inbox rather than as a handoff authored in this repository. Deferred until the full sequence is executed and verified: (a) decide whether this repository is rebuilt/replaced via the specification or remains as-is as the F1 source bundle; (b) onboard a real (non-synthetic) second project; (c) reconcile any drift between the specification's embedded process rules and this repository's live process docs if either evolves; (d) confirm the `TARGET_DIR` `docs/decisions.md` `###`-heading-nested-under-`## Log` convention actually holds once a real decision entry is written there — unverified as of Phase 3 since that file's log is still empty (`decision_entries_well_formed` currently passes only because an empty log is trivially valid), so the `decision_entries_well_formed`/`supersede_references_valid` checks remain unexercised against real content; Phase 5 is the first point a platform- or project-level decision entry is likely to be written.
* Run the first monthly inventory review after `docs/asset_inventory.md`, `docs/architecture_operating_model.md`, and `docs/architecture_principles.md` have been used in at least one subsequent planning or execution cycle.
* Identify which inventory rows need stronger validation details, fresher last-reviewed dates, or clearer consumers.
* Decide later whether a separate `docs/roadmap.md` is warranted, after backlog items repeatedly need phase-level planning beyond the current sections.
* Evaluate whether any architecture-governance rules should become automated fitness checks after repeated manual use.
* Review `Unknown`, `TBD`, and `Not applicable` values in `docs/asset_inventory.md` and convert real gaps into questions, backlog items, or handoffs.

## Completed Foundation Items

* KaggleHub data access setup for the selected Formula 1 dataset.
* Raw Kaggle CSV download into the local ignored data directory.
* DuckDB build for raw and curated Formula 1 tables.
* First championship-leader Markdown report and supporting CSV outputs.
* Reusable source, database, and analysis module structure under `src/f1_analytics/`.
* Reusable SQL folders under `sql/curated/` and `sql/analysis/`.
* Jolpica/Ergast loaded as a fully loaded, separate current-season source (`raw_jolpica_*` tables), with a `kaggle_jolpica_coverage` view comparing it against Kaggle.
* Kaggle `f1_circuits.csv` and `f1_qualifying.csv` loaded as raw and curated tables.
* Basic null-rate and referential-integrity validation checks for curated Kaggle tables, logged to `validation_results`.
* Constructor name-to-`constructor_id` reconciliation for `final_driver_standings`.

## Deferred Items

* Polished visualization for the championship-leader analysis.
* dbt evaluation after the first reusable tables are understood.
* Airflow orchestration after the local workflow is stable.
* Dashboard structure and Tableau-ready outputs.
* Machine learning exploration after the Version 1 analytics workflow exists.

## Not Started

* Define whether selected generated reports should be tracked as portfolio artifacts.
* Decide whether the next public artifact should be a refined Markdown story, Plotly visualization, or Tableau-ready export.
