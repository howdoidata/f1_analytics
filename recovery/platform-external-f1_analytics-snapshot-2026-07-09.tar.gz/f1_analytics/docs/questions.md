# Questions

## Open Questions

* Final project stack: Which tools are required for Version 1, and which should remain deferred?

* Planning scope discipline: Should the planning terminal, when evaluating a project-specific (deliverable-scoped) request, default to first checking whether an existing asset already meets the exact stated conditions — via `docs/asset_inventory.md` and related canonical docs — before pulling in broader analysis? Raised during review of draft Handoff 016: the reviewer's note characterized the draft's initial analysis as taking in more information than the request needed, and suggested that for project-specific requests, planning should check for an exact-match existing asset first, treating any unknowns that surface only as logged follow-ups (`docs/questions.md`/`docs/backlog.md`) rather than as blockers to producing a draft. Not yet adopted as policy — needs a decision on scope (which request types this applies to) before it could become a durable rule in `docs/decisions.md` or `docs/terminal_roles/planning.md`.

## Answered Questions

* Project-agnostic platform scope: How should project-agnostic architecture/process assets be separated from project-specific (F1) assets so multiple projects can share one operating model while each project's data, history, and assets stay isolated?
	- Build it fresh in an empty directory with no access to this repository's history, delivered as an incremental sequence of small, phase-scoped handoffs rather than one large specification, per the 2026-07-09 decision ("Deliver the bootstrap specification as an incremental, phase-scoped handoff sequence starting with repository scaffold only"), which superseded the same-day all-phases-in-one-handoff decision after the user asked to see only the first phase adhered to before more is drafted.
	- Each phase must still templatize the project's real, load-bearing architecture rationale into generic instructional text (not blank placeholders) while carrying forward none of this repository's logged history.
	- The platform shape carries forward: one repository, generic platform layer at root, isolated `projects/<project_name>/` folders, and a gitignored `exchange/` staging convention for moving files into or out of a project — these apply once later phases introduce them.
	- Phases 0-4 (repository scaffold; platform governance documents; terminal workflow layer; mechanical fitness-check/workflow scripts; multi-project layer: `projects/`, `exchange/`, project template/generator) are executed and verified against `TARGET_DIR` (`/Users/antonio/Documents/howdoidata/projects/platform`), as `docs/handoffs/approved/017`-`021` (all `Status: Completed`, except 021 include its `Status: Approved`→`Completed` history). Phases 3 and 4 each surfaced a stop-and-report-vs-in-place-fix finding during execution, resolved per the 2026-07-10 decision and Handoff 021's own Revision Note. A synthetic-project verification (Phase 5) and onboarding the existing F1 workflow (combined-analysis notebook headless) as an external-project verification (Phase 6) are planned as follow-on phases/handoffs, each drafted only after the previous one is reviewed and, if approved, executed. Phase 5 is being requested via `docs/inbox/` rather than directly, to test the inbox-triage path.
	- This repository is not restructured in place; whether it is later rebuilt via the specification is a separate future decision.

* Architecture governance: How should architecture governance audit observations and architecture findings enter the project workflow?
	- Use `docs/architecture_operating_model.md` to route each finding to one durable destination.
	- Use `docs/decisions.md` for durable policy, source, tool, lifecycle, or architecture choices.
	- Use `docs/questions.md` for unresolved blockers or answers needed before action.
	- Use `docs/backlog.md` for concrete deferred work, risks, cleanup, validation gaps, documentation gaps, and retirement candidates.
	- Use `docs/handoffs/drafts/` when the work is specific enough for execution.
	- Use `docs/asset_inventory.md` for asset metadata corrections and visibility gaps.

* External input intake: How should users provide external files, corrections, and reference material for planning or execution?
	- Use `docs/inbox/` as a supplemental intake area when the input is easier to provide as a file or bundle than in a prompt.
	- Raw inbox items use either `docs/inbox/YYYY-MM-DD-short-slug.md` or `docs/inbox/YYYY-MM-DD-short-slug/` with a `README.md` cover sheet.
	- Planning owns triage and routes each item to the durable destination: questions, decisions, draft edits, superseding handoffs, `data/raw/<source>/`, or `docs/inbox/processed/`.
	- Execution and command terminals may use inbox material only after planning has triaged it and an approved handoff or validation instruction references it.

* Data source handling: How should the initial Formula 1 dataset be acquired, stored locally, and refreshed?
	- Plan is to download from Kaggle using KaggleHub: https://www.kaggle.com/datasets/patelris/formula-1-complete-dataset-1950-2026
	- Use KaggleHub Option 3 authentication with the token file at `/Users/antonio/.kaggle/access_token`.
	- The token file is private local machine state and must not be committed.
	- Download raw files into `data/raw/f1_complete_dataset/`, which is ignored by Git.

* First deliverable: What is the first end-to-end Version 1 artifact?
	- A local DuckDB dataset plus a Markdown time-analysis report answering how often championship leaders at the current season cutoff went on to win the title.
	- The first report covers both drivers and constructors.
	- Supporting CSV outputs are written under `outputs/tables/`.

* Version 1 output format: Should the first insight story be a notebook, Markdown report, dashboard-ready extract, or another format?
	- The first insight story is a Markdown report with supporting CSV output tables.
	- Notebook, dashboard, and visualization polish remain deferred until a later handoff.
	- Handoff 016 (`docs/handoffs/approved/016-combined-dataset-championship-leader-notebook.md`) is that later handoff for the notebook specifically: it delivers the first notebook, at `notebooks/championship_leader_combined_analysis.ipynb`, executing headlessly against the scoped combined Kaggle+Jolpica dataset. Dashboard and Tableau-ready polish remain deferred.

* Project structure: What minimal folder structure is needed once the first data workflow is selected?
	- Shared Python functions live under `src/f1_analytics/`.
	- Source adapters live under `src/f1_analytics/data_sources/`.
	- DuckDB helpers live under `src/f1_analytics/database/`.
	- Reusable analysis logic lives under `src/f1_analytics/analysis/`.
	- Reusable SQL should live under `sql/curated/` or `sql/analysis/`.

* Should Jolpica/Ergast be used alongside Kaggle?
	- Kaggle CSV remains the Version 1 baseline source for curated tables.
	- Jolpica/Ergast is now fully loaded as a separate, comparison-only source (`raw_jolpica_*` tables), triggered by a concrete 2026-season staleness gap found in the Kaggle snapshot.
	- Jolpica data is never merged into Kaggle curated tables; a `kaggle_jolpica_coverage` view surfaces agreement/divergence per season and round.

* Should `f1_circuits.csv` and `f1_qualifying.csv` be loaded?
	- Yes. Both are loaded as raw and curated DuckDB tables (2026-07-08).

* How should the `f1_driver_standings.csv` constructor-name-only join gap be handled?
	- A reconciliation step maps the free-text constructor name to `constructor_id` using the id/name pairs already present in `results` and `constructor_standings` (2026-07-08). The mapping is unambiguous for the current dataset.

* How should implementation notes and analysis outputs communicate results?
	- Use the standard in `docs/analysis_output_standards.md`.
	- Future implementation notes should include handoff/status, plain-language summary, files changed, commands and results, generated outputs, data assumptions/cutoffs, limitations, and follow-up recommendations.
	- Reports should state sources, cutoff definitions, main results, generated artifacts, limitations, and follow-up directions.

* When should the project add analysis visuals?
	- Add visuals only when they reduce explanation burden or make comparison easier.
	- Keep Version 1 visuals simple and generated under `outputs/figures/`.
	- Do not add a dashboard until repeated reports justify it.

* What is the first follow-up analytical output after the championship-leader conversion report?
	- A Markdown follow-up report at `outputs/reports/championship_leader_followup.md`.
	- It keeps the Kaggle round-3 cutoff intact, adds historical constructor comeback cases, and defines candidate recovery features for future explanatory analysis.

* Enablement: How should users choose a terminal, revise a handoff, and find the next action?
	- Use the intent-based decision tree in `docs/workflow_guide.md`.
	- Run `python3 scripts/workflow.py` for current fitness, focus, next action, pending handoffs, and the latest implementation note.
	- Follow the existing revise-vs-supersede procedure in `docs/terminal_protocol.md`; no additional interface is needed.

* Draft review: What records why a draft handoff was sent back before approval?
	- Any handoff at `Status: Needs Revision`, including drafts that were never approved, must include a dated `## Revision Note` section.
	- `docs/terminal_protocol.md` now defines draft evaluation as raising clarifying questions and checking assumptions before approval.
	- `scripts/fitness_check.py` enforces only the presence of the section, not the quality of its contents.

* Process governance: Where do canonical terminal and handoff process facts live?
	- Terminal responsibilities and required inputs live in `docs/terminal_roles/*.md`.
	- Handoff status values live in `docs/handoffs/README.md`.
	- Workflow lifecycle and handoff required fields live in `docs/terminal_protocol.md`.
	- `scripts/fitness_check.py` and `scripts/workflow.py` enforce these canonical locations structurally rather than duplicating the facts inline.

## Blockers

None currently recorded.
