# Asset Inventory

## Purpose

This inventory is the lightweight control plane for important project assets. It records what exists, why it exists, who is responsible by role, how important it is, what it depends on, what depends on it, and how it is validated.

This is a Level 1 / early Level 2 inventory. It should stay simple and useful. Unknowns are explicit so they can become backlog items instead of hidden risk.

## Conventions

Status values:

* `Draft`
* `Active`
* `Deprecated`
* `Superseded`
* `Retired`
* `Unknown`

Criticality values:

* `High`
* `Medium`
* `Low`
* `Unknown`

Owner/role should name the accountable project role, not necessarily an individual. Use `TBD` when ownership is not yet clear.

## Inventory

| Asset ID | Type | Purpose | Owner/Role | Status | Criticality | Dependencies | Consumers | Validation | Last Reviewed | Notes |
|---|---|---|---|---|---|---|---|---|---|---|
| `project_context_docs` | Documentation | Define stable project purpose, profile, current state, setup, sources, architecture, and operating context. | Planning terminal | Active | High | `AGENTS.md`, `PROJECT.md`, `docs/project_profile.md`, `docs/active_context.md`, `docs/local_setup.md`, `docs/data_sources.md`, `docs/architecture.md` | Planning, execution, command, future portfolio readers | Reviewed through required terminal reads and `python3 scripts/fitness_check.py` required-doc checks | 2026-07-09 | Keep current before planning or execution work. |
| `terminal_workflow_docs` | Governance documentation | Define the three-terminal workflow, role contracts, prompt routing, and workflow guide. | Planning terminal | Active | High | `docs/terminal_protocol.md`, `docs/terminal_roles/`, `docs/prompts/`, `docs/workflow_guide.md` | All terminal workflows | `python3 scripts/fitness_check.py` structural checks | 2026-07-09 | Process facts should stay canonical by topic. |
| `handoff_lifecycle` | Workflow asset | Store draft and approved implementation instructions with lifecycle status. | Planning terminal for drafts; execution terminal for approved implementation | Active | High | `docs/handoffs/README.md`, `docs/handoffs/drafts/`, `docs/handoffs/approved/`, `docs/terminal_protocol.md` | Execution terminal, command terminal, implementation notes | Handoff status and folder checks in `python3 scripts/fitness_check.py` | 2026-07-09 | Approved/completed handoff bodies are frozen records. |
| `inbox_intake` | Workflow asset | Intake and retain external corrections, reference material, specs, questions, and file bundles. | Planning terminal | Active | Medium | `docs/inbox/README.md`, `docs/inbox/processed/` | Planning; execution or command only when referenced by approved workflow artifacts | `check_inbox_items_triaged` in `python3 scripts/fitness_check.py` | 2026-07-09 | Raw inbox items must be triaged before planning proceeds. |
| `decision_question_backlog_logs` | Governance documentation | Preserve durable decisions, open/answered questions, deferred work, and command history. | Planning terminal for decisions/questions/backlog; command terminal for run log validation results | Active | High | `docs/decisions.md`, `docs/questions.md`, `docs/backlog.md`, `docs/run_log.md` | Planning, execution, command, audit/review work | Decision-entry structural check; automatic fitness-check run-log entries | 2026-07-09 | Backlog is the current home for concrete deferred work; no separate roadmap file yet. |
| `implementation_notes` | Documentation | Record completed handoff outcomes, files changed, validation, issues, and follow-up recommendations. | Execution terminal | Active | High | `docs/implementation_notes/README.md`, completed handoffs | Planning, future execution, command validation | `completed_handoffs_not_approved` check detects completed notes still marked Approved | 2026-07-09 | Notes are written after execution and before final handoff completion. |
| `kaggle_raw_source` | Data asset | Store local raw Kaggle Formula 1 CSV snapshot. | Data workflow owner | Active | High | KaggleHub dataset, local Kaggle credentials, `scripts/download_kagglehub_f1_data.py` | DuckDB build, curated Kaggle tables, reports | Build-time load checks and curated-table validation after processing | 2026-07-09 | Local raw data is ignored by Git. |
| `jolpica_raw_source` | Data asset | Store cached Jolpica/Ergast current-season JSON responses as a separate comparison source. | Data workflow owner | Active | Medium | Jolpica API, `scripts/pull_jolpica_data.py`, `src/f1_analytics/data_sources/jolpica_loader.py` | `raw_jolpica_*` tables, Kaggle/Jolpica coverage view | Load command output and coverage comparison view | 2026-07-09 | Never merged into Kaggle curated tables without a future source-precedence decision. |
| `duckdb_processed_database` | Data asset | Store raw source tables, curated reusable tables, validation results, and analysis views. | Data workflow owner | Active | High | Raw Kaggle CSVs, Jolpica cache, `src/f1_analytics/`, `sql/` | Analysis scripts, generated reports/tables, future dashboards | `src/f1_analytics/validation/checks.py`, `validation_results`, build scripts | 2026-07-09 | Local processed database is ignored by Git. |
| `reusable_python_modules` | Code asset | Provide reusable source loading, database, validation, and analysis logic. | Execution terminal | Active | High | Python dependencies, raw data, DuckDB, `src/f1_analytics/` package structure | Command scripts, build workflow, analysis workflow | Script execution, validation checks, import/runtime behavior | 2026-07-09 | No changes in this handoff. |
| `command_scripts` | Workflow/code asset | Provide command-line wrappers for download, build, source pull, analysis, workflow status, and fitness checks. | Execution terminal for implementation; command terminal for operation | Active | High | `scripts/`, reusable Python modules, project docs | Command terminal, validation, generated outputs | Command execution and `python3 scripts/fitness_check.py` | 2026-07-09 | `scripts/fitness_check.py` is part of process governance. |
| `reusable_sql` | SQL asset | Store reusable curated and analysis SQL, including Kaggle/Jolpica coverage view. | Data workflow owner | Active | Medium | DuckDB, curated/raw tables, `sql/curated/`, `sql/analysis/` | Processed database, analysis workflows | SQL execution during build or analysis | 2026-07-09 | No changes in this handoff. |
| `generated_outputs` | Generated output asset | Store generated reports, tables, and figures for analysis and portfolio candidates. | Analysis workflow owner | Active | Medium | Processed DuckDB database, analysis scripts, output standards | Portfolio review, reporting, future dashboard decisions | Re-run analysis commands and inspect outputs | 2026-07-09 | Generated outputs are local/ignored unless a future decision tracks selected artifacts. |

## Review Notes

Use the architecture operating model to route findings from this inventory. Gaps should become a decision, question, backlog item, draft handoff, inventory update, or no-action note.
