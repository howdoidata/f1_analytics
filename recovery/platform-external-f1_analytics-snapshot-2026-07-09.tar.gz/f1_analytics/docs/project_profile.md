# Project Profile

## Project Summary

This project is intended to showcase data engineering, analysis, and data science skills using Formula 1 data. It should demonstrate the ability to build modular, maintainable analytics workflows that connect data ingestion, transformation, analysis, modeling, visualization, and communication.

The project should not be built as a disconnected notebook exercise. It should show how upstream engineering choices affect downstream analysis, dashboards, storytelling, and future maintainability.

## Intended Outputs

The project may eventually produce:

* Clean, reusable data pipelines
* Curated analytics tables or data models
* Exploratory analysis notebooks
* Predictive or statistical models
* Dashboard-ready datasets
* Tableau dashboards
* Plotly or Python-based visualizations
* LinkedIn-ready data stories
* Portfolio case studies
* GitHub-ready documentation
* Reusable project templates or workflow patterns

Not all outputs need to exist in Version 1. Outputs should be introduced progressively as the project matures.

## Iterative Development Model

The project should evolve through iterative sessions rather than one large linear build.

Example session pattern:

* Session 1: Identify data engineering problems and build initial solutions
* Session 2: Perform exploratory analysis using the available modeled data
* Session 3: Revisit and improve earlier data engineering solutions based on analysis needs

Later sessions should look backward and forward at the same time:

* Backward, to preserve decisions, standards, naming, formatting, and existing logic
* Forward, to ensure new work supports downstream analysis, dashboards, modeling, and storytelling

Core features may be introduced at different levels of maturity and refined over time.

## Audience Detail

Primary audience:

Hiring managers and analytics leaders evaluating whether the project demonstrates technical skill, analytical judgment, business communication, and strategic thinking.

Secondary audience:

LinkedIn followers, recruiters, and data professionals interested in Formula 1 analytics, data storytelling, and practical analytics workflows.

## Skill Areas to Demonstrate

The project should demonstrate strength across several areas:

* Data ingestion
* Data cleaning
* Data modeling
* SQL development
* Python analysis
* Exploratory data analysis
* Data quality checks
* Reproducible workflows
* Analytics engineering
* Dashboard preparation
* Statistical or predictive modeling where appropriate
* Visualization and storytelling
* Business-style communication
* GitHub documentation
* Practical project organization

## Technical Direction

The project should lean toward tools that are valuable for analytics, data engineering, and portfolio demonstration:

* Python for ingestion, analysis, automation, and modeling
* pandas for data manipulation
* SQL for reusable analytical logic
* DuckDB for lightweight local analytics
* dbt for data modeling if appropriate
* Airflow for orchestration when the project is mature enough to justify it
* scikit-learn for predictive or statistical modeling when useful
* Plotly and other practical visualization packages for exploratory and presentation visuals
* Tableau for dashboard storytelling
* GitHub for project documentation and version control

Tools should be introduced only when they add value. The project should avoid adding tools simply to appear more advanced.

## Data Direction

The expected starting dataset is the Kaggle Formula 1 complete dataset covering 1950 to 2026.

Dataset-specific decisions should be made after reviewing the actual files, fields, grain, quality, and limitations.

Future sessions may evaluate:

* Whether to use raw CSV files directly
* Whether to stage data into DuckDB
* Whether to model transformations through SQL, Python, dbt, or a combination
* Whether orchestration is needed
* Whether additional sources are useful
* Whether the project requires a refresh process

## Version 1 Definition

Version 1 should prove the end-to-end pattern:

1. Ingest Formula 1 data
2. Understand the raw structure
3. Create clean reusable tables
4. Run basic exploratory analysis
5. Validate important assumptions
6. Produce one clear insight story
7. Document the workflow clearly enough that it can be reused or extended

Version 1 should establish the foundation, not solve every possible F1 analytics question.

## Version 1 Non-Goals

Version 1 should not include:

* Paid APIs
* Betting or gambling analysis
* Heavy cloud infrastructure
* Large-scale package architecture
* Overly complex orchestration
* Advanced machine learning before the data foundation is stable
* Automated LinkedIn publishing
* A full dashboard build before the modeled data is ready

## Project Standards

The project should follow these standards:

* Keep workflows modular and readable
* Prefer simple solutions before complex ones
* Use clear naming conventions
* Document durable decisions
* Include validation checks where useful
* Avoid isolated notebooks that cannot be reused
* Create outputs that can support dashboards and storytelling
* Make technical work understandable to a business audience
* Preserve context across sessions
* Revisit earlier decisions when downstream analysis reveals a better approach

## Communication Standard

Final outputs should not only show technical work. They should explain:

* What question was being answered
* Why the question matters
* What data was used
* What assumptions or limitations exist
* What the analysis found
* How the finding could be communicated to a non-technical audience
* How the work could become a portfolio artifact or LinkedIn data story

## Future Update Rule

This file can be updated as the project matures, but major durable decisions should be recorded separately in:

* `docs/decisions.md`

Current working state should be recorded separately in:

* `docs/active_context.md`
