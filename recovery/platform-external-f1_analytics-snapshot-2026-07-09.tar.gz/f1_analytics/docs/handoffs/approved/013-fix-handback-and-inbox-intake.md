# Handoff 013: Fix Command-Terminal Handback Ambiguity and Introduce External-Input Intake

Status: Completed

## Goal

Introduce two immediate process capabilities that the current three-terminal model needs now:

1. Make command-terminal validation handback complete only when validation results are recorded in `docs/run_log.md`, so a later planning session can confirm the latest fitness state from the repo instead of from chat.
2. Add a lightweight, supplemental `docs/inbox/` intake convention for human-provided external files, corrections, specs, questions, and reference material that need to influence planning or execution.

`docs/inbox/` does not replace `docs/questions.md`, `docs/decisions.md`, handoffs, implementation notes, raw data folders, or generated outputs. It is an entry point for material that is easier to provide as a file or file bundle than to paste into a prompt. After triage, the durable conclusion must land in the correct existing project artifact.

## Planning Summary

What should exist:

* A repo-owned inbox at `docs/inbox/` for external planning/execution inputs that are not already covered by the analytics data pipeline.
* Two supported input shapes:
  * a single Markdown intake note: `docs/inbox/YYYY-MM-DD-short-slug.md`
  * a file bundle: `docs/inbox/YYYY-MM-DD-short-slug/` containing a `README.md` cover sheet plus attached files.
* A clear cover-sheet/header format so users know what to provide:
  * `Date:` — when the user added the item.
  * `Intent:` — one of `correction`, `new-context`, `question`, `data-spec`, `reference-material`.
  * `Related:` — optional link to a handoff, decision, question, implementation note, report, data source, or file path.
  * `Summary:` — what the file/context says in plain language.
  * `Requested Use:` — what the user wants the project to do with it.
  * `Retention Guidance:` — whether the source file should be retained for later reference, can be superseded after triage, or should move to a data/source location.
* Human-facing directions in `docs/workflow_guide.md` explaining when to use the inbox and when to edit a draft handoff directly.
* Planning-terminal triage ownership: planning checks raw inbox items before planning work and routes each one to a durable destination.
* Cross-terminal accessibility after triage:
  * planning reads raw inbox items and decides where they belong.
  * execution may read processed inbox items only when an approved handoff references them.
  * command may read processed inbox items only when validation/setup instructions reference them.
* A retention rule for processed items: each moved item gets a landing note showing whether the information was stored, superseded, moved, rejected, or requires follow-up.
* A mechanical guardrail: `python3 scripts/fitness_check.py` fails if untriaged items remain directly under `docs/inbox/`.

How it fits the project architecture:

* `docs/inbox/` is part of the documentation/process layer. It is not a new analytics source layer and not a general dumping ground.
* Analytical datasets still belong under `data/raw/<source>/` and should be handled by source-specific loaders and data-source documentation.
* External reference files that inform planning/execution enter through `docs/inbox/`, are triaged, then either:
  * become a durable question, decision, handoff edit, or superseding handoff;
  * remain archived in `docs/inbox/processed/` with a landing note and future reference path;
  * move to `data/raw/<source>/` if they are actually datasets; or
  * are marked as superseded/no-action with the reason recorded.
* This preserves the existing three-terminal model: humans supply context, planning triages and decides where it belongs, execution implements only approved handoffs, and command validates.

## Success Criteria

* `scripts/fitness_check.py` records its own run result in `docs/run_log.md` every time it completes the check list, before returning its exit code. The entry must include a timestamp, the command `python3 scripts/fitness_check.py`, and the summary line `Fitness checks: N run, M failed`. A failed fitness result must still be logged.
* The self-logged run-log entry uses the existing reverse-chronological Markdown style in `docs/run_log.md`: newest entry near the top under `# Run Log`, not a detached ad hoc line at the bottom.
* `docs/terminal_roles/command.md` Required Behavior step 4 no longer offers "record or return" as equally valid choices. Results must land in `docs/run_log.md` before the command-terminal turn ends. Note that `fitness_check.py` records itself automatically after this handoff; other validation commands still require manual run-log recording.
* `docs/terminal_protocol.md` Handoff Lifecycle step 6 names the command terminal as responsible for the `docs/run_log.md` portion.
* `docs/inbox/README.md` exists and documents:
  * purpose: supplemental intake for external files/context, not a replacement for existing durable docs.
  * supported input shapes: single Markdown note or folder bundle with a `README.md` cover sheet.
  * filename/folder convention: `YYYY-MM-DD-short-slug`.
  * required fields: `Date:`, `Intent:`, `Summary:`, `Requested Use:`.
  * optional fields: `Related:`, `Retention Guidance:`, `Source/Origin:`, `Constraints:`.
  * allowed `Intent:` values: `correction`, `new-context`, `question`, `data-spec`, `reference-material`.
  * examples for at least three common cases:
    * correcting a draft handoff.
    * providing a PDF/reference file for planning.
    * providing a file needed by an approved execution handoff.
  * ownership/access rule:
    * planning owns raw inbox triage.
    * execution and command may use inbox material only after planning has triaged it and an approved handoff or validation instruction references it.
  * triage destinations:
    * `docs/questions.md`
    * `docs/decisions.md`, using supersession when the item contradicts an accepted decision
    * direct edits to a draft handoff
    * a new handoff that supersedes an approved/completed handoff
    * `data/raw/<source>/` when the item is actually an analytical dataset
    * `docs/inbox/processed/` as retained reference material when the source file should remain available
  * processed-item landing-note fields:
    * `Triaged Date:`
    * `Triaged By:`
    * `Landing:`
    * `Retention: retained | superseded | moved-to-data | no-action | follow-up-needed`
    * `Superseded By:` when applicable
    * `Notes:`
* `docs/inbox/processed/README.md` exists as a placeholder and explains that processed items live there only after triage with a landing note.
* `docs/terminal_roles/planning.md` Required Behavior gains an explicit inbox-triage step alongside its existing Source of Truth reads.
* `docs/workflow_guide.md` gains a routing entry for external files or corrections pointing to `docs/inbox/`, and states the handoff-editing rule in human-facing language: draft handoffs can be edited directly; approved/completed handoffs cannot be rewritten and should receive corrections through the inbox, which leads to a superseding handoff when needed.
* `docs/terminal_protocol.md` Source of Truth / Standing Fitness Check list includes `docs/inbox/README.md`.
* `scripts/fitness_check.py` gains a 13th check, `check_inbox_items_triaged`: any direct child under `docs/inbox/` other than `README.md` and the `processed/` directory is a FAIL naming the item. `REQUIRED_DOCS` includes `docs/inbox/README.md`.
* `docs/questions.md` records the answered process question: how users should provide external files, corrections, and reference material for planning/execution.
* `docs/decisions.md` gains two new dated entries, both with `Decision:`, `Rationale:`, `Tradeoffs:`, and `Status: Accepted`:
  * command-terminal validation results must be recorded in `docs/run_log.md`
  * adopt `docs/inbox/` as supplemental external-input intake
* `python3 scripts/fitness_check.py` reports `Fitness checks: 13 run, 0 failed` after all changes.
* No analytics code, data models, reports, dashboards, analytical datasets, or git commit is introduced by this handoff.

## Files Expected To Change

* `scripts/fitness_check.py`
* `docs/terminal_roles/command.md`
* `docs/terminal_roles/planning.md`
* `docs/terminal_protocol.md`
* `docs/workflow_guide.md`
* `docs/decisions.md`
* `docs/questions.md`
* `docs/inbox/README.md` (new)
* `docs/inbox/processed/README.md` (new)
* `docs/active_context.md` (Current Repo State, Current Focus, Next Action, Current Decisions)
* `docs/run_log.md` (append/prepend only; do not rewrite prior entries)
* `docs/implementation_notes/013-fix-handback-and-inbox-intake.md` (new, written after execution)

## Files That Should Not Change

* Existing entries already in `docs/run_log.md`, `docs/decisions.md`, and `docs/questions.md` except for appending/prepending new entries.
* Anything under `src/f1_analytics/`, `sql/`, `outputs/`, `data/`, or existing analysis scripts.
* Handoffs 001-012.
* `scripts/workflow.py`. Workflow-router inbox awareness can be considered later if repeated use shows that the read-only status router needs it; this handoff only adds human-facing routing in `docs/workflow_guide.md`.

## Revision Note (2026-07-09)

Human review findings:

* `docs/inbox/` must be framed as supplemental, not as a replacement for current planning, execution, data, or documentation workflows.
* Some files may be easier to reference than paste into a prompt, and the inbox must support that.
* It is not yet proven that inbox material will affect only planning. The convention must allow execution or command use when a triaged item is referenced by an approved handoff or validation instruction.
* The intake format needs enough description that a user can fill it in without guessing.
* The retention/supersession discipline needs to be stronger: the project must know whether an input was stored for later use, moved, superseded, rejected/no-action, or left for follow-up.

Resolution:

This revision changes the inbox from a planning-only Markdown note idea into a supplemental intake convention that supports both single-note and file-bundle inputs. It makes planning responsible for raw triage, but allows execution and command terminals to use processed inbox material when approved workflow artifacts reference it. It also adds required/optional cover-sheet fields, examples to be written into `docs/inbox/README.md`, and processed-item landing-note fields that preserve the same durable-record discipline used elsewhere in the project.

## Relevant Project Context

A command-terminal handback showed the first concrete gap: command terminal ran `python3 scripts/fitness_check.py` and reported `Fitness checks: 12 run, 0 failed`, but because it returned the result without editing `docs/run_log.md`, the next planning-terminal session could not confirm a fresh recorded pass from the repo. That created avoidable ambiguity in a workflow whose source of truth is explicitly the repo, not chat.

The second gap comes from the same repo-first model. The project has durable places for decisions, questions, handoffs, run logs, implementation notes, raw datasets, and generated outputs, but it has no documented place for a human to add an external correction, reference file, short spec, or clarification before planning/execution begins. Without a convention, those inputs stay in chat or get mixed into the wrong artifact.

Handoff 010 already answered the related but distinct enablement question -- "which terminal do I use, can I edit this handoff, what do I do now" -- through `docs/workflow_guide.md` and `scripts/workflow.py`. This handoff does not reopen that design. It adds one missing intake lane to the existing Markdown workflow and one missing validation-completion signal to command-terminal work.

## Decisions Already Made

* Use the ADR supersede convention (`Supersedes`/`Superseded by`, frozen record bodies) for both `docs/decisions.md` and handoffs (`docs/decisions.md`, 2026-07-08).
* Use `python3`, not `python`, in all live repository documentation and prompt instructions (`docs/decisions.md`, 2026-07-08).
* Use `docs/workflow_guide.md` and the read-only `scripts/workflow.py` status router for intent-based terminal selection (`docs/decisions.md`, 2026-07-08; Handoff 010). This handoff adds one routing entry to the guide; it does not restructure the router.
* A richer TUI or web interface is not warranted yet. Extend the existing Markdown plus `fitness_check.py` convention only.
* Keep duplicated process facts canonical by topic and enforce pointers structurally via `scripts/fitness_check.py` / `scripts/workflow.py` (`docs/decisions.md`, 2026-07-08).

## Assumptions Not To Revisit

* The three-terminal model and the draft/approved handoff folder split are not being replaced.
* `docs/inbox/` is supplemental intake. It does not replace `docs/questions.md`, `docs/decisions.md`, handoffs, implementation notes, `data/raw/`, or generated outputs.
* Analytical datasets keep using `data/raw/<source>/` and the existing `data_sources/` loaders. If a user puts a dataset-like file in `docs/inbox/`, triage should move it to the correct data location or create a handoff to do so.
* `scripts/workflow.py` is not changed by this handoff.
* No git commit is introduced by this handoff.

## Implementation Steps

1. In `scripts/fitness_check.py`, add a small run-log recording helper that writes a compact Markdown entry near the top of `docs/run_log.md`, immediately after `# Run Log`.
   * The entry must include the current local timestamp, purpose, command, result summary, and a short issue line when failures are present.
   * Call the helper after all checks have printed and after the summary string is known, but before `main()` returns `0` or `1`.
   * Do not hide failed checks: a failing check still prints FAIL output and returns nonzero after recording the run-log entry.
2. Add `check_inbox_items_triaged()` to `scripts/fitness_check.py`: inspect direct children of `docs/inbox/`; exclude `README.md` and the `processed/` directory; any other direct child is a FAIL naming that item. This should fail for both direct files and direct folders, because both represent untriaged inbox items. Wire it into the `checks` list in `main()` as the 13th check. Add `"docs/inbox/README.md"` to `REQUIRED_DOCS`.
3. In `docs/terminal_roles/command.md`, reword Required Behavior step 4 from "Record or return results for `docs/run_log.md`." to mandatory language: validation results must be recorded in `docs/run_log.md` before the turn ends. Mention that `fitness_check.py` records itself automatically after this handoff and other validation commands must be recorded manually.
4. In `docs/terminal_protocol.md`, reword Handoff Lifecycle step 6 to name the command terminal as responsible for recording command and validation results in `docs/run_log.md`.
5. Create `docs/inbox/README.md` with the purpose, input shapes, filename/folder convention, cover-sheet fields, examples, ownership/access rules, triage destinations, and processed-item landing-note fields listed in Success Criteria.
6. Create `docs/inbox/processed/README.md` as a short placeholder explaining that processed inbox items are archived there after triage and must include a landing note.
7. Add one bullet for `docs/inbox/README.md` to `docs/terminal_protocol.md`'s `## Source of Truth / Standing Fitness Check` list, in the same style as existing bullets.
8. Add an inbox-triage step to `docs/terminal_roles/planning.md`'s `## Required Behavior` list: before other planning work, check `docs/inbox/` for untriaged items and route each item to the correct durable destination.
9. Add a routing entry to `docs/workflow_guide.md` for external files or corrections pointing at `docs/inbox/`. Include the handoff-editing rule: if the target is still a draft, revise the draft directly; if the target is approved/completed, file the correction through the inbox so planning can create a superseding handoff if needed. Also state that execution/command terminals may use processed inbox material when an approved handoff or validation instruction references it.
10. Add an answered question to `docs/questions.md` explaining how users should provide external files, corrections, and reference material for planning/execution.
11. Add two new dated entries to `docs/decisions.md` with `Decision:`/`Rationale:`/`Tradeoffs:`/`Status: Accepted`: one for mandatory run-log recording of command validation, one for adopting `docs/inbox/` as supplemental external-input intake.
12. Update `docs/active_context.md`: add `docs/inbox/` to Current Repo State, update Current Focus and Next Action, and add the two new decisions to Current Decisions.
13. Append or prepend a human-readable `docs/run_log.md` entry for this handoff's own commands and results, matching the existing run-log style. Keep prior entries intact. This manual entry is in addition to the automatic `fitness_check.py` entry created when validation runs.
14. Write `docs/implementation_notes/013-fix-handback-and-inbox-intake.md` following the standard format in `docs/implementation_notes/README.md`.

## Validation Commands

```bash
pwd
python3 scripts/fitness_check.py
grep -n "record or return" docs/terminal_roles/command.md
grep -n "docs/inbox" docs/workflow_guide.md docs/terminal_roles/planning.md docs/terminal_protocol.md docs/questions.md
ls docs/inbox
sed -n '1,80p' docs/run_log.md
git status --short
```

## Expected Outputs

* `python3 scripts/fitness_check.py` prints `Fitness checks: 13 run, 0 failed`.
* The `grep` for "record or return" in `docs/terminal_roles/command.md` returns no matches.
* The `grep` for `docs/inbox` returns matches in the workflow guide, planning role, terminal protocol, and questions log.
* `ls docs/inbox` shows only `README.md` and `processed/`.
* `sed -n '1,80p' docs/run_log.md` shows a fresh automatic entry from the `fitness_check.py` run above.
* `git status --short` shows only the files listed in Files Expected To Change, plus any pre-existing untracked state already present before execution.

## Stop Conditions

Stop if `docs/run_log.md`'s current structure cannot support a compact newest-first fitness-check entry without rewriting prior entries. Stop if adding the inbox check would require touching analytics code, data files, generated outputs, or a git commit. Stop if the routing addition to `docs/workflow_guide.md` would require restructuring its existing decision tree rather than adding one entry.

## What To Report Back

Files changed, `scripts/fitness_check.py` output before (`12 run, 0 failed`) and after (`13 run, 0 failed`), confirmation that `docs/run_log.md` received the auto-recorded fitness-check entry, confirmation that `docs/inbox/` contains only `README.md` and `processed/`, and confirmation that no analytics code, data files, generated outputs, or git commit were touched.
