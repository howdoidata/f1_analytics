• Current State

  - AGENTS.md exists at the project root and contains universal rules: repo as source of truth, read project context
    before changes, prefer simple maintainable solutions, record decisions and validation.

  - PROJECT.md exists and is strong: it defines purpose, audience, V1 goal, likely data direction, technical
    direction, standards, and non-goals.

  - docs/active_context.md exists but is stale. It says the repo only contains AGENTS.md, which is no longer true.
  - docs/decisions.md exists with one accepted decision: use repo Markdown as durable project memory.
  - docs/terminal_protocol.md exists and defines the three-terminal workflow.
  - docs/project_profile.md exists and gives deeper project context.
  - Terminal role docs exist, but at terminal_roles/, not docs/terminal_roles/.
  - Prompt files exist under docs/prompts/, but docs/prompts/planing_prompt.txt has a typo in the filename and points
    to docs/terminal_roles/planning.md, which does not currently exist.

  - The directory is not currently a Git repository.
  - Missing expected files/directories include docs/questions.md, docs/backlog.md, docs/run_log.md, docs/handoffs/,
    and docs/implementation_notes/.

  Gap Analysis

  - The proposed config mostly matches the project’s direction, but the actual file layout is inconsistent.
  - active_context.md is the highest-priority stale document because future terminals will read it and get the wrong
    project state.

  - Terminal-role docs are useful, but their location conflicts with the prompt files and proposed structure.
  - The terminal protocol lists docs/questions.md, docs/run_log.md, docs/handoffs/, and docs/implementation_notes/,
    but those do not exist yet.

  - PROJECT.md and docs/project_profile.md overlap somewhat, but that is acceptable if PROJECT.md stays concise and
    project_profile.md remains the extended reference.

  - Git should be initialized soon because the workflow depends on checking changes, preserving history, and
    separating planning/execution/validation artifacts.

  Recommended Minimal Setup

  Truly necessary before building code:

  - Root AGENTS.md
  - PROJECT.md
  - docs/active_context.md
  - docs/decisions.md
  - docs/questions.md
  - docs/backlog.md
  - docs/run_log.md
  - docs/terminal_protocol.md
  - docs/terminal_roles/planning.md
  - docs/terminal_roles/execution.md
  - docs/terminal_roles/command.md
  - docs/handoffs/README.md
  - docs/implementation_notes/README.md
  - Git initialized

  This is enough to keep terminal roles clear, preserve decisions, capture blockers, and pass execution-ready work
  between terminals without creating a heavy documentation system.

  What Not To Build Yet

  Delay these until the first real data/code handoff:

  - Full app/package scaffold
  - Airflow
  - dbt
  - dashboard folders
  - notebook templates
  - ML structure
  - data lake/raw/processed directory design
  - dependency files like requirements.txt or pyproject.toml
  - complex naming conventions
  - automated validation framework

  Those choices depend on inspecting the actual dataset and choosing the first V1 workflow.

  Project-Level vs Terminal-Level Rules

  Project-level rules belong in AGENTS.md when every agent/session must obey them:

  - repo is source of truth
  - read context before changing files
  - prefer simple maintainable solutions
  - record durable decisions
  - record validation evidence
  - do not rely on chat history

  Terminal/session-level rules belong in docs/terminal_roles/*.md:

  - planning terminal does not edit code
  - execution terminal implements only approved handoffs
  - command terminal runs listed commands and reports outputs
  - stop conditions for each terminal
  - what each terminal must read before acting

  PROJECT.md should hold stable project intent:

  - purpose
  - audience
  - V1 goal
  - technical direction
  - data direction
  - standards
  - non-goals

  docs/active_context.md should hold volatile state:

  - current phase
  - current filesystem/project state
  - active handoff
  - recent changes
  - current blockers
  - next expected action

  First Execution Handoff

  # Handoff 001: Normalize Project Context Scaffold

  Status: Completed

  ## Goal

  Bring the documentation scaffold into alignment with the intended context-control configuration before any
  application code is created.

  ## Success Criteria

  - Git is initialized in the project directory.
  - `docs/active_context.md` accurately reflects the current project state.
  - Missing planning docs and directories exist.
  - Terminal role docs live under `docs/terminal_roles/`.
  - Prompt files reference valid paths.
  - No application code, data pipeline, notebook, dashboard, or dependency scaffold is created.

  ## Files Expected To Change

  - `docs/active_context.md`
  - `docs/questions.md`
  - `docs/backlog.md`
  - `docs/run_log.md`
  - `docs/terminal_protocol.md`
  - `docs/terminal_roles/planning.md`
  - `docs/terminal_roles/execution.md`
  - `docs/terminal_roles/command.md`
  - `docs/handoffs/README.md`
  - `docs/implementation_notes/README.md`
  - `docs/prompts/planing_prompt.txt` or rename to `planning_prompt.txt`
  - `docs/prompts/execution_prompt.txt`
  - `docs/prompts/command_prompt.txt`

  ## Files To Preserve

  - `AGENTS.md`
  - `PROJECT.md`
  - `docs/decisions.md`
  - `docs/project_profile.md`

  ## Implementation Steps

  1. Run `git init` from the project root if `.git` does not exist.
  2. Create `docs/terminal_roles/`.
  3. Move or recreate the existing role docs from `terminal_roles/` into `docs/terminal_roles/`.
  4. Remove the old root `terminal_roles/` directory only after the copied files are verified.
  5. Fix prompt references so they point to `docs/terminal_roles/*.md`.
  6. Rename `docs/prompts/planing_prompt.txt` to `docs/prompts/planning_prompt.txt`.
  7. Create `docs/questions.md` with current open questions: stack, data source handling, first deliverable, project
  structure, and V1 output format.
  8. Create `docs/backlog.md` with deferred items: data ingestion, DuckDB design, dbt evaluation, Airflow later,
  dashboard later, ML later.
  9. Create `docs/run_log.md` with an initial entry for this scaffold validation.
  10. Create `docs/handoffs/README.md`.
  11. Create `docs/implementation_notes/README.md`.
  12. Update `docs/active_context.md` so it lists the actual scaffold and says no application code exists yet.
  13. Update `docs/terminal_protocol.md` only where paths or missing files need correction.

  ## Validation Commands

  ```bash
  pwd
  find . -maxdepth 4 -type f | sort
  git status --short

  ## Expected Output

  - Root contains AGENTS.md, PROJECT.md, docs/, and .git/.
  - docs/terminal_roles/ exists.
  - docs/handoffs/ exists.
  - docs/implementation_notes/ exists.
  - No app/source/data/notebook scaffold exists yet.

  ## Stop Conditions

  Stop if this directory appears to belong inside another Git repo, if moving files would delete unique content, or
  if any prompt/doc path cannot be reconciled cleanly.
