# Handoff 006: Data Source Foundation And Project Structure

Status: Completed

## Goal

Create a small reusable data foundation for multiple F1 analyses: document current and supplemental data sources, introduce a reusable project structure for shared queries/functions, add a database loading pattern for multiple sources, and create a visual project structure diagram.

## Success Criteria

* The existing Kaggle CSV workflow remains working.
* Jolpica/Ergast is documented as a supplemental source for filling gaps, not as a replacement for Kaggle.
* The project has a simple source registry that describes each data source, what it is used for, and where it lands in DuckDB.
* DuckDB has source-level metadata/audit tables for loaded local sources.
* Shared SQL and Python functions are moved or introduced in reusable locations instead of being trapped inside one-off scripts.
* The existing analysis scripts still run or have thin wrappers that preserve their command-terminal usage.
* A Mermaid visual diagram of the project structure exists in docs.
* Stale planning/backlog items are updated to reflect completed work.
* No dbt, Airflow, dashboard, notebook, or ML scaffold is introduced.

## Relevant Project Context

The project already has:

* KaggleHub setup and raw CSV download.
* Local raw CSVs under `data/raw/f1_complete_dataset/`.
* A processed DuckDB database at `data/processed/f1_analytics.duckdb`.
* First report outputs under `outputs/reports/` and `outputs/tables/`.
* Scripts for dataset build and championship-leader analysis.

The next problem is reuse. Current transformation and analysis logic lives mostly inside scripts. That is acceptable for the first deliverable, but it will become brittle as more analyses and data sources are added.

Jolpica/Ergast API root:

`https://api.jolpi.ca/ergast/?format=api`

The API root advertises endpoints for seasons, circuits, races, constructors, drivers, results, sprint, qualifying, pitstops, laps, driver standings, constructor standings, and status. Treat this as an optional supplemental source for missing or more current data after the Kaggle CSV baseline is loaded.

## Portions Not Yet Utilized

* `docs/backlog.md` is stale; it still describes data ingestion and first deliverable as not started.
* `docs/project_profile.md` is useful context but not yet reflected in code organization or architecture docs.
* `docs/prompts/` contains historical prompt files and is not part of the analytical workflow.
* Plotly is installed but no visualization has been created yet.
* dbt, Airflow, Tableau/dashboarding, notebooks, and ML remain intentionally unused.
* Jolpica/Ergast is not yet used.
* Reusable SQL, shared Python functions, source registry, and database load metadata do not exist yet.

## Cleanup Or Deprecation Needed

* Remove or keep ignored `.DS_Store` and `__pycache__` artifacts out of Git status noise; do not track them.
* Update stale backlog entries that say the first dataset and first deliverable are not started.
* Keep generated outputs ignored unless a later decision chooses to track selected portfolio artifacts.
* Do not delete current scripts; first refactor them into thin wrappers around reusable modules.
* Keep `docs/prompts/` for terminal convenience, but do not treat it as project architecture or analysis documentation.

## Files Expected To Change

* `requirements.txt`, only if adding a small HTTP dependency such as `requests`.
* `docs/active_context.md`
* `docs/questions.md`
* `docs/backlog.md`
* `docs/decisions.md`
* `docs/run_log.md`
* `docs/implementation_notes/006-data-source-foundation-and-project-structure.md`
* `docs/data_sources.md`
* `docs/architecture.md`
* `docs/diagrams/project_structure.mmd`
* `scripts/build_f1_dataset.py`
* `scripts/analyze_championship_leaders.py`

## Directories Expected To Be Created

* `src/f1_analytics/`
* `src/f1_analytics/data_sources/`
* `src/f1_analytics/analysis/`
* `src/f1_analytics/database/`
* `sql/`
* `sql/curated/`
* `sql/analysis/`
* `docs/diagrams/`

## Files Expected To Be Created

* `src/f1_analytics/__init__.py`
* `src/f1_analytics/config.py`
* `src/f1_analytics/data_sources/__init__.py`
* `src/f1_analytics/data_sources/kaggle_csv.py`
* `src/f1_analytics/data_sources/jolpica.py`
* `src/f1_analytics/database/__init__.py`
* `src/f1_analytics/database/duckdb_io.py`
* `src/f1_analytics/analysis/__init__.py`
* `src/f1_analytics/analysis/championship_leaders.py`
* `sql/curated/README.md`
* `sql/analysis/README.md`

## Files That Should Not Change

* `AGENTS.md`
* `PROJECT.md`
* `docs/terminal_protocol.md`
* `docs/terminal_roles/*`
* Existing approved handoffs
* Raw data files
* Generated DuckDB/output files except through documented rebuild commands

## Assumptions Not To Revisit

* Kaggle CSV remains the baseline source for Version 1.
* Jolpica/Ergast is supplemental and used for gap-fill or freshness checks.
* DuckDB remains the local analytical database.
* Shared Python goes under `src/f1_analytics/`.
* Reusable SQL goes under `sql/`.
* Architecture diagrams are stored as Mermaid text so they are reviewable in Git.

## Implementation Steps

1. Read `AGENTS.md`, `PROJECT.md`, `docs/active_context.md`, `docs/questions.md`, and this handoff.
2. Confirm this handoff is approved before implementing. Stop if it is still `Status: Draft` or still under `docs/handoffs/drafts/`.
3. Create the `src/f1_analytics/`, `sql/`, and `docs/diagrams/` structure listed above.
4. Add `src/f1_analytics/config.py` with project paths for raw data, processed data, outputs, DuckDB path, and source names.
5. Add `src/f1_analytics/database/duckdb_io.py` with small helpers for opening DuckDB connections, writing dataframes, and ensuring source metadata tables.
6. Add source metadata tables to DuckDB during the build:
   * `source_registry`
   * `source_load_log`
7. Add `src/f1_analytics/data_sources/kaggle_csv.py` for reusable raw CSV discovery/loading.
8. Add `src/f1_analytics/data_sources/jolpica.py` with a minimal client skeleton:
   * base URL `https://api.jolpi.ca/ergast/f1`
   * function for building endpoint URLs
   * function for fetching JSON with clear error messages
   * no large API pull yet unless needed for a lightweight smoke test
9. Refactor shared build logic from `scripts/build_f1_dataset.py` into reusable modules while keeping `scripts/build_f1_dataset.py` as the command-line entry point.
10. Refactor shared championship-leader analysis logic from `scripts/analyze_championship_leaders.py` into `src/f1_analytics/analysis/championship_leaders.py` while keeping the script as the command-line entry point.
11. Add `docs/data_sources.md` describing:
   * Kaggle CSV baseline source
   * Jolpica/Ergast supplemental API source
   * intended use cases for each
   * credential requirements
   * database landing tables
   * current gaps not filled yet
12. Add `docs/architecture.md` describing:
   * raw source layer
   * reusable Python modules
   * SQL directory
   * DuckDB processed database
   * analysis scripts
   * report/table outputs
13. Add `docs/diagrams/project_structure.mmd` with a Mermaid flowchart showing:
   * KaggleHub CSV source
   * Jolpica/Ergast API supplemental source
   * raw data
   * reusable Python source modules
   * SQL queries
   * DuckDB database
   * analysis scripts
   * output reports/tables
14. Add README files under `sql/curated/` and `sql/analysis/` explaining where reusable SQL should live.
15. Update `docs/backlog.md` so completed ingestion/build/report tasks are no longer listed as not started.
16. Update `docs/questions.md` so the additional data-source question is captured as answered or narrowed.
17. Update `docs/decisions.md` with a durable decision:
   * Kaggle CSV is baseline.
   * Jolpica/Ergast is supplemental for gap-fill/freshness.
   * Shared code lives under `src/f1_analytics/`; reusable SQL lives under `sql/`.
18. Update `docs/active_context.md` so the next action is command-terminal validation of the refactored build and analysis commands.
19. Record implementation notes in `docs/implementation_notes/006-data-source-foundation-and-project-structure.md`.
20. Append a concise entry to `docs/run_log.md` listing validation commands to run.

## Data Source Rules

* Do not overwrite Kaggle raw files with API responses.
* Store supplemental API responses separately if they are persisted later, for example under `data/raw/jolpica/`.
* Load each source into DuckDB with a source prefix or metadata record so provenance remains clear.
* Prefer explicit merge/gap-fill tables over silently mutating baseline tables.
* Any future gap-fill rule must state which source wins when Kaggle and Jolpica disagree.

## Query And Function Storage Rules

* Reusable Python functions belong under `src/f1_analytics/`.
* Script files under `scripts/` should be thin command-line wrappers.
* Reusable SQL belongs under `sql/curated/` or `sql/analysis/`.
* One-off report formatting can stay in analysis modules until it is reused.
* Avoid adding dbt until repeated SQL models justify it.

## Diagram Rules

* Store the primary diagram as Mermaid text at `docs/diagrams/project_structure.mmd`.
* Link or embed that diagram from `docs/architecture.md`.
* Do not generate image files yet unless a later deliverable needs them.

## Command Terminal Validation Commands

Run these from the project root:

```bash
pwd
source .venv/bin/activate
python -m compileall scripts src
python scripts/build_f1_dataset.py
python scripts/analyze_championship_leaders.py
test -f data/processed/f1_analytics.duckdb && echo "duckdb built"
test -f outputs/reports/championship_leader_conversion.md && echo "report built"
test -f docs/diagrams/project_structure.mmd && echo "diagram exists"
python - <<'PY'
from pathlib import Path
required = [
    Path("docs/data_sources.md"),
    Path("docs/architecture.md"),
    Path("docs/diagrams/project_structure.mmd"),
    Path("src/f1_analytics/config.py"),
    Path("src/f1_analytics/data_sources/jolpica.py"),
    Path("src/f1_analytics/database/duckdb_io.py"),
]
missing = [str(path) for path in required if not path.exists()]
if missing:
    raise SystemExit(f"missing expected files: {missing}")
print("foundation files present")
PY
git status --short
```

## Expected Outputs

* Existing build and analysis commands still work.
* Shared Python modules exist under `src/f1_analytics/`.
* SQL folders exist with clear README guidance.
* `docs/data_sources.md` explains Kaggle and Jolpica roles.
* `docs/architecture.md` links to or embeds the Mermaid diagram.
* `docs/diagrams/project_structure.mmd` exists.
* DuckDB contains or can create source metadata/audit tables.
* No dashboard, notebook, dbt, Airflow, or ML structure is created.

## Stop Conditions

Stop if:

* This handoff is still in `docs/handoffs/drafts/`.
* This handoff still has `Status: Draft`.
* Refactoring would break the existing report-generation commands.
* Jolpica requires authentication, payment, or a materially different API path than documented.
* Adding the source registry would require a larger schema decision than this handoff defines.
* The implementation would introduce dbt, Airflow, dashboarding, notebooks, or ML.

## What To Report Back

Report:

* Files changed.
* Whether existing build/report scripts still work.
* Where shared Python functions now live.
* Where reusable SQL should live.
* What DuckDB source metadata tables were added.
* Where the project diagram is stored.
* Any Jolpica API limitations or follow-up questions.
