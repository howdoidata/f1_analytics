# Handoff 011: Consolidate Terminal-Role and Handoff-Schema Duplication

Status: Completed

## Goal

Fix the specific class of drift this project has already experienced twice -- the required-docs list independently hand-typed in both `docs/terminal_protocol.md` and `scripts/fitness_check.py`'s `REQUIRED_DOCS`, and the execution terminal being called "Execution Codex" in two files but plain "Execution" everywhere else -- by giving every duplicated process fact exactly one canonical location (colocated by topic, not a single global file), trimming every other living doc to a pointer or its non-duplicated remainder, and extending `scripts/fitness_check.py` with checks that mechanically catch this category of drift going forward. This does not introduce generation/codegen (facts stay hand-edited at their canonical location); it only adds detection. Historical/frozen records (`docs/decisions.md` entries, `docs/handoffs/approved/*`, `docs/implementation_notes/*`, `docs/run_log.md`, `docs/prompts/planning/archive/*`) are out of scope and must not be edited -- rewriting them would violate the project's own ADR frozen-record convention, not follow it.

## Success Criteria

* Seven duplicated fact-families (required-docs list; terminal naming; handoff required-field list; handoff status enum; execution stop-conditions/approval-gate rule; per-terminal required-reading list; terminal purpose/routing descriptions) each have exactly one canonical location, listed under Implementation Steps.
* Every terminal name in every living doc matches its canonical name in `docs/terminal_roles/{role}.md` exactly, with no qualifier appended -- enforced structurally by `check_terminal_names_consistent()` (Implementation Step 10), not by banning a specific word. "Codex" is the one currently-known violation of this rule, not the rule itself; if a tool name legitimately needs to be referenced somewhere later, the rule doesn't block that, it only blocks it from being appended to a terminal's canonical name.
* `docs/terminal_protocol.md` no longer contains a `Use this terminal for:` heading anywhere (`grep -n "Use this terminal for:" docs/terminal_protocol.md` returns nothing) -- that content now lives solely in `docs/terminal_roles/*.md`.
* `docs/terminal_roles/command.md` has a "Required Inputs" section (previously missing entirely -- a gap, not just duplication).
* `docs/terminal_roles/execution.md`'s Stop Conditions section is the union of its current list and `docs/terminal_protocol.md`'s current list (includes `Needs Revision` status and the command-fails-in-a-way-that-changes-implementation-path condition, both currently only in the `terminal_protocol.md` copy).
* `scripts/fitness_check.py` gains six new check functions (listed under Implementation Steps) and `python3 scripts/fitness_check.py` reports `12 run, 0 failed` after all changes.
* `scripts/workflow.py`'s `run_fitness_checks()` imports and includes all six new checks (its import line already hand-lists specific function names from `fitness_check.py`, so this must be updated in the same commit as the new checks -- forgetting it is a fresh instance of the exact bug this handoff fixes).
* No analytics code, data models, reports, dashboards, terminal-count/renumbering changes, or a codegen/templating mechanism is introduced by this handoff.

## Files Expected To Change

* `docs/terminal_roles/execution.md` -- becomes canonical for stop-conditions/approval-gate rule and required-reading list.
* `docs/terminal_roles/command.md` -- gains a new "Required Inputs" section (content sourced from `docs/prompts/command_prompt.txt`).
* `docs/handoffs/README.md` -- becomes canonical for the handoff status enum; line 5 trimmed to a pointer for the required-field list.
* `docs/terminal_protocol.md` -- trimmed to short per-terminal summaries plus pointers to `docs/terminal_roles/*.md`; "Execution Codex" heading fixed to match its canonical name in `docs/terminal_roles/execution.md` (no qualifier appended); duplicated lists removed.
* `docs/active_context.md` -- "Execution Codex terminal" wording fixed.
* `docs/workflow_guide.md` -- capability-list phrasing in the decision tree shortened to illustrative tags; routing structure kept.
* `docs/prompts/execution_prompt.txt`, `docs/prompts/command_prompt.txt` -- restated required-reading lists replaced with pointers to the relevant `docs/terminal_roles/*.md` section.
* `scripts/workflow.py` -- `INTENT_ROUTES` values trimmed to pointer strings; `run_fitness_checks()` import/list updated for the six new checks.
* `scripts/fitness_check.py` -- six new check functions added; `main()`'s checks list updated.
* `docs/decisions.md` -- new dated entry recording this consolidation (append only).
* `docs/questions.md`, `docs/active_context.md` (Current Focus/Next Action/Current Decisions/Current Repo State), `docs/run_log.md` -- standard completion housekeeping.
* `docs/implementation_notes/011-consolidate-terminal-role-duplication.md` (new).

## Files That Should Not Change

* `docs/decisions.md` entries that already exist (append only; frozen bodies).
* `docs/handoffs/approved/*`, `docs/implementation_notes/001` through `010`, `docs/run_log.md` existing entries, `docs/prompts/planning/archive/*` -- historical/frozen records.
* `docs/prompts/planning/session_prompt.txt` -- already the model pointer-only pattern (`"Adopt the planning role only. See docs/terminal_roles/planning.md."`), nothing to trim.
* `docs/terminal_protocol.html`, `docs/workflow_guide.html` -- stray hand-exported artifacts, not governed by any script or prompt; out of scope for this handoff (candidate backlog item: delete or establish a real build step).
* Anything under `src/f1_analytics/`, `sql/`, `outputs/`, `data/`, or existing analysis scripts.
* The three-terminal count/model itself -- no renumbering or role-splitting. This handoff only removes duplication of facts as they exist today.

## Relevant Project Context

Handoff 009 established the standing fitness check and consolidated the required-docs checklist into `docs/terminal_protocol.md` as canonical -- but `scripts/fitness_check.py`'s `REQUIRED_DOCS` constant remained a second, independently hand-typed copy with nothing checking the two agree. Handoff 010 added `scripts/workflow.py` as a second consumer of the same checklist. Reviewing `docs/terminal_protocol.md` end to end surfaced that this same "one fact restated by hand in N places, nothing checks agreement" shape recurs at least six more times: the execution terminal is called "Execution Codex" in `docs/terminal_protocol.md` and `docs/active_context.md` but plain "Execution" everywhere else; the handoff required-field list and status enum are each independently restated in `docs/terminal_protocol.md` and `docs/handoffs/README.md`; the execution stop-conditions list exists as three overlapping-but-not-identical copies (two of them in the same file, `docs/terminal_protocol.md` lines 75 and 141-153); the per-terminal required-reading list is restated in four places and is missing entirely for the command role; and each terminal's purpose/responsibilities is independently restated in `docs/terminal_protocol.md`, each `docs/terminal_roles/*.md`, `docs/workflow_guide.md`, and `scripts/workflow.py`'s `INTENT_ROUTES`.

## Decisions Already Made

* Treat the setup-comparison check as a standing, mechanically-verified fitness function (`docs/decisions.md`, Handoff 009 decisions) -- this handoff extends that same script rather than introducing a new mechanism.
* Use the ADR supersede convention and frozen-record rule for `docs/decisions.md` and handoffs (`docs/decisions.md`, Handoff 009 decisions) -- this handoff's historical-records exclusion list follows directly from that rule.
* Use `docs/workflow_guide.md` and `scripts/workflow.py` for intent-based terminal selection and status reporting (`docs/decisions.md`, Handoff 010 decisions) -- both are edited here, not replaced.
* Generation/codegen of duplicate files from a canonical data source was explicitly considered and rejected for this scope -- drift detection only, facts stay hand-edited at their canonical location.

## Assumptions Not To Revisit

* The three-terminal model, terminal names, and the draft/approved handoff folder split are not being changed, renumbered, or split by this handoff.
* Canonical locations are chosen per fact, colocated by topic (e.g. role responsibilities in `docs/terminal_roles/*.md`, not a single global manifest file) -- this was an explicit user requirement, not a simplification to revisit.
* New fitness checks can only catch structural drift (a missing pointer, a regrown list, a mismatched enum) -- they cannot detect paraphrased prose drift. This is a known, accepted limit without generation and is not a defect to fix in this handoff.
* `docs/terminal_protocol.html` and `docs/workflow_guide.html` are out of scope; do not delete, regenerate, or otherwise touch them here.

## Implementation Steps

1. `docs/terminal_roles/execution.md`: merge Stop Conditions with `docs/terminal_protocol.md`'s current list (add `Needs Revision` status and the command-fails condition). This file becomes canonical for the stop-conditions/approval-gate fact and the execution required-reading list.
2. `docs/terminal_roles/command.md`: add a "## Required Inputs" section (`AGENTS.md`, `PROJECT.md`, `docs/active_context.md`, assigned handoff in `docs/handoffs/approved/`), sourced from `docs/prompts/command_prompt.txt`. Closes the current gap where the command role has no such section at all.
3. `docs/handoffs/README.md`: trim the restated handoff-field sentence (line 5) to a pointer at `docs/terminal_protocol.md`'s "Handoff Requirements". Leave "## Status" as-is -- it becomes canonical for the handoff status enum.
4. `docs/terminal_protocol.md`: retitle `### Terminal 2: Execution Codex` to `### Terminal 2: Execution` (canonical name, no qualifier appended, per the naming rule below); delete the three "Use this terminal for:" bullet lists (now solely in the role docs); delete Terminal 2's numbered reading list and restated restriction sentences; replace the literal handoff-status enumeration with a pointer to `docs/handoffs/README.md`; replace the restated Stop Conditions list with a pointer to `docs/terminal_roles/execution.md`; keep one short summary per terminal plus an explicit `docs/terminal_roles/{x}.md` pointer. Leave the "Planning output should usually become one of:" list in place, untouched -- out of scope for this handoff (see Assumptions Not To Revisit).
5. `docs/active_context.md`: fix "Execution Codex terminal" to "Execution terminal" in the Current Operating Model section.
6. `docs/workflow_guide.md`: shorten the near-verbatim capability-list phrases in the decision tree to brief illustrative tags; add one preface sentence noting `docs/terminal_roles/*.md` are authoritative for exact responsibilities. Keep the routing/question structure.
7. `docs/prompts/execution_prompt.txt`: change "Adopt the execution role only." to "Adopt the role contract in `docs/terminal_roles/execution.md`." (matching the pattern the other two prompt files already use); delete the restated 4-item reading list, replace with a one-line note that required reading is defined in the adopted role contract.
8. `docs/prompts/command_prompt.txt`: same treatment -- delete the restated reading list, replace with a pointer to `command.md`'s new "Required Inputs" section.
9. `scripts/workflow.py`: replace `INTENT_ROUTES` values with short pointer strings that don't restate capability lists (e.g. `"architecture": "Planning terminal -- see docs/terminal_roles/planning.md."`).
10. `scripts/fitness_check.py`: add six new check functions:
    * `check_required_docs_matches_protocol_list()` -- parse `docs/terminal_protocol.md`'s "Source of Truth / Standing Fitness Check" section, extract backtick path spans, compare against `REQUIRED_DOCS` with directory-prefix-aware matching (a prose entry ending in `/` covers any `REQUIRED_DOCS` entry under that prefix).
    * `check_terminal_names_consistent()` -- derive canonical role names from each `docs/terminal_roles/*.md` H1 (strip trailing " Role"); regex-match `docs/terminal_protocol.md`'s `### Terminal N: <name>` headings and fail if a trailing qualifier is present that isn't the canonical name itself (this is what catches "Execution Codex" -- no hardcoded word list, purely structural: canonical name, optionally nothing else); apply the same shape check to `docs/active_context.md`'s Current Operating Model list. No denylist of specific words -- a legitimate future mention of a tool name elsewhere in prose is not what this check restricts.
    * `check_handoff_status_enum_consistent()` -- parse `docs/handoffs/README.md`'s "## Status" bullet list, compare against `HANDOFF_STATUSES`; assert `docs/terminal_protocol.md` has no differing itemized enumeration.
    * `check_role_docs_have_required_inputs()` -- assert each `docs/terminal_roles/*.md` has a "Required Inputs"/"Source of Truth" H2 containing at least `AGENTS.md`, `PROJECT.md`, `docs/active_context.md`.
    * `check_prompts_point_to_role_docs()` -- assert each of the three prompt files references its own correct `docs/terminal_roles/(planning|execution|command)\.md` path.
    * `check_terminal_protocol_sections_stay_pointers()` -- assert each Terminal-N subsection in `docs/terminal_protocol.md` contains a `docs/terminal_roles/` reference and no `Use this terminal for:` heading has regrown.
    Wire all six into `main()`'s checks list.
11. `scripts/workflow.py`: update `run_fitness_checks()`'s import line and checks list to include the six new functions.
12. Add a new dated decision entry to `docs/decisions.md` describing this consolidation (per the pattern of prior entries; do not edit any existing entry).
13. Update `docs/active_context.md` (Current Repo State, Current Focus, Next Action, Current Decisions) and append an entry to `docs/run_log.md` for this handoff's commands and results.
14. Write `docs/implementation_notes/011-consolidate-terminal-role-duplication.md` following the standard format used by prior implementation notes.

## Validation Commands

```bash
pwd
python3 scripts/fitness_check.py
python3 scripts/workflow.py
python3 scripts/workflow.py --intent architecture
grep -rn "Codex" docs/ --include="*.md" --include="*.txt"
grep -n "Use this terminal for:" docs/terminal_protocol.md
grep -c "Required Inputs" docs/terminal_roles/command.md
grep -n "^Status" docs/handoffs/drafts/011-consolidate-terminal-role-duplication.md
git status --short
```

## Expected Outputs

* `Fitness checks: 12 run, 0 failed`.
* `scripts/workflow.py` runs without error and reports a clean fitness summary; `git status --short` unchanged by running it.
* The `Codex` grep (excluding frozen paths and stray `.html` files) returns nothing -- a spot check confirming the one known naming-rule violation is gone, not the rule's enforcement mechanism (that's `check_terminal_names_consistent()`).
* The `Use this terminal for:` grep returns nothing.
* `grep -c "Required Inputs" docs/terminal_roles/command.md` returns `1` or more.
* Adding the six new checks against the current, unfixed docs (before applying steps 1-10) should make each new check **fail** with a specific detail string -- run and capture this before editing, to prove the checks actually detect today's real drift rather than trivially passing.

## Stop Conditions

Stop if a new check can't be made to fail against the pre-fix state (means it isn't testing anything real); if fixing a check would require editing a file listed under "Files That Should Not Change"; if closing the command-role required-reading gap surfaces that the four terminal-role files disagree on required reading in a way not resolvable by simple union; or if this work would require renumbering/splitting the terminal roles themselves (out of scope, a separate open question).

## What To Report Back

Files changed, the six new check names with a one-line description of what each parses/compares, `scripts/fitness_check.py` output before (`6 run, 0 failed`) and after (`12 run, 0 failed`) all changes, output of the pre-fix "each new check fails" run, and confirmation of both grep sweeps returning nothing.

## Revision Note (2026-07-08)

This draft has carried `Status: Needs Revision` without a Revision Note because, until this handoff, no process required one for a draft that never left `docs/handoffs/drafts/` -- only the approved-handoff revise procedure in `docs/terminal_protocol.md` required this artifact. The original clarifying question(s) or assumption(s) that led to this status were not recorded at the time and were subsequently lost during later edits to this draft; they cannot be reconstructed. This note is added retroactively as the first real use of the Revision Note requirement introduced by Handoff 012, so this draft's status is no longer unexplained going forward. Before this draft can move to `Status: Approved`, the open question(s) behind its `Needs Revision` status must be re-established (by re-review against `docs/terminal_protocol.md` and the Stop Conditions already listed in this file) and resolved.

### Re-review addendum (2026-07-08)

Since the original open question could not be reconstructed, this draft was re-reviewed from scratch against the current live content of every file it references (`docs/terminal_protocol.md`, `docs/handoffs/README.md`, all three `docs/terminal_roles/*.md`, all three `docs/prompts/*` files, `scripts/fitness_check.py`, `scripts/workflow.py`, `docs/decisions.md`, `docs/questions.md`). All seven duplicated fact-families named in this handoff's Relevant Project Context are still real and unresolved in the repo today; none of the Assumptions Not To Revisit have been invalidated by Handoffs 009, 010, or 012. The Stop Conditions below were checked explicitly and none trigger -- in particular, the four terminal-role files' required-reading lists were compared directly and do not disagree in a way blocking a simple union. No open question or needed change was found. Status is moved to `Approved` unchanged; no body edits were made, consistent with this project's frozen-record convention for approved handoffs.
