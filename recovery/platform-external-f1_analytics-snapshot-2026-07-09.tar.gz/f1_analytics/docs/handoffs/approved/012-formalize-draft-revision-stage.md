# Handoff 012: Formalize the Draft-Revision Evaluation Stage

Status: Completed

## Goal

Close a gap in the Handoff Lifecycle (`docs/terminal_protocol.md`): a fully-specified procedure exists for sending an *approved* handoff back for changes ("Revising vs. superseding a handoff" -- flip status, move to `drafts/`, append a dated Revision Note), but there is no equivalent procedure for a draft that never left `docs/handoffs/drafts/`. Handoff Lifecycle step 2 is just "User reviews or edits the draft" -- no definition of what that review entails, no requirement to raise clarifying questions or flag assumptions, and no required artifact recording why a draft was sent back. `docs/handoffs/drafts/011-consolidate-terminal-role-duplication.md` is live proof: it carries `Status: Needs Revision` with no Revision Note, and the reasoning behind that status was never recorded and is no longer recoverable. This handoff (a) generalizes the existing Revising-vs-superseding procedure to cover drafts still in `drafts/`, (b) adds a minimal structural check enforcing the Revision Note requirement, and (c) retroactively applies the new requirement to 011 as its first real use. This does not introduce a new mechanism -- it reuses and extends the Revision Note artifact and the existing `check_handoff_statuses()` function, consistent with this project's detection-only fitness-check philosophy.

## Success Criteria

* `docs/terminal_protocol.md`'s Handoff Lifecycle step 2 and "Revising vs. superseding a handoff" section define what evaluating a draft means (raising clarifying questions / flagging assumptions) and require a dated `## Revision Note` section whenever a draft is set to `Status: Needs Revision`, whether or not it was ever approved.
* `scripts/fitness_check.py`'s existing `check_handoff_statuses()` fails any handoff with `Status: Needs Revision` that has no `## Revision Note` section -- enforced as one additional condition inside the existing function, not a new check function, and not a new entry in `main()`'s checks list.
* `docs/handoffs/drafts/011-consolidate-terminal-role-duplication.md` has a dated `## Revision Note` section added (existing content untouched) so it passes the newly-strict check.
* `python3 scripts/fitness_check.py` reports the same check count as before this handoff (no new check added, one existing check extended) with 0 failed.
* No new mechanism, folder, status value, or check function is introduced. No content-quality/substance evaluation of clarifying questions is added -- only structural presence of the Revision Note section is enforced.

## Files Expected To Change

* `docs/handoffs/drafts/011-consolidate-terminal-role-duplication.md` -- a dated `## Revision Note` section appended; no existing content deleted or edited.
* `docs/terminal_protocol.md` -- Handoff Lifecycle step 2 (line 98) and the "Revising vs. superseding a handoff" section (lines 130-139) edited to cover drafts that never left `drafts/`.
* `scripts/fitness_check.py` -- `check_handoff_statuses()` (lines 69-93) gains one additional condition.
* `docs/decisions.md` -- new dated entry recording this decision (append only).
* `docs/questions.md`, `docs/active_context.md` (Current Focus/Next Action/Current Decisions/Current Repo State), `docs/run_log.md` -- standard completion housekeeping.
* `docs/implementation_notes/012-formalize-draft-revision-stage.md` (new).

## Files That Should Not Change

* `docs/handoffs/README.md` -- already points to `docs/terminal_protocol.md`'s procedure rather than restating it (line 27); the new rule should not be duplicated there.
* `docs/decisions.md` entries that already exist (append only; frozen bodies).
* `docs/handoffs/approved/*`, existing `docs/implementation_notes/*`, existing `docs/run_log.md` entries -- historical/frozen records.
* `scripts/workflow.py` -- no new check function is added, so its `run_fitness_checks()` import/list needs no change.
* `scripts/fitness_check.py`'s `main()` checks list and every check function other than `check_handoff_statuses()` -- unaffected.
* Any existing content within `docs/handoffs/drafts/011-consolidate-terminal-role-duplication.md` other than the appended Revision Note -- 011's own scope (fact-duplication/fitness-checks) is untouched by this handoff.
* Anything under `src/f1_analytics/`, `sql/`, `outputs/`, `data/`, or existing analysis scripts.

## Relevant Project Context

The Handoff Lifecycle in `docs/terminal_protocol.md` already defines a `Needs Revision` status and, in "Revising vs. superseding a handoff," a fully worked procedure for sending an *approved* handoff back for changes: flip its status, move it back to `drafts/`, and append a dated Revision Note describing the open question or needed change without deleting original content. That procedure is explicitly framed around "while reading an approved handoff" -- it does not address a draft that never left `drafts/` in the first place. Handoff Lifecycle step 2 ("User reviews or edits the draft") is the only place a not-yet-approved draft's review is mentioned, and it says nothing about what that review entails or what artifact, if any, should exist when the draft is sent back for changes.

`docs/handoffs/drafts/011-consolidate-terminal-role-duplication.md` sits at `Status: Needs Revision` today with no Revision Note anywhere in the file. The reasoning that produced that status was never written down and was subsequently lost during later edits to the draft -- there is nothing to recover. This is the exact failure the Revision Note convention exists to prevent for approved handoffs, and it happened here precisely because the convention's scope never covered drafts still in `drafts/`.

`scripts/fitness_check.py`'s `check_handoff_statuses()` (introduced per Handoff 009's decision to make the required-docs/status checks a standing, mechanically-verified fitness function) already reads every handoff's `Status:` line and validates it against `HANDOFF_STATUSES`/`DRAFT_FOLDER_STATUSES`/`APPROVED_FOLDER_STATUSES`. It does not currently look at any content beyond the `Status:` line itself, so it has no way to detect a `Needs Revision` handoff missing its Revision Note.

Handoff 011 (currently `Status: Needs Revision`, unapproved) also edits `docs/terminal_protocol.md` and `scripts/fitness_check.py`, but in different subsections: 011 touches the Terminal Roles section, naming, and stop-conditions text, and adds six new check functions; this handoff touches the Handoff Lifecycle section and extends one existing check function. Overlap in the same two files is expected; direct line conflicts are unlikely given the different subsections, but whichever of 011 or 012 is executed second should re-verify the line references below still match current file state before editing.

## Decisions Already Made

* Treat `check_handoff_statuses()` (and the standing fitness check generally) as a mechanically-verified, continually-run check rather than a one-time bootstrap step (`docs/decisions.md`, Handoff 009 decisions) -- this handoff extends that same function rather than introducing a new mechanism.
* Use the ADR supersede/revise convention and frozen-record rule for handoffs (`docs/decisions.md`, Handoff 009 decisions; "Revising vs. superseding a handoff" in `docs/terminal_protocol.md`) -- this handoff generalizes that existing convention's scope rather than replacing it.
* Detection-only fitness checks: checks catch structural drift, not content-quality drift (established explicitly in Handoff 011's Decisions Already Made and Assumptions Not To Revisit) -- this handoff's Revision Note check follows the same limit: it verifies a section exists, not that its content is adequate.

## Assumptions Not To Revisit

* This only structurally enforces the *presence* of a `## Revision Note` section when `Status: Needs Revision` -- it does not, and is not intended to, evaluate the quality, completeness, or substance of the clarifying questions or assumptions written inside that section. That evaluation remains a human/Planning-terminal judgment call, consistent with every other check in `scripts/fitness_check.py`.
* No new check function, no new `CheckResult`, and no change to `main()`'s checks list or `scripts/workflow.py`'s imports -- the existing `check_handoff_statuses()` function is extended in place. If implementing this turns out to require touching `scripts/workflow.py`, that is a signal the design assumption here was wrong and the handoff should stop (see Stop Conditions).
* The three-terminal model, handoff status enum, and draft/approved folder split are not being changed by this handoff -- only the Needs-Revision sub-procedure is being generalized and enforced.
* 011's own scope (fact-duplication, terminal naming, the six new check functions it introduces) is not touched or re-litigated here beyond appending its Revision Note.

## Implementation Steps

1. `docs/handoffs/drafts/011-consolidate-terminal-role-duplication.md`: append a new section at the end of the file:

   ```
   ## Revision Note (2026-07-08)

   This draft has carried `Status: Needs Revision` without a Revision Note because, until this handoff, no process required one for a draft that never left `docs/handoffs/drafts/` -- only the approved-handoff revise procedure in `docs/terminal_protocol.md` required this artifact. The original clarifying question(s) or assumption(s) that led to this status were not recorded at the time and were subsequently lost during later edits to this draft; they cannot be reconstructed. This note is added retroactively as the first real use of the Revision Note requirement introduced by Handoff 012, so this draft's status is no longer unexplained going forward. Before this draft can move to `Status: Approved`, the open question(s) behind its `Needs Revision` status must be re-established (by re-review against `docs/terminal_protocol.md` and the Stop Conditions already listed in this file) and resolved.
   ```

   Do not edit, delete, or reorder any existing content in the file -- append only.

2. `docs/terminal_protocol.md`, Handoff Lifecycle step 2 (currently line 98: "User reviews or edits the draft."): replace with:

   ```
   2. User reviews the draft -- raising clarifying questions and checking its stated assumptions -- and either approves it or, if it is not yet ready, marks it `Status: Needs Revision` and appends a dated Revision Note (see "Revising vs. superseding a handoff" below) describing the open question(s) or assumption(s) that must be resolved before approval.
   ```

3. `docs/terminal_protocol.md`, "Revising vs. superseding a handoff" section (lines 130-139): broaden its opening sentence and add explicit handling for a draft that was never approved. Replace the opening sentence (line 132: "If, while reading an approved handoff, you have a question, find something unclear, or it needs a small change -- ask one question first:") with:

   ```
   If, while reading any handoff still eligible for revision -- a draft in `docs/handoffs/drafts/` under `Status: Draft` or `Status: Needs Revision`, or an approved handoff not yet executed -- you have a question, find something unclear, or it needs a small change, ask one question first:
   ```

   Then, immediately after the existing "No"/"Yes" bullet pair (after line 137, before the closing paragraph at line 139), add:

   ```
   If the handoff is already in `docs/handoffs/drafts/` and was never approved, no file move is required: set (or keep) `Status: Needs Revision` directly and append the dated Revision Note in place, describing the open question(s) or assumption(s) blocking approval. Edit the draft to resolve them, then set `Status: Approved` (moving it to `docs/handoffs/approved/`) once resolved.
   ```

   Leave the rest of the section (the existing "No"/"Yes" bullets, and the closing paragraph defining "`Needs Revision` is `Draft` with a paper trail") unchanged.

4. `scripts/fitness_check.py`, inside `check_handoff_statuses()` (lines 69-93): in the per-file loop, after the existing `elif status not in expected_statuses:` branch (line 88-89), add one more condition checked whenever `status == "Needs Revision"`:

   ```python
   if status == "Needs Revision" and not REVISION_NOTE_RE.search(text):
       problems.append(f"{rel}: status 'Needs Revision' but no Revision Note section found")
   ```

   Add a module-level pattern near `STATUS_LINE_RE`/`SUPERSEDE_RE` (around line 42-43):

   ```python
   REVISION_NOTE_RE = re.compile(r"^##\s*Revision Note", re.MULTILINE)
   ```

   This is one additional branch inside the existing function -- no new `CheckResult`, no new function, no change to `main()`'s checks list.

5. `docs/decisions.md`: append a new dated entry following the existing format (Decision / Rationale / Tradeoffs / Status), describing this generalization of the Revision Note requirement to drafts and the minimal `check_handoff_statuses()` extension, per the pattern of the two most recent entries.

6. Update `docs/active_context.md` (Current Repo State, Current Focus, Next Action, Current Decisions) and append an entry to `docs/run_log.md` for this handoff's commands and results.

7. Write `docs/implementation_notes/012-formalize-draft-revision-stage.md` following the standard format used by prior implementation notes.

## Validation Commands

```bash
pwd
python3 scripts/fitness_check.py
python3 scripts/workflow.py
grep -n "Revision Note" docs/handoffs/drafts/011-consolidate-terminal-role-duplication.md
grep -n "^Status" docs/handoffs/drafts/011-consolidate-terminal-role-duplication.md
grep -n "REVISION_NOTE_RE" scripts/fitness_check.py
git status --short
```

## Expected Outputs

* `Fitness checks: N run, 0 failed` where `N` matches the count before this handoff (no new check added; `check_handoff_statuses()` is one of the existing checks, now stricter).
* `grep -n "Revision Note" docs/handoffs/drafts/011-consolidate-terminal-role-duplication.md` returns at least one match.
* Before appending 011's Revision Note (i.e., testing step 4 against 011's pre-fix state), running the newly-extended `check_handoff_statuses()` should report 011 as a problem (`status 'Needs Revision' but no Revision Note section found`) -- capture this to prove the new condition actually detects the real gap, then re-run after step 1 to confirm it passes.
* `scripts/workflow.py` runs without error; `git status --short` unchanged by running it.

## Stop Conditions

Stop if extending `check_handoff_statuses()` would require also touching `scripts/workflow.py`'s imports or `main()`'s checks list -- that would mean this was implemented as a new check rather than an extension of the existing one, contradicting this handoff's scope. Stop if 011 has already been approved and executed by the time this handoff is picked up (re-check its `Status:` line and folder location first) -- if so, re-verify the line references in Implementation Steps 2-4 against the current state of `docs/terminal_protocol.md` and `scripts/fitness_check.py` before editing, since 011's own changes may have shifted them. Stop if the Revision Note text for 011 (Implementation Step 1) needs to say anything more specific than "the original reasoning was lost" -- that would require information this handoff does not have, and inventing a substantive technical reason would misrepresent the historical record.

## What To Report Back

Files changed, confirmation that `check_handoff_statuses()` was extended in place (not a new function), the fitness check count before and after (should be equal), the pre-fix/post-fix output of the check run against 011 specifically, and confirmation that no existing content in 011 or in `docs/handoffs/README.md` was altered.
