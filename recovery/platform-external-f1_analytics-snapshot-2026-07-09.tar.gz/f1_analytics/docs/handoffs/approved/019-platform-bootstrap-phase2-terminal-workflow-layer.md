# Handoff 019: Platform Bootstrap — Phase 2 (Terminal Workflow Layer)

Status: Approved

Project: platform

## Revision Note 2026-07-10 : A dry run against the real `TARGET_DIR` stopped before writing anything, having found that Gate 2's placeholder/hedge-phrase checks scanned the entire `docs/` tree, including the Phase 0-1 files this phase must not touch. `docs/multi_project_operating_model.md`'s `## Not Yet Built` heading (correctly written in Phase 1) contains the substring "not yet," so the original broad check would always fail Phase 2 through no fault of anything Phase 2 creates. Gate 2 and the Validation Commands below are corrected to scope those two checks to only the files this phase creates. Moved back to drafts per the revise-in-place procedure since no part of this handoff had executed.

## Goal

Add a three-terminal workflow layer to the existing platform scaffold (Phases 0-1 already built): role contracts, a terminal protocol document, a workflow guide, a handoff lifecycle convention with empty draft/approved folders, an implementation-notes convention, an inbox-intake convention, three reusable session-start prompt templates, and an initial `docs/active_context.md`. Nothing else.

Everything from "Execution Contract" onward must be followable by a system with no access to this repository's history, decisions, or logged context — only this document and the `TARGET_DIR` parameter below.

## Success Criteria

See Gate 2 below — that checklist is the complete, sole definition of done for this phase.

## Assumptions Not To Revisit

* Do not create `scripts/fitness_check.py`, `scripts/workflow.py`, or any other script in this phase — those belong to Phase 3.
* Do not create `projects/` or `exchange/` directories in this phase — those belong to Phase 4.
* Do not modify any file or directory that already exists in `TARGET_DIR` from Phases 0-1.
* `TARGET_DIR` is the same directory Phases 0-1 built into; it already contains the root scaffold plus the nine `docs/` governance files before this phase starts.
* Do not consult, copy, or paraphrase this repository's own workflow documents. Write `TARGET_DIR`'s versions fresh, using this handoff's own instructions as the sole source of required content.
* None of the new documents may state or imply that `scripts/fitness_check.py`, `scripts/workflow.py`, or any other mechanical enforcement already runs. State plainly, without hedging, that a later phase adds that tooling.

## Inputs (set by the user before execution)

| Parameter | Meaning | Value for this run |
|---|---|---|
| `TARGET_DIR` | Existing platform directory Phases 0-1 built into | `/Users/antonio/Documents/howdoidata/projects/platform` |

## Files Expected To Change (in this repository)

None.

## Files That Should Not Change (in this repository)

Everything. This repository is read-only for the purpose of this handoff.

---

# THE SPECIFICATION

Everything below this line is the self-contained Phase 2 build instruction. It assumes no other context.

## Execution Contract

1. Confirm `TARGET_DIR` exists and contains exactly `.git/`, `AGENTS.md`, `PROJECT.md`, `.gitignore`, `docs/` at its root, and that `TARGET_DIR/docs/` contains exactly the nine files `decisions.md`, `questions.md`, `backlog.md`, `run_log.md`, `asset_inventory.md`, `architecture_principles.md`, `architecture_operating_model.md`, `analysis_output_standards.md`, `multi_project_operating_model.md`, before doing anything else. If anything is missing or anything extra is present, stop and report — do not add, remove, or modify anything to force a match.
2. Perform the steps below in order. Do not add files or directories beyond what is listed.
3. Where this specification states a requirement in prose, write original text satisfying that requirement. Do not leave bracketed placeholders, "TBD," or lorem-ipsum-style filler. Every sentence must be real, substantive content a reader could act on.
4. Do not reference any specific project, product, dataset, vendor, or client anywhere in the files you write.
5. Where a document would naturally reference mechanical tooling that does not exist yet (a fitness-check script, a status-router script), state plainly that a later phase adds it and describe the manual alternative for now. Do not use hedge phrases ("for now," "not yet," "currently empty") elsewhere for intentionally empty sections; state the append or population mechanism plainly instead.

## Steps

1. Create `docs/terminal_roles/` and inside it:

   **`planning.md`**:
   * `## Your Role` — state responsibility for architecture reasoning, scope decisions, tradeoff analysis, and writing draft handoffs.
   * `## Hard Restrictions` — must not edit project code or create source files; must not run implementation steps; must not place a handoff into an approved location without explicit user approval; must not ask whether to implement a plan or offer to implement it.
   * `## Handoff File Rules` — may create or update files under a drafts location only when explicitly instructed; may not place files into an approved location unless the user explicitly says the work is approved.
   * `## Required Behavior` — read relevant context; check any inbox/intake area for untriaged items before other planning work; identify a recommended path; produce a planning answer; if explicitly instructed, create or update a draft handoff; stop after the handoff.
   * `## Source of Truth` — before planning, read `AGENTS.md`, `PROJECT.md`, `docs/active_context.md`, `docs/decisions.md`, `docs/questions.md`.

   **`execution.md`**:
   * `## Your Role` — responsible for implementing approved handoffs only.
   * `## Required Inputs` — `AGENTS.md`, `PROJECT.md`, `docs/active_context.md`, the assigned handoff file from an approved location.
   * `## Hard Restrictions` — must not revisit architecture decisions unless blocked; must not expand scope; must not create files outside the approved scope; must not run unrelated commands; must not make product or architecture decisions on its own; must not execute a draft handoff.
   * `## Required Behavior` — read the assigned handoff; confirm it is in the approved location and not `Draft` or `Needs Revision`; confirm expected files; implement only the requested changes; record what changed in the implementation-notes location; state what validation commands should be run.
   * `## Stop Conditions` — handoff conflicts with `AGENTS.md`; handoff is `Draft` or `Needs Revision`, or located in a drafts location; required files are missing; repo state does not match the handoff; a command fails in a way that changes the implementation path; the task requires a new decision; implementation would exceed the approved scope.

   **`command.md`**:
   * `## Your Role` — responsible for running commands, installs, and validation steps.
   * `## Required Inputs` — same four as execution's.
   * `## Hard Restrictions` — must not make architecture decisions; must not edit files unless specifically instructed; must not change implementation strategy; must not install anything not listed in the handoff; must not run commands outside validation or setup scope.
   * `## Required Behavior` — read the assigned handoff; run only the listed commands unless the user approves more; capture command outputs; record validation results in the run-log document before the turn ends.
   * `## Stop Conditions` — a command fails; a command asks for credentials or payment; a command would modify files outside expected scope; the environment does not match the handoff's assumptions.

2. Create `docs/terminal_protocol.md`:
   * `## Purpose` — state that this document defines the three-terminal workflow, the handoff lifecycle, and the completion rules that keep planning, execution, and validation separated with the repository as source of truth.
   * `## Source Of Truth` — list the documents that together define project state as of this phase: `AGENTS.md`, `PROJECT.md`, `docs/decisions.md`, `docs/questions.md`, `docs/backlog.md`, `docs/run_log.md`, `docs/asset_inventory.md`, `docs/architecture_principles.md`, `docs/architecture_operating_model.md`, `docs/analysis_output_standards.md`, `docs/multi_project_operating_model.md`, `docs/active_context.md`, `docs/terminal_protocol.md` itself, `docs/terminal_roles/`, `docs/workflow_guide.md`, `docs/handoffs/README.md`, `docs/handoffs/drafts/`, `docs/handoffs/approved/`, `docs/implementation_notes/`, `docs/inbox/README.md`. State plainly, directly beneath the list, that mechanically checking this list against repo state is added by a later phase; until then, treat it as a manual reference to confirm at the start of a session.
   * `## Terminal Roles` — one paragraph each pointing to `docs/terminal_roles/planning.md`, `execution.md`, and `command.md` as authoritative.
   * `## Handoff Lifecycle` — a numbered list: planning creates or updates a draft only when explicitly instructed; the user reviews and either approves it or marks it `Needs Revision` with a dated revision note; an approved handoff moves to the approved location; execution implements only that handoff; command runs its validation commands; execution records an implementation note and command records validation results; planning updates `docs/active_context.md` and, if needed, `docs/decisions.md`, `docs/questions.md`, or `docs/backlog.md`.
   * `## Handoff Requirements` — list the required fields every handoff must include: Handoff ID, Status, Goal, Success criteria, Files expected to change, Files that should not change, Relevant project context, Decisions already made, Assumptions not to revisit, step-by-step implementation instructions, validation commands, expected outputs, stop conditions, and what to report back.
   * `## Decision And Handoff Status` — state the ADR-style lifecycle (`Draft`/`Proposed` → `Approved`/`Accepted` → `Completed`, `Rejected`, or `Superseded`) and that a frozen record's body is never rewritten once accepted or approved; only its status line may later change.
   * `## Revising Vs. Superseding A Handoff` — state the binary fork: if no part of a handoff has executed yet, revise it in place (set `Needs Revision`, move it back to the drafts location if it had been approved, append a dated revision note, and correct the same file); if any part has executed, leave the original untouched and create a new handoff with the next sequential ID that supersedes it.
   * `## Context Refresh Rule` — before starting any task, confirm current repo state, the current active handoff, relevant decisions, and open blockers; do not rely only on prior conversation memory.
   * `## Completion Rule` — a task is not complete until the intended files were changed, validation commands were run or clearly marked as not run, results were recorded, blockers were documented, and `docs/active_context.md` reflects the new state.

3. Create `docs/workflow_guide.md`:
   * State this guide routes work into the three-terminal workflow by intent; the terminal role documents remain authoritative for exact responsibilities.
   * A decision tree covering at least: architecture/scope/tradeoff questions → planning terminal; a new analysis or feature question → planning terminal first for scoping; external files, corrections, or reference material → the inbox-intake convention; implementing an approved handoff → execution terminal; running commands, installs, or validation → command terminal; changing an existing handoff → the revise-vs-superseding procedure in `docs/terminal_protocol.md`.
   * A closing statement that a later phase adds a status-router script for automatically answering "what do I do now"; until then, check `docs/active_context.md` and the approved-handoffs location manually.

4. Create `docs/handoffs/README.md`:
   * State this directory stores handoffs from the planning terminal, and that required fields are defined in `docs/terminal_protocol.md`.
   * `## Locations` — a drafts location for proposed handoffs awaiting review, and an approved location for execution-ready handoffs; execution must only implement handoffs from the approved location.
   * `## Status` — every handoff must include a `Status:` line; valid values are `Draft`, `Needs Revision`, `Approved`, `Completed`, `Rejected`, `Superseded`; a superseded handoff keeps its original body and gets a `Superseded by:` line, with the newer handoff carrying a matching `Supersedes:` line.

5. Create empty directories `docs/handoffs/drafts/` and `docs/handoffs/approved/`. Do not place any file inside either.

6. Create `docs/implementation_notes/README.md`:
   * State this directory stores concise notes from completed execution handoffs.
   * A standard format list: handoff ID and status; a plain-language summary; files changed grouped by purpose; commands run and whether they passed; outputs produced, if any, and where to find them; assumptions made, if any; known limitations; follow-up recommendations.

7. Create `docs/inbox/README.md`:
   * State that this is a supplemental intake area for external files, corrections, short specs, questions, and reference material that need to influence planning or execution, and that it is not a replacement for the decision, question, backlog, or handoff documents.
   * Supported input shapes: a single Markdown intake note, or a small file bundle with a cover-sheet `README.md`.
   * Required cover-sheet fields (`Date:`, `Intent:`, `Summary:`, `Requested Use:`) and the allowed `Intent:` values (`correction`, `new-context`, `question`, `data-spec`, `reference-material`).
   * Ownership: planning owns triage and checks this location before other planning work; execution and command may use a processed item only after planning has triaged it and an approved handoff references it.
   * Triage destinations: `docs/questions.md`; `docs/decisions.md` (using supersession when it contradicts an accepted decision); direct edits to a draft handoff; a new handoff superseding an approved or completed one; a project's own storage location once project directories exist (see `docs/multi_project_operating_model.md`); or retained reference material in a processed location.

8. Create empty directory `docs/inbox/processed/`. Do not place any file inside it.

9. Create `docs/prompts/planning_prompt.txt`:
   * A reusable session-start block: adopt the planning role from `docs/terminal_roles/planning.md`; have the command terminal run the standing fitness check first (state plainly that a later phase adds a mechanical script for this — until then, manually compare repo state against `docs/terminal_protocol.md`'s source-of-truth list); use `docs/workflow_guide.md` to confirm terminal choice; do not act on process findings directly, they become entries in `docs/decisions.md` per the supersede convention.
   * A trailing fill-in guide (marked as removable) showing where the session's specific topic or task is added below the reusable block.

10. Create `docs/prompts/execution_prompt.txt`:
    * A reusable session-start block: adopt the execution role from `docs/terminal_roles/execution.md`; read the required inputs the role defines plus the assigned approved handoff; implement only that handoff; do not revisit architecture decisions or expand scope; if blocked, stop and explain; after implementation, report files created, files changed, commands run, and any issues or deviations; use `docs/workflow_guide.md` to confirm terminal choice.
    * A trailing fill-in guide showing where the exact approved-handoff filename is substituted.

11. Create `docs/prompts/command_prompt.txt`:
    * A reusable session-start block: adopt the command role from `docs/terminal_roles/command.md`; read the required inputs the role defines plus the assigned approved handoff; run only the validation commands listed in the handoff; do not make implementation or architecture decisions; return command output for recording in `docs/run_log.md`; use `docs/workflow_guide.md` to confirm terminal choice.
    * A trailing fill-in guide showing where the exact approved-handoff filename is substituted, and a note that the standing fitness check can also be run here once a later phase adds its script.

12. Create `docs/active_context.md`:
    * `## Project` — state plainly that this repository is a shared, reusable operating platform for running multiple independent projects, not a single project itself.
    * `## Current Repo State` — list what exists at the root and under `docs/` as of this phase: the root scaffold, the nine governance documents, and the terminal-workflow documents this phase just added (name them).
    * `## Current Focus` — state plainly that the terminal workflow layer was just added, and that no decisions, questions, or handoffs have been recorded yet because none have been needed so far.
    * `## Current Operating Model` — describe the three terminals (planning, execution, command) in one sentence each, and state that the repository is the source of truth, not conversation history.
    * `## Open Questions` — point to `docs/questions.md`.
    * `## Next Action` — state plainly that mechanical fitness-check and workflow-router tooling are added by a later phase; until then, confirm state by reading the documents listed above directly.

13. Do not run any further steps. Stop here.

## Gate 2 (must pass before this phase is reported complete)

* `docs/terminal_roles/` contains exactly `planning.md`, `execution.md`, `command.md`.
* `docs/terminal_protocol.md`, `docs/workflow_guide.md`, and `docs/active_context.md` exist at the root of `docs/`.
* `docs/handoffs/` contains exactly `README.md`, an empty `drafts/`, and an empty `approved/`.
* `docs/implementation_notes/` contains exactly `README.md`.
* `docs/inbox/` contains exactly `README.md` and an empty `processed/`.
* `docs/prompts/` contains exactly `planning_prompt.txt`, `execution_prompt.txt`, `command_prompt.txt`.
* Every file and directory from Phases 0-1 (`AGENTS.md`, `PROJECT.md`, `.gitignore`, and the nine `docs/` governance files) is unchanged.
* None of the files created in this phase (Steps 1-12 above) name a specific project, dataset, vendor, or product.
* None of the files created in this phase state or imply that a fitness-check or workflow-router script already exists or already runs; each reference instead states plainly that a later phase adds it.
* None of the files created in this phase contain an unresolved placeholder token (e.g. literal `[fill in]`, `TBD`, `{{...}}`, or `lorem ipsum`).
* None of the files created in this phase use hedge phrases ("for now," "not yet," "currently empty") for an intentionally empty section; each states its population mechanism plainly instead. Pre-existing Phase 0-1 files (including `docs/multi_project_operating_model.md`'s `## Not Yet Built` heading) are out of scope for this check — they predate this phase and must not be modified.

If any condition fails, fix it within this phase and re-check the full Gate before reporting completion. Do not report success with a failing or unchecked condition.

## Validation Commands (run from this repository's command terminal, against the external `TARGET_DIR`)

```bash
find "$TARGET_DIR/docs" -mindepth 1 | sort
test -d "$TARGET_DIR/docs/handoffs/drafts" && find "$TARGET_DIR/docs/handoffs/drafts" -mindepth 1 | wc -l   # expect 0
test -d "$TARGET_DIR/docs/handoffs/approved" && find "$TARGET_DIR/docs/handoffs/approved" -mindepth 1 | wc -l   # expect 0
test -d "$TARGET_DIR/docs/inbox/processed" && find "$TARGET_DIR/docs/inbox/processed" -mindepth 1 | wc -l   # expect 0
for f in decisions questions backlog run_log asset_inventory architecture_principles architecture_operating_model analysis_output_standards multi_project_operating_model; do
  test -f "$TARGET_DIR/docs/$f.md" && echo "$f.md still present"
done
# Scope these two checks to only the files this phase creates -- Phase 0-1 files
# (e.g. docs/multi_project_operating_model.md's "## Not Yet Built" heading) are
# frozen and must not be re-validated against a rule introduced after they existed.
NEW_FILES="$TARGET_DIR/docs/terminal_roles/planning.md $TARGET_DIR/docs/terminal_roles/execution.md $TARGET_DIR/docs/terminal_roles/command.md $TARGET_DIR/docs/terminal_protocol.md $TARGET_DIR/docs/workflow_guide.md $TARGET_DIR/docs/handoffs/README.md $TARGET_DIR/docs/implementation_notes/README.md $TARGET_DIR/docs/inbox/README.md $TARGET_DIR/docs/active_context.md $TARGET_DIR/docs/prompts/planning_prompt.txt $TARGET_DIR/docs/prompts/execution_prompt.txt $TARGET_DIR/docs/prompts/command_prompt.txt"
grep -niE "\[fill in\]|TBD|\{\{|lorem ipsum" $NEW_FILES; echo "exit=$? (expect 1, no matches)"
grep -niE "for now|not yet|currently empty" $NEW_FILES; echo "exit=$? (expect 1, no matches)"
git status --short   # this repository: expect no output, nothing changed
```

## Expected Outputs

* `TARGET_DIR/docs/` gains `terminal_roles/`, `terminal_protocol.md`, `workflow_guide.md`, `handoffs/` (with empty `drafts/`/`approved/`), `implementation_notes/`, `inbox/` (with empty `processed/`), `prompts/`, and `active_context.md`.
* `TARGET_DIR`'s Phase 0-1 files are untouched.
* This repository shows no changes in `git status`.

## Stop Conditions

Stop if:

* This handoff is still `Status: Draft` or `Status: Needs Revision` and has not been explicitly (re-)approved and moved to `docs/handoffs/approved/`.
* `TARGET_DIR` does not already contain exactly the Phase 0-1 fileset at the start.
* Completing the Gate would require adding any file or directory not listed in the Steps above — that means a later phase's work is being pulled forward; stop and report rather than expanding scope.
* Any file ends up naming a specific project, dataset, or vendor, claims mechanical tooling already exists when it does not, or contains an unresolved placeholder or hedge phrase — fix it before reporting completion; if it cannot be fixed without adding out-of-scope content, stop and report why.

## What To Report Back

* Full contents of all new files.
* Gate 2 command outputs, condition by condition.
* Confirmation this repository was not modified.
* Anything that required a judgment call not explicitly covered by the Steps above (so it can be tightened before Phase 3 is drafted).
