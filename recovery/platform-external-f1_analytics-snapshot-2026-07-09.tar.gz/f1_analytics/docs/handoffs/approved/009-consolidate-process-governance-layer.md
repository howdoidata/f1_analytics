# Handoff 009: Consolidate Process Governance Layer

Status: Completed

## Goal

Consolidate the duplicated "compare current setup against proposed config" checklist into one canonical standing fitness check, add the standard ADR supersede convention to decisions and handoffs, define one explicit revise-vs-supersede procedure for handoffs, add copy/paste helper text to the command prompt, and add an automated script that mechanically checks these invariants instead of relying on a human-read checklist.

## Success Criteria

* `docs/terminal_protocol.md` holds one canonical "Source of Truth / Standing Fitness Check" list; no other file duplicates it.
* `docs/decisions.md` and `docs/handoffs/README.md` support `Supersedes:`/`Superseded by:` fields and an extended Status enum (`Draft`, `Needs Revision`, `Approved`, `Completed`, `Rejected`, `Superseded`).
* A written, binary (has-execution-started?) procedure exists for revising vs. superseding a handoff.
* `docs/prompts/planning/` contains exactly one active template; the seven retired prompt files (including the stray `docs/planning_prompt8.txt`) are archived, not deleted.
* `docs/prompts/command_prompt.txt` has a placeholder legend distinguishing fixed text from per-session fill-ins.
* `scripts/fitness_check.py` exists and exits non-zero if any invariant above is violated.
* No analytics application code, build scripts, or data pipeline files change.

## Files Expected To Change

* `docs/terminal_protocol.md`
* `docs/decisions.md`
* `docs/handoffs/README.md`
* `docs/handoffs/approved/001-normalize-project-context-scaffold.md` (add missing `Status:` line)
* `docs/handoffs/approved/002-cleanup-project-scaffold.md` (add missing `Status:` line)
* `docs/prompts/planning/session_prompt.txt` (new)
* `docs/prompts/planning/archive/` (new)
* `docs/prompts/command_prompt.txt`
* `docs/active_context.md`
* `scripts/fitness_check.py` (new)
* `docs/run_log.md`

## Files That Should Not Change

* Any file under `src/f1_analytics/`, `sql/`, or existing `scripts/*.py` other than the new `fitness_check.py`.
* `outputs/`, `data/`.
* Handoffs 003-008 (already have a valid `Status:` line; left untouched).

## Relevant Project Context

Planning sessions were repeatedly opening with a full setup-comparison checklist duplicated across seven prompt files (`docs/prompts/planning/planning_prompt.txt` through `planning_prompt6.txt`, plus a stray `docs/planning_prompt8.txt`), because findings from that check had no governed path to become durable process decisions. Separately, there was no defined procedure for handling a question or needed change on an approved-but-not-yet-executed handoff.

## Decisions Already Made

See the five new/updated entries in `docs/decisions.md` dated 2026-07-08: superseding the Kaggle/Jolpica decision pair, adopting the fitness-function framing, adopting the ADR supersede convention, adopting the revise-vs-supersede fork, and consolidating the planning prompt files.

## Assumptions Not To Revisit

* The three-terminal model (planning/execution/command) and the draft/approved handoff folder split are sound and are not being replaced.
* `docs/decisions.md` remains append-only for record bodies; only Status lines are ever updated after the fact.

## Implementation Steps

1. Write `scripts/fitness_check.py` (required docs exist, handoff status validity, supersede referential integrity, no stray prompt files, decision entries well-formed).
2. Run it against the pre-change repo state to confirm it detects real drift (stray `docs/planning_prompt8.txt`, missing `Status:` lines on handoffs 001/002).
3. Add missing `Status: Completed` lines to handoffs 001 and 002.
4. Update `docs/terminal_protocol.md`: consolidate the Source of Truth list, label it the standing fitness check, add the Decision and Handoff Status section with the revise-vs-supersede procedure.
5. Update `docs/handoffs/README.md`: extend the Status enum, reference the revise-vs-supersede procedure.
6. Update `docs/decisions.md`: retrofit the Jolpica decision pair with `Superseded by:`/`Supersedes:`, append four new process decision entries.
7. Create `docs/prompts/planning/session_prompt.txt`; move the seven retired prompt files into `docs/prompts/planning/archive/`.
8. Add the placeholder legend to `docs/prompts/command_prompt.txt`.
9. Update `docs/active_context.md` (Current Repo State, Current Focus, Current Decisions, Current Approved Documents, Next Action).
10. Re-run `scripts/fitness_check.py`; confirm all checks pass.
11. Record this handoff's commands and results in `docs/run_log.md`.

## Validation Commands

```bash
pwd
python3 scripts/fitness_check.py
find docs/prompts/planning -type f | sort
test -f docs/planning_prompt8.txt && echo "still present" || echo "stray file gone"
grep -n "Supersedes\|Superseded by" docs/decisions.md docs/handoffs/README.md
git status --short
```

## Expected Outputs

* `Fitness checks: 5 run, 0 failed` after all edits.
* `docs/prompts/planning/` contains `session_prompt.txt` and `archive/` (with 7 files) and nothing else.
* `docs/planning_prompt8.txt` no longer exists at the repo root's `docs/`.
* `Supersedes`/`Superseded by` references present in `docs/decisions.md` and `docs/handoffs/README.md`.

## Stop Conditions

Stop if any application/analytics file would need to change to satisfy this handoff, or if the fitness check cannot be made to pass without weakening one of its five checks.

## What To Report Back

Files changed, the fitness-check output before and after the doc edits, and confirmation that no analytics code was touched.
