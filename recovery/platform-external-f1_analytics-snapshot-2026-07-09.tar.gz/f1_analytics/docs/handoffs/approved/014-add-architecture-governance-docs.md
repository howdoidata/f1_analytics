# Handoff 014: Add Architecture Governance Documents

Status: Completed

## Goal

Create the project's first lightweight architecture-governance documentation set and introduce it into the operating workflow.

This handoff implements three planning recommendations informed by:

* `docs/inbox/processed/2026-07-09-build-models.md`
* `docs/inbox/processed/2026-07-09-build-principles.md`

The purpose is not to build a heavy governance program. The purpose is to move the project from implicit architecture discipline to explicit, lightweight Level 1 / early Level 2 controls: a visible asset inventory, a clear change operating model, and project-specific architecture principles that future work can reference.

## Planning Summary

What should exist after implementation:

1. `docs/asset_inventory.md`
   * A simple Markdown table of important project assets.
   * Fields: asset id, type, purpose, owner/role, status, criticality, dependencies, consumers, validation, last reviewed, notes.
   * Initial rows should cover the current critical process, documentation, workflow, data, source, analysis, script, SQL, and generated-output asset groups already present in the repo.
   * Unknowns should be marked explicitly as `Unknown` or `TBD`; do not invent consumers, owners, run history, or validation that the repo does not support.

2. `docs/architecture_operating_model.md`
   * Defines how architecture changes happen in this project.
   * Covers decision flow, handoff flow, validation flow, inbox triage, backlog entry rules, review cadence, and how an asset moves from idea to active, deprecated, superseded, or retired.
   * Explains how work enters `docs/backlog.md` or later roadmap-style planning:
     * backlog for concrete deferred work, risks, cleanup, validation gaps, and retirement candidates.
     * decisions for durable policy/architecture/tool/source choices.
     * questions for unresolved blockers.
     * handoffs for execution-ready implementation tasks.

3. `docs/architecture_principles.md`
   * Short project-specific principles, not a generic manifesto.
   * Should include principles such as:
     * keep source boundaries explicit.
     * do not merge data sources without documented precedence rules.
     * validate reusable tables and workflows.
     * defer tooling until repeated need justifies it.
     * keep documentation close to the work and repo-owned.
     * make generated outputs reproducible before polishing dashboards or ML.
     * record meaningful decisions with rationale and tradeoffs.
     * prefer small, reversible changes.

How these docs should become part of project administration:

* Add all three docs to the `docs/terminal_protocol.md` Source of Truth / Standing Fitness Check list.
* Add all three docs to `scripts/fitness_check.py` `REQUIRED_DOCS` so missing governance docs are mechanically detected.
* Add workflow guidance in `docs/workflow_guide.md` so planning uses these docs when architecture, operating model, inventory, or governance questions arise.
* Add a durable decision in `docs/decisions.md` adopting the lightweight architecture governance documentation set.
* Add an answered question in `docs/questions.md` explaining how architecture governance findings enter backlog, questions, decisions, or handoffs.
* Update `docs/backlog.md` so architecture-governance work has a visible backlog/admin home without creating a separate roadmap file in this handoff.
* Update `docs/active_context.md` so the current repo state and decisions mention the new governance docs.

## Success Criteria

* `docs/asset_inventory.md` exists and includes:
  * a short purpose section.
  * allowed lifecycle/status values: `Draft`, `Active`, `Deprecated`, `Superseded`, `Retired`, `Unknown`.
  * allowed criticality values: `High`, `Medium`, `Low`, `Unknown`.
  * the required table columns exactly: `Asset ID`, `Type`, `Purpose`, `Owner/Role`, `Status`, `Criticality`, `Dependencies`, `Consumers`, `Validation`, `Last Reviewed`, `Notes`.
  * initial inventory rows for at least these asset groups:
    * project charter/context docs.
    * terminal workflow/process docs.
    * handoff folders.
    * inbox/processed reference-material flow.
    * decisions/questions/backlog/run log.
    * implementation notes.
    * raw Kaggle source files.
    * raw Jolpica cached source.
    * processed DuckDB database.
    * reusable Python modules under `src/f1_analytics/`.
    * command scripts under `scripts/`.
    * reusable SQL under `sql/`.
    * generated reports/tables/figures under `outputs/`.
  * unknown or not-yet-applicable values are explicit; do not hide gaps.
* `docs/architecture_operating_model.md` exists and defines:
  * scope and purpose.
  * roles of planning, execution, and command terminals.
  * decision flow.
  * handoff flow.
  * validation flow.
  * inbox triage flow.
  * backlog entry rules.
  * review cadence:
    * per-change review.
    * lightweight monthly inventory/backlog review.
    * quarterly architecture direction review.
  * asset lifecycle and disposition values: `Keep`, `Improve`, `Merge`, `Deprecate`, `Supersede`, `Retire`, `Investigate`.
  * explicit rule that architecture findings produce concrete destinations: decision, question, backlog item, draft handoff, inventory update, or no-action note.
* `docs/architecture_principles.md` exists and contains a concise set of project-specific principles with short rationale for each principle.
* `docs/terminal_protocol.md` Source of Truth / Standing Fitness Check list includes:
  * `docs/asset_inventory.md`
  * `docs/architecture_operating_model.md`
  * `docs/architecture_principles.md`
* `scripts/fitness_check.py` `REQUIRED_DOCS` includes the three new docs.
* `docs/workflow_guide.md` points architecture/governance users to the three new docs without restructuring the existing decision tree.
* `docs/decisions.md` gets one new dated entry with `Decision:`, `Rationale:`, `Tradeoffs:`, and `Status: Accepted` for adopting lightweight architecture governance docs.
* `docs/questions.md` records the answered question: how architecture governance findings and audit observations enter backlog, questions, decisions, or handoffs.
* `docs/backlog.md` gets a new architecture-governance section that records immediate follow-up items without changing existing completed/deferred analytics items.
* `docs/active_context.md` is updated to include the new docs in Current Repo State and Current Decisions.
* `docs/run_log.md` gets a human-readable entry for this handoff's implementation and validation commands. The automatic `fitness_check.py` entry should also appear when validation runs.
* `docs/implementation_notes/014-add-architecture-governance-docs.md` is created after execution.
* `python3 scripts/fitness_check.py` reports `Fitness checks: 13 run, 0 failed` after all changes.
* No analytics code, data models, generated reports, dashboards, analytical datasets, or git commit is introduced by this handoff.

## Files Expected To Change

* `docs/asset_inventory.md` (new)
* `docs/architecture_operating_model.md` (new)
* `docs/architecture_principles.md` (new)
* `scripts/fitness_check.py`
* `docs/terminal_protocol.md`
* `docs/workflow_guide.md`
* `docs/decisions.md`
* `docs/questions.md`
* `docs/backlog.md`
* `docs/active_context.md`
* `docs/run_log.md` (append/prepend only; do not rewrite prior entries)
* `docs/implementation_notes/014-add-architecture-governance-docs.md` (new)

## Files That Should Not Change

* Anything under `src/f1_analytics/`.
* Anything under `sql/`.
* Anything under `data/`.
* Anything under `outputs/`.
* Existing analysis scripts or data-loading scripts, except `scripts/fitness_check.py`.
* Existing handoffs 001-013.
* `scripts/workflow.py`; router enhancements can be considered later if these docs prove useful enough to expose through the CLI.
* `docs/inbox/processed/2026-07-09-build-models.md` and `docs/inbox/processed/2026-07-09-build-principles.md`; they have already been triaged and retained.

## Relevant Project Context

The project now has a strong process foundation: role contracts, handoffs, decision records, questions, run logs, implementation notes, inbox triage, and a standing process fitness check.

The project does not yet have a lightweight architecture-governance layer that answers:

* What assets exist?
* Which assets are important?
* Which assets have owners, validation, and consumers?
* How do architecture findings become decisions, questions, backlog items, or handoffs?
* Which principles should guide future additions such as dbt, Airflow, dashboards, or ML?

The processed inbox references recommend a maturity-based approach: start with Level 1 visibility, avoid overbuilding, and add Level 2 repeatability only where it helps current project administration.

## Decisions Already Made

* Use repo Markdown as durable project memory.
* Use separate planning, execution, and command terminals.
* Use `docs/handoffs/drafts/` for proposed handoffs and `docs/handoffs/approved/` for approved execution-ready handoffs.
* Use the ADR supersede convention for decisions and handoffs.
* Treat `python3 scripts/fitness_check.py` as the standing process fitness check.
* Use `docs/inbox/` as supplemental external-input intake, with raw triage owned by planning.
* Keep duplicated process facts canonical by topic and enforce structural pointers with fitness checks.
* Keep Version 1 lightweight: no heavy infrastructure, no premature orchestration, and no advanced ML before the data foundation is stable.

## Assumptions Not To Revisit

* The three-terminal model remains in place.
* `docs/inbox/` remains supplemental; it does not become the architecture repository.
* The new governance docs should be Markdown files, not a database, app, spreadsheet, or metadata platform.
* The asset inventory starts as a simple Markdown table.
* This handoff introduces governance documentation and workflow integration only; it does not implement automated lineage, scoring, dashboards, or new architecture tooling.
* `scripts/workflow.py` is not changed by this handoff.
* No git commit is introduced by this handoff.

## Implementation Steps

1. Create `docs/asset_inventory.md`.
   * Include a concise purpose.
   * Define status, criticality, and ownership conventions.
   * Add the required table columns exactly as listed in Success Criteria.
   * Populate initial rows from current repo assets only. Use stable asset IDs such as `project_context_docs`, `terminal_workflow_docs`, `handoff_lifecycle`, `inbox_intake`, `decision_question_backlog_logs`, `implementation_notes`, `kaggle_raw_source`, `jolpica_raw_source`, `duckdb_processed_database`, `reusable_python_modules`, `command_scripts`, `reusable_sql`, and `generated_outputs`.
   * Use `Unknown`, `TBD`, or `Not applicable` where the repo does not yet provide an answer.
2. Create `docs/architecture_operating_model.md`.
   * Explain the project-specific operating model for architecture change.
   * Reuse the current terminal roles and handoff lifecycle instead of inventing a second workflow.
   * Include explicit routing from architecture observations into `docs/decisions.md`, `docs/questions.md`, `docs/backlog.md`, draft handoffs, inventory updates, or no-action notes.
   * Include review cadence and asset disposition values from the processed inbox references.
3. Create `docs/architecture_principles.md`.
   * Keep it concise and project-specific.
   * Each principle should have a short rationale and practical implication.
   * Include principles for source boundaries, validation, deferred tooling, reproducibility, decision records, incremental change, and generated-output discipline.
4. Update `docs/terminal_protocol.md`.
   * Add the three new docs to the Source of Truth / Standing Fitness Check list.
   * Keep the existing list style.
   * Do not rewrite the terminal lifecycle or handoff status model.
5. Update `scripts/fitness_check.py`.
   * Add the three new docs to `REQUIRED_DOCS`.
   * Do not add a new check unless necessary; the existing required-docs and protocol-list checks should cover these files.
6. Update `docs/workflow_guide.md`.
   * Add a short note under the architecture/scope routing entry pointing users to `docs/architecture_principles.md`, `docs/architecture_operating_model.md`, and `docs/asset_inventory.md`.
   * Do not restructure the decision tree.
7. Update `docs/decisions.md`.
   * Add one new dated decision entry: adopt lightweight architecture governance documents.
   * Include `Decision:`, `Rationale:`, `Tradeoffs:`, and `Status: Accepted`.
8. Update `docs/questions.md`.
   * Add one answered question explaining how architecture governance findings and audit observations enter backlog, decisions, questions, handoffs, or inventory updates.
9. Update `docs/backlog.md`.
   * Add an architecture-governance section.
   * Include short follow-up items such as:
     * run the first monthly inventory review after these docs are created.
     * identify which inventory rows need stronger validation.
     * decide later whether a separate `docs/roadmap.md` is warranted.
     * evaluate whether any architecture-governance rules should become automated fitness checks after repeated manual use.
   * Keep existing completed/deferred analytics items intact.
10. Update `docs/active_context.md`.
    * Add the new docs to Current Repo State.
    * Add the new architecture-governance decision to Current Decisions.
    * Mention the new docs in Current Focus or Next Action as appropriate.
11. Run validation commands listed below.
12. Add a human-readable run-log entry for this handoff's implementation and validation results.
13. Write `docs/implementation_notes/014-add-architecture-governance-docs.md` using the standard format in `docs/implementation_notes/README.md`.

## Validation Commands

```bash
pwd
python3 scripts/fitness_check.py
grep -n "docs/asset_inventory.md" docs/terminal_protocol.md scripts/fitness_check.py docs/workflow_guide.md
grep -n "docs/architecture_operating_model.md" docs/terminal_protocol.md scripts/fitness_check.py docs/workflow_guide.md
grep -n "docs/architecture_principles.md" docs/terminal_protocol.md scripts/fitness_check.py docs/workflow_guide.md
grep -n "Asset ID" docs/asset_inventory.md
grep -n "Decision:" docs/decisions.md
grep -n "architecture governance" docs/questions.md docs/backlog.md docs/active_context.md
sed -n '1,120p' docs/asset_inventory.md
sed -n '1,140p' docs/architecture_operating_model.md
sed -n '1,140p' docs/architecture_principles.md
git status --short
```

## Expected Outputs

* `python3 scripts/fitness_check.py` prints `Fitness checks: 13 run, 0 failed`.
* The three new docs exist and are referenced in both `docs/terminal_protocol.md` and `scripts/fitness_check.py`.
* `docs/workflow_guide.md` points architecture/governance planning users to the new docs.
* `docs/asset_inventory.md` includes the required table columns and initial rows for current project assets.
* `docs/architecture_operating_model.md` explains how architecture findings become decisions, questions, backlog items, handoffs, or inventory updates.
* `docs/architecture_principles.md` contains concise project-specific principles.
* `docs/backlog.md` has architecture-governance follow-up items.
* `docs/run_log.md` has an automatic fitness-check entry and a manual handoff entry.
* `git status --short` shows only the expected files plus any pre-existing local untracked state.

## Stop Conditions

Stop if the new docs would require changing analytics code, data files, generated outputs, or the CLI router.

Stop if adding the new docs to the Source of Truth list would require restructuring `docs/terminal_protocol.md` rather than adding entries.

Stop if the asset inventory cannot be populated without inventing information not present in the repo. In that case, create the table with explicit `Unknown`/`TBD` values and record the gaps in `docs/backlog.md`.

Stop if validation fails for reasons unrelated to this handoff and report the blocker.

## What To Report Back

Report:

* files created.
* files changed.
* `python3 scripts/fitness_check.py` result.
* confirmation that the three new docs are now part of the standing fitness list.
* confirmation that architecture governance findings now have routing into backlog/questions/decisions/handoffs/inventory.
* any unknowns left in the first asset inventory.
* any issues or deviations.
