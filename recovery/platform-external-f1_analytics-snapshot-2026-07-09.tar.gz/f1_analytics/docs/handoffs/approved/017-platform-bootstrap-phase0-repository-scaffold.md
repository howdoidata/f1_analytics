# Handoff 017: Platform Bootstrap — Phase 0 (Repository Scaffold)

Status: Approved

Project: platform

## Goal

Create three files in an empty directory: `AGENTS.md`, `PROJECT.md`, `.gitignore`. Nothing else.

Everything from "Execution Contract" onward must be followable by a system with no access to this repository's history, decisions, or logged context — only this document and the `TARGET_DIR` parameter below.

## Revision Note 2026-07-09 16:46 : New directories will not be able to learn from documents, history on why it was created because there is a compromise between architecture and projects. This is to rectify that. Once setup correctly it will and does not necessarily need to be called out here. That note is for this planning session to understand to leave out language that is not "templatized"


## Success Criteria

See Gate 0 below — that checklist is the complete, sole definition of done for this phase.


## Revision Note 2026-07-09 16:46 : I feel the first true success criteria should be a system that strictyl adheres to the terminal protocol (or replacement) and current processes needed to interact in a miniminal manner needed to operate in accordance with main requirements. 



## Relevant Project Context (for the human reviewing this draft; not available to, or needed by, the executing system)

This is Phase 0 of a planned seven-phase bootstrap (0-6) for a project-agnostic, multi-project analytics platform, replacing the earlier attempt to migrate this repository in place (see `docs/decisions.md`, "Deliver the bootstrap specification as an incremental, phase-scoped handoff sequence starting with repository scaffold only" and its superseded predecessor). Later phases — platform governance documents, the terminal workflow layer, mechanical fitness/workflow scripts, the multi-project/template/exchange layer, a synthetic-project verification, and finally onboarding this repository's own F1 workflow (`notebooks/championship_leader_combined_analysis.ipynb`) as an external verification — are deliberately **not** drafted yet. Each will become its own handoff only after the phase before it has been reviewed and, if approved, executed. This keeps every phase small enough to verify in isolation, per the "prefer small, reversible changes" principle already used elsewhere in this project.

## Decisions Already Made (recorded in this repository's `docs/decisions.md`)

* The bootstrap is delivered as a sequence of phase-scoped handoffs, not one large specification; this handoff is Phase 0 only.
* Each phase must be executable by a system with no access to this repository's history — the underlying architecture rationale is restated generically inside each phase's own instructions, not inherited by reference to this repository's decision log.
* This repository is not restructured by executing this handoff; the build target is a separate, empty directory.

## Assumptions Not To Revisit

* Do not create any file or directory beyond `AGENTS.md`, `PROJECT.md`, and `.gitignore` in this phase. Governance docs, scripts, `projects/`, and `exchange/` belong to later phases and must not be pre-created here, even as empty placeholders.
* Do not consult, copy, or paraphrase this repository's own `AGENTS.md`/`PROJECT.md` content. Write `TARGET_DIR`'s versions fresh, as platform-only documents, using this handoff's own instructions as the sole source of what they must contain.
* `TARGET_DIR` is a directory outside this repository, chosen by the user. This repository stays completely unmodified.

## Inputs (set by the user before execution)

| Parameter | Meaning | Value for this test run |
|---|---|---|
| `TARGET_DIR` | Empty directory where the platform scaffold is built | user-chosen, e.g. a new sibling directory of this repository |

## Files Expected To Change (in this repository)

None.

## Files That Should Not Change (in this repository)

Everything. This repository is read-only for the purpose of this handoff.

---

# THE SPECIFICATION

Everything below this line is the self-contained Phase 0 build instruction. It assumes no other context.

## Execution Contract

1. Confirm `TARGET_DIR` exists and is empty before doing anything else. If it is missing or not empty, stop and report — do not create it yourself or delete its contents.
2. Perform the steps below in order. Do not add files or directories beyond what is listed.
3. Where this specification states a requirement in prose ("must state X"), write original text satisfying that requirement. Do not leave bracketed placeholders, "TBD," or lorem-ipsum-style filler in the delivered files — every sentence must be real, substantive content a reader could act on.
4. Do not reference any specific project, product, dataset, vendor, or client anywhere in the files you write. If you are unsure whether a word is project-specific, prefer the more generic word.

## Steps

1. Run `git init` inside `TARGET_DIR`.

2. Create `AGENTS.md` at the root of `TARGET_DIR` with a `## Universal Rules` heading, followed by a rule list covering at least these points, each as its own bullet, in your own words:
   * The repository is the source of truth for project state; do not rely on conversation history when the repository already records the answer.
   * Before making a change, read the platform's root documentation and, if the work is scoped to a specific project directory, that project's own documentation first.
   * Prefer simple, maintainable solutions; do not add abstractions or infrastructure the current work does not need.
   * Durable decisions get written down with their reasoning, not left implicit in code or chat.
   * Commands run and their results get recorded, not just described from memory afterward.

3. Create `PROJECT.md` at the root of `TARGET_DIR` as the platform's own charter (not any individual project's charter). It must contain, at minimum, these sections with substantive content:
   * `## Purpose` — state plainly that this repository is a shared, reusable operating platform for running multiple independent analytics/engineering projects side by side, not a single project itself.
   * `## Scope` — state that root-level content (this file and everything that will live under a future `docs/` directory) must stay generic: it may describe process, workflow, documentation conventions, and mechanical checks, but must never describe a specific project's goals, data sources, tools chosen for one project's use, or business context. Project-specific work belongs entirely inside that project's own directory once the multi-project layer exists (a later phase, not yet built).
   * `## Current State` — state plainly that only the repository scaffold exists so far (this phase); no governance documents, workflow scripts, or projects have been added yet, and name that fact as expected, not a gap.
   * `## Projects` — an empty list for now, with one sentence noting it will be populated once individual projects are onboarded in a later phase.

4. Create `.gitignore` at the root of `TARGET_DIR` covering, at minimum:
   * OS artifacts (e.g. `.DS_Store`)
   * Editor/IDE directories
   * Python virtual environments and bytecode caches (e.g. `.venv/`, `__pycache__/`, `*.py[cod]`)
   * Notebook checkpoint directories (e.g. `.ipynb_checkpoints/`)
   * Credential and environment files (e.g. `.env`, `.env.*`, any token/key file patterns)

   Do not add ignore rules for directories that do not exist yet (no `projects/`, `exchange/`, `data/`, or `outputs/` patterns in this phase — those belong to the phase that introduces those directories, so the ignore rules can be verified against real content rather than guessed in advance).

5. Do not run any further steps. Stop here.

## Gate 0 (must pass before this phase is reported complete)

* `git -C "$TARGET_DIR" rev-parse --is-inside-work-tree` succeeds.
* `AGENTS.md`, `PROJECT.md`, and `.gitignore` exist at the root of `TARGET_DIR`, and only those three files/paths exist (plus the `.git/` directory `git init` created).
* `AGENTS.md` contains a `## Universal Rules` heading followed by a non-empty bullet list.
* `PROJECT.md` contains all four required headings (`## Purpose`, `## Scope`, `## Current State`, `## Projects`), each followed by non-placeholder prose.
* Neither file contains an unresolved placeholder token (e.g. literal `[fill in]`, `TBD`, `{{...}}`, or `lorem ipsum`).
* Neither file names a specific project, dataset, vendor, or product.
* No file or directory other than `AGENTS.md`, `PROJECT.md`, `.gitignore`, and `.git/` exists under `TARGET_DIR`.

If any condition fails, fix it within this phase and re-check the full Gate before reporting completion. Do not report success with a failing or unchecked condition.

## Validation Commands (run from this repository's command terminal, against the external `TARGET_DIR`)

```bash
test -n "$TARGET_DIR" && echo "TARGET_DIR is set"
git -C "$TARGET_DIR" rev-parse --is-inside-work-tree
find "$TARGET_DIR" -mindepth 1 -maxdepth 1 ! -name ".git" | sort
test -f "$TARGET_DIR/AGENTS.md" && grep -c "^## Universal Rules" "$TARGET_DIR/AGENTS.md"
test -f "$TARGET_DIR/PROJECT.md" && grep -c "^## Purpose\|^## Scope\|^## Current State\|^## Projects" "$TARGET_DIR/PROJECT.md"
grep -niE "\[fill in\]|TBD|\{\{|lorem ipsum" "$TARGET_DIR/AGENTS.md" "$TARGET_DIR/PROJECT.md"; echo "exit=$? (expect 1, no matches)"
test -f "$TARGET_DIR/.gitignore" && cat "$TARGET_DIR/.gitignore"
git status --short   # this repository: expect no output, nothing changed
```

## Expected Outputs

* `TARGET_DIR` contains exactly `.git/`, `AGENTS.md`, `PROJECT.md`, `.gitignore` — nothing more.
* Both Markdown files are complete, generic, substantive, and name no specific project.
* This repository shows no changes in `git status`.

## Stop Conditions

Stop if:

* This handoff is still `Status: Draft` and has not been explicitly approved and moved to `docs/handoffs/approved/`.
* `TARGET_DIR` does not exist or is not empty at the start.
* Completing the Gate would require adding any file or directory not listed in the Steps above — that means a later phase's work is being pulled forward; stop and report rather than expanding scope.
* Any file ends up naming a specific project, dataset, or vendor, or contains an unresolved placeholder — fix it before reporting completion; if it cannot be fixed without adding out-of-scope content, stop and report why.

## What To Report Back

* Full contents of the generated `AGENTS.md` and `PROJECT.md`.
* Gate 0 command outputs, condition by condition.
* Confirmation this repository was not modified.
* Anything that required a judgment call not explicitly covered by the Steps above (so it can be tightened before Phase 1 is drafted).
