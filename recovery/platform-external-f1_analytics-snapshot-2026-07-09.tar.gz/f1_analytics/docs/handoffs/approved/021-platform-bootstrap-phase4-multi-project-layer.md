# Handoff 021: Platform Bootstrap — Phase 4 (Multi-Project Layer)

Status: Completed

Project: platform

## Completion Note 2026-07-10

Executed against `TARGET_DIR` and verified independently: `find`/`fitness_check.py` output matches Gate 4 exactly. Contract item 0 worked as intended — the delivery copy found inside `TARGET_DIR/docs/handoffs/approved/` this time was removed before Step 1's fileset check, per the revision below, rather than causing another stop. `projects/`, `exchange/`, and `scripts/new_project.py` exist as specified; the `smoke_test_project` create/collide/cleanup sequence passed and left no trace; `python3 scripts/fitness_check.py` passes 10/10 both with and without a project present, unmodified. `scripts/fitness_check.py`/`scripts/workflow.py` are byte-unchanged. See `docs/active_context.md` for the folded-in report.

## Revision Note 2026-07-10

An execution attempt against `TARGET_DIR` correctly stopped at Step 1 rather than forcing a match, reporting two blockers, with no implementation changes made:

* Three `.DS_Store` files (macOS Finder metadata, already covered by `.gitignore`) were present under `TARGET_DIR` and counted as "extra files present" by the fileset comparison, which this handoff never told the executing system to disregard.
* A copy of this handoff document itself had been placed inside `TARGET_DIR/docs/handoffs/approved/` (renamed `04-platform-bootstrap-phase4-multi-project-layer.md`) so the execution session would have something on disk to read. That directly conflicts with Step 1's requirement that `docs/handoffs/approved/` be empty, since this handoff never specified how it should reach an executing session that has no access to this repository.

No part of this phase has executed, so this is revised in place rather than superseded. Step 1 now explicitly disregards `.DS_Store` files, and a new contract item explains where this document may and may not be delivered, including how to recover from exactly the delivery mistake found above. A corresponding stop condition and reporting item were added so future phases (5-6) do not have to rediscover this.

## Goal

Add the multi-project layer to the existing platform scaffold (Phases 0-3 already built): an empty, isolated `projects/` directory with its own convention document, a gitignored `exchange/` staging area for moving files into or out of a project, and a stdlib-only `scripts/new_project.py` generator that creates a new project directory following that convention. Then correct the two Phase 0 sentences that describe this layer as not yet existing, now that this phase adds it. Nothing else.

Everything from "Execution Contract" onward must be followable by a system with no access to this repository's history, decisions, or logged context — only this document and the `TARGET_DIR` parameter below.

## Success Criteria

See Gate 4 below — that checklist is the complete, sole definition of done for this phase.

## Relevant Project Context

Phase 3 execution against `TARGET_DIR` surfaced a process finding: its own new fitness check found that Phase 0-2's `docs/terminal_protocol.md` `## Source Of Truth` list did not cover the `docs/handoffs/` and `docs/inbox/` directories, and that gap was corrected in place during execution rather than stopped-and-reported, which was a deviation from Handoff 020's own stop conditions. This was accepted after direct verification (the correction is accurate; `python3 scripts/fitness_check.py` passes 10/10 against `TARGET_DIR` as of 2026-07-10), but the stop-and-report rule was reaffirmed for future phases (2026-07-10 decision, `docs/decisions.md`, this repository). Phase 4 is a plausible place for a similar situation to recur, since it introduces new top-level directories. Step 8 below makes the stop-and-report expectation an explicit stop condition rather than relying on that decision being available to the executing system.

## Decisions Already Made

* Deliver the bootstrap specification as an incremental, phase-scoped handoff sequence, one phase at a time (2026-07-09 decision, this repository).
* The target shape carries forward from Phase 1's `docs/multi_project_operating_model.md`: one repository, a generic platform layer at the root, isolated `projects/<name>/` directories that must not depend on another project's code, data, or documentation, and a staging convention for moving files into or out of a project modeled on the existing `docs/inbox/` land-triage-claim-or-archive pattern.
* Accept Phase 3's Source-Of-Truth correction and require stop-and-report, not in-place repair, for future phase-boundary fitness findings (2026-07-10 decision, this repository).

## Assumptions Not To Revisit

* Do not onboard any real or synthetic project in this phase — creating and keeping a project directory under `projects/` is Phase 5's job. This phase adds only the mechanism (the empty `projects/` directory, its convention document, and the generator script), not an occupant.
* Do not modify `scripts/fitness_check.py` or `scripts/workflow.py` in this phase. Adding `projects/` and `exchange/` as new top-level entries does not require adding them to `docs/terminal_protocol.md`'s `## Source Of Truth` list (that list names platform governance documents, not every top-level directory), so the existing scripts' checks are expected to keep passing unmodified — Step 7 below requires proving this rather than assuming it.
* Do not modify any Phase 0-3 file except the four files and exact sections named in Steps 5-6 below.
* `TARGET_DIR` is the same directory Phases 0-3 built into; it already contains exactly the Phase 0-3 fileset described in Step 1 before this phase starts.
* Do not consult, copy, or paraphrase this repository's own project structure, `src/f1_analytics/` layout, or any F1-specific file when writing the generator or its generated templates. Write `TARGET_DIR`'s versions fresh, using this handoff's own instructions as the sole source of required content. F1 onboarding is Phase 6's job, not this one.
* `scripts/new_project.py` must use only the Python 3 standard library. Do not add a `requirements.txt` or any third-party dependency.
* None of the new or edited files may name a specific project, dataset, vendor, or product. The one exception is the transient smoke-test project name used and then removed in Step 7 (`smoke_test_project`), which is a structural placeholder, not a product or dataset name.
* None of the new or edited files may contain an unresolved placeholder token (e.g. literal `[fill in]`, `TBD`, `{{...}}`, or `lorem ipsum`) in what the phase leaves behind at the end of Step 8.

## Inputs (set by the user before execution)

| Parameter | Meaning | Value for this run |
|---|---|---|
| `TARGET_DIR` | Existing platform directory Phases 0-3 built into | `/Users/antonio/Documents/howdoidata/projects/platform` |

## Files Expected To Change (in this repository)

None.

## Files That Should Not Change (in this repository)

Everything. This repository is read-only for the purpose of this handoff.

---

# THE SPECIFICATION

Everything below this line is the self-contained Phase 4 build instruction. It assumes no other context.

## Execution Contract

0. This document must reach the executing session as pasted context or as a file stored outside `TARGET_DIR` — never saved anywhere under `TARGET_DIR`, including `TARGET_DIR/docs/handoffs/`. That folder's emptiness is part of the Phase 0-3 fileset Step 1 checks, because it is reserved for `TARGET_DIR`'s own future handoffs once the platform is in real use, not for delivering the bootstrap sequence that builds it. If a copy of this exact document is found anywhere inside `TARGET_DIR` when Step 1 runs, that copy is a delivery artifact, not a Phase 0-3 state problem: remove it (or move it outside `TARGET_DIR`), then evaluate Step 1 as if it had never been there. Do not treat its prior presence as license to change anything else. If it is unclear whether an unexpected file is this delivery artifact or a genuine Phase 0-3 problem, stop and report rather than guessing.
1. Confirm `TARGET_DIR` exists and contains exactly this fileset before doing anything else, disregarding `.DS_Store` files at any depth (macOS Finder metadata, already covered by `.gitignore`, never part of any phase's authored content). If anything else is missing or present that is not named below, stop and report — do not add, remove, or modify anything to force a match.
   * Root: `.git/`, `.gitignore`, `AGENTS.md`, `PROJECT.md`, `docs/`, `scripts/`.
   * `docs/` top level: `decisions.md`, `questions.md`, `backlog.md`, `run_log.md`, `asset_inventory.md`, `architecture_principles.md`, `architecture_operating_model.md`, `analysis_output_standards.md`, `multi_project_operating_model.md`, `active_context.md`, `terminal_protocol.md`, `workflow_guide.md`, `terminal_roles/`, `handoffs/`, `implementation_notes/`, `inbox/`, `prompts/`.
   * `docs/terminal_roles/`: `planning.md`, `execution.md`, `command.md`.
   * `docs/handoffs/`: `README.md`, empty `drafts/`, empty `approved/`.
   * `docs/implementation_notes/`: `README.md`.
   * `docs/inbox/`: `README.md`, empty `processed/`.
   * `docs/prompts/`: `planning_prompt.txt`, `execution_prompt.txt`, `command_prompt.txt`.
   * `scripts/`: `fitness_check.py`, `workflow.py`.
2. Perform the steps below in order. Do not add files or directories beyond what is listed, except the transient smoke-test project created and removed in Step 7.
3. Where this specification states a requirement in prose, write original code or text satisfying that requirement. Do not leave bracketed placeholders, "TBD," or lorem-ipsum-style filler.
4. Do not reference any specific project, product, dataset, vendor, or client anywhere in the files you write or edit, other than the transient smoke-test project name in Step 7.
5. Every check and error path described below must produce a human-readable failure detail (what was wrong, not just that something failed) when it fails.

## Steps

1. Create `projects/` and inside it a single file, `projects/README.md`:
   * State plainly that each project owns its own code, data, documentation, and generated outputs under `projects/<name>/`, and must not depend on another project's code, data, or documentation — only the root platform layer is shared. Point to `docs/multi_project_operating_model.md` as the authoritative statement of this isolation rule rather than restating its rationale here.
   * State that a project directory is created by running `python3 scripts/new_project.py <name>` from the repository root, and describe in one sentence what that produces (a `projects/<name>/` directory containing a project-level `PROJECT.md` and a project-level `docs/` with `decisions.md`, `questions.md`, `backlog.md`, `run_log.md`, and `active_context.md`).
   * State plainly that no project directory exists inside `projects/` at the end of this phase, and that a later phase creates the first one (do not name that phase's content here beyond that one fact).

2. Create `exchange/` and inside it a single tracked file, `exchange/README.md`:
   * State that this is a staging area for moving files into or out of a project — external files, corrections, specs, or reference material land here first — modeled on the same land-triage-claim-or-archive pattern already used by `docs/inbox/` for platform-level intake, but scoped to project-bound material instead of platform governance material.
   * State the triage outcomes plainly: an item is either claimed (moved into the relevant `projects/<name>/` directory by whoever owns that project's planning) or removed once no longer needed. Unlike `docs/inbox/processed/`, staged items are not retained here for provenance — this directory's contents (other than this README) are not tracked by version control, so anything worth keeping permanently must be moved into a project's own tracked files.
   * State plainly that this directory's contents, other than this README, are git-ignored, and name `.gitignore` as where that rule is enforced.

3. Edit `.gitignore`: add a rule (or pair of rules) that ignores everything under `exchange/` except `exchange/README.md`. Do not remove or reorder any existing rule.

4. Create `scripts/new_project.py`, an argument-required command-line script with no third-party imports:
   * Usage: `python3 scripts/new_project.py <name>`. Exit with a non-zero status and a human-readable message on any of the following, without creating or modifying anything: no name given; the name is not a lowercase, filesystem-safe slug (letters, digits, and underscores only, must start with a letter — reject anything containing `/`, `.`, spaces, or other characters that could escape `projects/` or collide with hidden files); `projects/<name>/` already exists.
   * On a valid, non-colliding name, create `projects/<name>/` containing:
     * `PROJECT.md` with sections stating the project's purpose is not yet filled in (this file is a starting point for the project's own planning terminal to complete), its scope is owned entirely by this project directory and must not describe platform-level process, and its current state is that only this generated scaffold exists.
     * `docs/decisions.md`, `docs/questions.md`, `docs/backlog.md`, and `docs/run_log.md`, each seeded with the same `## Purpose`/`## Format`/`## Log` (or, for `questions.md`, `## Open Questions`/`## Answered Questions`/`## Blockers`; for `backlog.md`, a single top-level heading with no entries yet) skeleton already used by this repository's own root-level documents of the same name, adapted only to state that the scope is this one project rather than the platform.
     * `docs/active_context.md` stating the project's name, that it was generated by `scripts/new_project.py` and has not yet been populated with real content, and pointing back to the root `docs/terminal_protocol.md` and `docs/workflow_guide.md` as the still-authoritative process documents shared across all projects.
   * On success, print the path created and exit `0`. The script must not write to any file outside the new `projects/<name>/` tree, and must not modify `PROJECT.md`, `docs/multi_project_operating_model.md`, or any other existing file.

5. Edit `docs/multi_project_operating_model.md`. Replace the `## Future State` heading and its body ("No project directories or staging convention exist in this repository. They are introduced by a later phase.") with a section stating plainly that `projects/` and `exchange/` now exist with the shape described above, that `scripts/new_project.py <name>` creates a new project directory, and that no project directory exists inside `projects/` at the end of this phase — a later phase creates the first one.

6. Edit `PROJECT.md`:
   * In `## Scope`, replace the sentence "Once the multi-project layer exists in a later phase, project-specific work belongs entirely inside that project's own directory." with a sentence stating plainly that the multi-project layer now exists and project-specific work belongs entirely inside that project's own `projects/<name>/` directory; root-level content stays generic.
   * In `## Current State`, replace the sentence "Only the repository scaffold exists so far. No governance documents, workflow scripts, shared templates, or individual projects have been added yet. That is the expected state for this phase, not a missing piece to fill in early." with a sentence stating plainly what actually exists as of this phase: the governance documents, terminal workflow layer, mechanical fitness-check/workflow scripts, and now the multi-project layer and generator, with no individual project yet created.
   * Leave `## Projects` unchanged — it is populated by whichever later phase or handoff actually onboards a project, not by this one.

7. Prove the generator works, then remove all trace of the proof:
   * Run `python3 scripts/new_project.py smoke_test_project` from `TARGET_DIR` and confirm it exits `0` and creates exactly the file set described in Step 4.
   * Run `python3 scripts/new_project.py smoke_test_project` a second time and confirm it exits non-zero and creates or modifies nothing (the existing-directory collision case).
   * Run `python3 scripts/fitness_check.py` from `TARGET_DIR` with `projects/smoke_test_project/` present and confirm it still exits `0` with 10/10 `[PASS]` — this proves Phase 4 does not require any change to `scripts/fitness_check.py`, per the Assumptions above.
   * Delete `projects/smoke_test_project/` entirely. Confirm `projects/` is empty again except for `README.md`.
   * Run `python3 scripts/fitness_check.py` one final time and confirm it still exits `0` with 10/10 `[PASS]`, and that this cleanup did not modify any file this phase was not already authorized to change.

8. Do not run any further steps. Stop here. In particular: if any check in Step 7 fails, or if satisfying the Gate below would require modifying `scripts/fitness_check.py`, `scripts/workflow.py`, or any Phase 0-3 file or section not named in Steps 5-6, stop and report rather than making that change — this is the same stop-and-report expectation Phase 3 did not follow for an analogous finding (see Relevant Project Context above), restated here as a binding stop condition for this phase.

## Gate 4 (must pass before this phase is reported complete)

* `projects/` exists at the root of `TARGET_DIR`, contains exactly `README.md`, and no project subdirectory.
* `exchange/` exists at the root of `TARGET_DIR` and contains exactly `README.md` as a tracked file (`git status --short --ignored` in `TARGET_DIR` shows nothing else under `exchange/` as untracked-and-not-ignored).
* `scripts/` contains exactly `fitness_check.py`, `workflow.py`, `new_project.py`.
* Running `python3 scripts/new_project.py smoke_test_project` from `TARGET_DIR`, then deleting the result, leaves no trace: `projects/` contains only `README.md` afterward.
* Running `python3 scripts/new_project.py` a second time against an existing project name exits non-zero and changes nothing.
* Running `python3 scripts/fitness_check.py` from `TARGET_DIR` exits `0` and prints `[PASS]` for all 10 checks, both with and without a project directory present (Step 7), and without any edit to `scripts/fitness_check.py` itself.
* Running `python3 scripts/new_project.py` with no argument, or with a name containing `/`, a space, or a leading digit, exits non-zero with a human-readable error and creates nothing.
* `docs/multi_project_operating_model.md` and `PROJECT.md` no longer contain the phrase "later phase" anywhere in connection with `projects/` or `exchange/` already existing (the phrase may still legitimately appear when correctly describing that project onboarding itself is left to a later phase, per Steps 1 and 5 above).
* Every file and directory from Phases 0-3 other than the two files edited in Steps 5-6 is byte-for-byte unchanged, and `scripts/fitness_check.py`/`scripts/workflow.py` specifically are unchanged.
* None of the files created or edited in this phase name a specific project, dataset, vendor, or product, other than the transient `smoke_test_project` name, which does not exist at the end of the phase.
* None of the files left behind at the end of this phase contain an unresolved placeholder token.
* This repository (the one holding this handoff) shows no changes in `git status`.

If any condition fails, fix it within this phase and re-check the full Gate before reporting completion. Do not report success with a failing or unchecked condition.

## Validation Commands (run from this repository's command terminal, against the external `TARGET_DIR`)

```bash
find "$TARGET_DIR/projects" -type f | sort   # expect only projects/README.md
find "$TARGET_DIR/exchange" -type f | sort   # expect only exchange/README.md
find "$TARGET_DIR/scripts" -type f | sort    # expect fitness_check.py, new_project.py, workflow.py
cd "$TARGET_DIR" && python3 scripts/new_project.py smoke_test_project; echo "exit=$?"
find "$TARGET_DIR/projects/smoke_test_project" -type f | sort   # expect the Step 4 file set
cd "$TARGET_DIR" && python3 scripts/new_project.py smoke_test_project; echo "exit=$? (expect non-zero)"
cd "$TARGET_DIR" && python3 scripts/fitness_check.py; echo "exit=$? (expect 0, 10/10 PASS, with smoke_test_project present)"
rm -rf "$TARGET_DIR/projects/smoke_test_project"
find "$TARGET_DIR/projects" -type f | sort   # expect only projects/README.md again
cd "$TARGET_DIR" && python3 scripts/fitness_check.py; echo "exit=$? (expect 0, 10/10 PASS, after cleanup)"
cd "$TARGET_DIR" && python3 scripts/new_project.py; echo "exit=$? (expect non-zero, no argument)"
cd "$TARGET_DIR" && python3 scripts/new_project.py "bad name"; echo "exit=$? (expect non-zero, invalid slug)"
grep -ni "later phase" "$TARGET_DIR/docs/multi_project_operating_model.md" "$TARGET_DIR/PROJECT.md"   # review manually: only legitimate onboarding-deferral mentions should remain
git -C "$TARGET_DIR" status --short --ignored   # informational only; exchange/README.md tracked, rest of exchange/ ignored, projects/README.md tracked
git status --short   # this repository: expect no output, nothing changed
```

## Expected Outputs

* `TARGET_DIR/projects/README.md`, `TARGET_DIR/exchange/README.md`, and `TARGET_DIR/scripts/new_project.py` exist and behave as specified.
* `TARGET_DIR/.gitignore` gains a rule excluding `exchange/` contents other than its `README.md`.
* `TARGET_DIR/docs/multi_project_operating_model.md` and `TARGET_DIR/PROJECT.md` are edited exactly as described in Steps 5-6; no other Phase 0-3 file changes, and `scripts/fitness_check.py`/`scripts/workflow.py` are untouched.
* `TARGET_DIR/projects/` contains no project directory at the end of the phase.
* This repository shows no changes in `git status`.

## Stop Conditions

Stop if:

* This handoff is still `Status: Draft` or `Status: Needs Revision` and has not been explicitly (re-)approved and moved to `docs/handoffs/approved/`.
* `TARGET_DIR` does not already contain exactly the Phase 0-3 fileset described in Step 1 at the start, after disregarding `.DS_Store` files and removing a delivery copy of this document per Contract item 0 — if what remains still does not match, stop and report rather than guessing further.
* Any Phase 0-3 fitness-equivalent check would fail before this phase's additions are even made, or satisfying this phase's Gate would require modifying `scripts/fitness_check.py`, `scripts/workflow.py`, or any Phase 0-3 file or section not named in Steps 5-6 — stop and report rather than silently repairing Phase 0-3 content or expanding this phase's authorized edits (see Relevant Project Context above).
* Completing the Gate would require creating or keeping any project directory under `projects/` beyond the transient, removed `smoke_test_project`, or adding anything under `exchange/` beyond `README.md` — that means a later phase's work is being pulled forward; stop and report rather than expanding scope.
* A script would require a third-party dependency to satisfy a check as specified — stop and report rather than adding one.
* Any file ends up naming a specific project, dataset, or vendor (other than the transient smoke-test name, which must not remain at completion), or contains an unresolved placeholder — fix it before reporting completion; if it cannot be fixed without adding out-of-scope content, stop and report why.

## What To Report Back

* Full contents of `scripts/new_project.py` and the three new/edited README-scale files (`projects/README.md`, `exchange/README.md`, plus the diff of `.gitignore`).
* A diff (or before/after excerpt) of `docs/multi_project_operating_model.md` and `PROJECT.md`.
* Gate 4 command outputs, condition by condition, including the smoke-test create/collide/cleanup sequence from Step 7.
* Confirmation this repository was not modified.
* How this document actually reached the executing session (pasted context, or a file path outside `TARGET_DIR`, and which one) — Phase 5 and 6 need a working example, not just the rule in Contract item 0.
* Anything that required a judgment call not explicitly covered by the Steps above — in particular, whether the generated per-project `docs/decisions.md`/`questions.md`/`backlog.md`/`run_log.md` skeletons in Step 4 needed any adaptation beyond what was specified to avoid platform-specific language leaking into project-level files, since Phase 5 will be the first real test of whether a project generated this way is actually usable end-to-end.
