  # Handoff 003: Add Draft Handoff Approval Workflow

Status: Completed

  ## Goal

  Add a lightweight file-based draft approval workflow so future handoff instructions do not need to be manually pasted between
  terminals.

  ## Success Criteria

  - Draft handoffs have a documented location.
  - Approved handoffs have a documented location.
  - Execution terminal is explicitly prohibited from executing draft handoffs.
  - Planning terminal is explicitly allowed to create or update draft handoff files only when the user asks it to.
  - `docs/active_context.md` reflects the new handoff lifecycle.
  - No application code, data workflow, notebook, dependency, dashboard, dbt, Airflow, or ML scaffold is created.

  ## Files Expected To Change

  - `docs/handoffs/README.md`
  - `docs/terminal_protocol.md`
  - `docs/terminal_roles/planning.md`
  - `docs/terminal_roles/execution.md`
  - `docs/active_context.md`
  - `docs/decisions.md`
  - `docs/run_log.md`

  ## Directories Expected To Be Created

  - `docs/handoffs/drafts/`
  - `docs/handoffs/approved/`

  ## Files That Should Not Change

  - `AGENTS.md`
  - `PROJECT.md`
  - `docs/project_profile.md`
  - `docs/questions.md`
  - `docs/backlog.md`
  - Any application/source/data files

  ## Implementation Steps

  1. Read `AGENTS.md`, `PROJECT.md`, `docs/active_context.md`, `docs/terminal_protocol.md`, `docs/terminal_roles/planning.md`,
  and `docs/terminal_roles/execution.md`.
  2. Create `docs/handoffs/drafts/` and `docs/handoffs/approved/`.
  3. Update `docs/handoffs/README.md` to define:
     - `docs/handoffs/drafts/` for proposed handoffs waiting for approval or edits.
     - `docs/handoffs/approved/` for execution-ready handoffs.
     - Every handoff must include a `Status:` line near the top.
     - Valid statuses are `Draft`, `Approved`, and `Completed`.
  4. Update `docs/terminal_protocol.md` so the handoff lifecycle becomes:
     - Planning terminal creates or updates draft handoff files only when explicitly instructed.
     - User reviews or edits the draft.
     - An approved handoff is placed in `docs/handoffs/approved/`.
     - Execution terminal implements only approved handoffs.
     - Command terminal runs validation commands from the approved handoff.
     - Results are recorded in `docs/implementation_notes/` and `docs/run_log.md`.
  5. Update `docs/terminal_roles/planning.md` to say:
     - Planning terminal does not edit code.
     - Planning terminal may create or update files under `docs/handoffs/drafts/` only when explicitly instructed.
     - Planning terminal should not place files in `docs/handoffs/approved/` unless the user explicitly says the handoff is
     approved.
  6. Update `docs/terminal_roles/execution.md` to say:
     - Execution terminal must only execute handoffs from `docs/handoffs/approved/`.
     - Execution terminal must stop if a handoff has `Status: Draft` or is located under `docs/handoffs/drafts/`.
  7. Add a decision to `docs/decisions.md` documenting the draft-to-approved handoff lifecycle.
  8. Update `docs/active_context.md` to note that the project now uses draft and approved handoff folders.
  9. Append a concise validation entry to `docs/run_log.md`.

  ## Validation Commands

  ```bash
  pwd
  find docs/handoffs -maxdepth 3 -type d -print | sort
  find docs/handoffs -maxdepth 3 -type f -print | sort
  rg -n "Status:|draft|approved|docs/handoffs/drafts|docs/handoffs/approved" docs/handoffs docs/terminal_protocol.md docs/
  terminal_roles docs/active_context.md docs/decisions.md
  git status --short

  ## Expected Output

  - docs/handoffs/drafts/ exists.
  - docs/handoffs/approved/ exists.
  - Docs clearly distinguish draft handoffs from approved handoffs.
  - Execution role forbids running draft handoffs.
  - Planning role allows draft handoff file creation only when explicitly instructed.
  - No application code or data workflow files are created.

  ## Stop Conditions

  Stop if the existing handoff files cannot be categorized cleanly, if the docs conflict on whether planning may write draft
  files, or if any requested change would require modifying application code.
