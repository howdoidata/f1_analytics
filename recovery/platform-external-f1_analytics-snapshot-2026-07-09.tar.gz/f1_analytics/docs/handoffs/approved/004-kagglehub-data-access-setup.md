# Handoff 004: Create KaggleHub Data Access Setup

Status: Completed

## Goal

Create the minimal local environment and KaggleHub data-access setup needed to reach the first F1 analytics milestone: downloading the selected Formula 1 dataset into the project without committing credentials.

## Success Criteria

* No secrets are committed to the repo.
* The project documents KaggleHub Option 3 authentication using `~/.kaggle/access_token`.
* The project treats `/Users/antonio/.kaggle/access_token` as the expected local KaggleHub token file.
* The repo has a minimal dependency file for dataset access and first-mile analysis.
* The repo has a script that downloads the selected Formula 1 dataset through `kagglehub`.
* The next command-terminal validation step is clear.
* No cleaning, modeling, dashboarding, dbt, Airflow, or ML work is added yet.

## Relevant Project Context

The selected starting dataset is:

`https://www.kaggle.com/datasets/patelris/formula-1-complete-dataset-1950-2026`

Use the Kaggle dataset handle:

`patelris/formula-1-complete-dataset-1950-2026`

The user expects to use `kagglehub` authentication Option 3 from:

`https://pypi.org/project/kagglehub/`

KaggleHub Option 3 expects the API token file at:

`~/.kaggle/access_token`

For this machine, that resolves to:

`/Users/antonio/.kaggle/access_token`

Treat this file as private local machine state. Do not create it in the repo.

## Decisions Already Made

* Use repo Markdown as project memory.
* Use draft and approved handoff folders.
* Start Version 1 with a free Kaggle Formula 1 dataset.
* Use `kagglehub` rather than the legacy Kaggle CLI for the first dataset access path.
* Keep Version 1 lightweight and locally runnable.
* Defer dbt, Airflow, dashboards, and ML until the local data workflow is stable.

## Files Expected To Change

* `.gitignore`
* `docs/active_context.md`
* `docs/questions.md`
* `docs/run_log.md`
* `docs/implementation_notes/004-kagglehub-data-access-setup.md`
* `requirements.txt`
* `docs/local_setup.md`
* `scripts/download_kagglehub_f1_data.py`

## Directories Expected To Be Created

* `scripts/`
* `data/raw/`
* `data/processed/`
* `outputs/`

## Files That Should Not Change

* `AGENTS.md`
* `PROJECT.md`
* `docs/project_profile.md`
* `docs/terminal_protocol.md`
* `docs/terminal_roles/*`
* Existing completed handoffs

## Assumptions Not To Revisit

* The Kaggle API token stays outside the repo.
* The token file for KaggleHub Option 3 is `/Users/antonio/.kaggle/access_token`.
* Downloaded raw data should not be committed.
* This handoff is only for setup and dataset access, not analysis.

## Implementation Steps

1. Read `AGENTS.md`, `PROJECT.md`, `docs/active_context.md`, `docs/questions.md`, and this handoff.
2. Confirm this handoff is approved before implementing. Stop if it is still `Status: Draft` or still under `docs/handoffs/drafts/`.
3. Update `.gitignore` so local data, credentials, virtual environments, Python caches, OS files, and editor files are ignored.
4. Create `requirements.txt` with only the minimum dependencies needed for dataset access and first-mile analysis:
   * `kagglehub`
   * `pandas`
   * `duckdb`
   * `plotly`
5. Create `docs/local_setup.md` with user instructions:
   * Generate a Kaggle API token from Kaggle account settings.
   * Save the token value at `/Users/antonio/.kaggle/access_token`.
   * Never commit this token file.
   * Do not place the token under the project directory.
6. Create `scripts/download_kagglehub_f1_data.py` to download `patelris/formula-1-complete-dataset-1950-2026` into `data/raw/f1_complete_dataset/` using `kagglehub.dataset_download(..., output_dir=...)`.
7. Make the download script fail clearly if the KaggleHub token file is missing at `/Users/antonio/.kaggle/access_token`.
8. Make the download script print the downloaded path and a short file count, but never print token contents.
9. Update `docs/questions.md` so the KaggleHub Option 3 credential preference is reflected as answered setup context, replacing the older `/Users/antonio/.config/f1_keys/kaggle_key` note.
10. Update `docs/active_context.md` so the next action is command-terminal validation of KaggleHub credential access and dataset download.
11. Record implementation notes in `docs/implementation_notes/004-kagglehub-data-access-setup.md`.
12. Append a concise entry to `docs/run_log.md` listing validation commands to run.

## User Setup Needed Before Command Validation

The user must ensure the KaggleHub token exists at:

```bash
/Users/antonio/.kaggle/access_token
```

This file should contain the Kaggle API token value expected by KaggleHub Option 3. It must not be committed to the project repo.

## Command Terminal Validation Commands

Run these from the project root:

```bash
pwd
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
test -f /Users/antonio/.kaggle/access_token && echo "kagglehub token file found"
python scripts/download_kagglehub_f1_data.py
find data/raw/f1_complete_dataset -maxdepth 3 -type f | sort | head -50
git status --short
```

## Expected Outputs

* `kagglehub token file found`
* The dataset downloads into `data/raw/f1_complete_dataset/`.
* `git status --short` does not show credential files or downloaded raw data.
* The project is ready for the next handoff: inspect raw files, define basic cleaning, joins, aggregations, and first visualization.

## Stop Conditions

Stop if:

* This handoff is still in `docs/handoffs/drafts/`.
* This handoff still has `Status: Draft`.
* The KaggleHub token file is missing at `/Users/antonio/.kaggle/access_token`.
* The Kaggle download requires payment, browser login, or a different dataset identifier.
* Any step would commit credentials or downloaded raw data.

## What To Report Back

Report:

* Files changed.
* Whether the KaggleHub setup instructions were created.
* Whether the dataset download script was created.
* Exact validation commands for the command terminal.
* Any blockers or assumptions that need planning review.
