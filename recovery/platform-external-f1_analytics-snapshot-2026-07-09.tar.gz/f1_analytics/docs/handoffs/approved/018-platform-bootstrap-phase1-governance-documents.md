# Handoff 018: Platform Bootstrap — Phase 1 (Platform Governance Documents)

Status: Approved

Project: platform

## Goal

Add a `docs/` directory to the existing platform scaffold (built in Phase 0) containing nine generic governance documents: decisions, questions, backlog, run log, asset inventory, architecture principles, architecture operating model, analysis output standards, and multi-project operating model. Nothing else.

Everything from "Execution Contract" onward must be followable by a system with no access to this repository's history, decisions, or logged context — only this document and the `TARGET_DIR` parameter below.

## Success Criteria

See Gate 1 below — that checklist is the complete, sole definition of done for this phase.



## Assumptions Not To Revisit

* Do not create `docs/terminal_protocol.md`, `docs/terminal_roles/`, `docs/prompts/`, `docs/handoffs/`, `docs/implementation_notes/`, or `docs/inbox/` in this phase — those belong to Phase 2.
* Do not create `projects/` or `exchange/` directories in this phase — those belong to Phase 4.
* Do not modify the existing `AGENTS.md`, `PROJECT.md`, or `.gitignore` created in Phase 0.
* `TARGET_DIR` is the same directory Phase 0 built into; it already contains `.git/`, `AGENTS.md`, `PROJECT.md`, `.gitignore` before this phase starts.
* Do not consult, copy, or paraphrase this repository's own governance documents. Write `TARGET_DIR`'s versions fresh, using this handoff's own instructions as the sole source of required content.

## Inputs (set by the user before execution)

| Parameter | Meaning | Value for this run |
|---|---|---|
| `TARGET_DIR` | Existing platform directory Phase 0 built into | `/Users/antonio/Documents/howdoidata/projects/platform` |

## Files Expected To Change (in this repository)

None.

## Files That Should Not Change (in this repository)

Everything. This repository is read-only for the purpose of this handoff.

---

# THE SPECIFICATION

Everything below this line is the self-contained Phase 1 build instruction. It assumes no other context.

## Execution Contract

1. Confirm `TARGET_DIR` exists and contains exactly `.git/`, `AGENTS.md`, `PROJECT.md`, `.gitignore` before doing anything else. If anything is missing or anything extra is present, stop and report — do not add, remove, or modify anything to force a match.
2. Perform the steps below in order. Do not add files or directories beyond what is listed.
3. Where this specification states a requirement in prose ("must state X"), write original text satisfying that requirement. Do not leave bracketed placeholders, "TBD," or lorem-ipsum-style filler. Every sentence must be real, substantive content a reader could act on.
4. Do not reference any specific project, product, dataset, vendor, or client anywhere in the files you write.
5. Do not describe or depend on a terminal, role, or handoff-based review/approval workflow anywhere in these documents — that layer is not part of this phase and is added later. Where a document needs to describe how a finding gets reviewed, approved, or scheduled for work, describe it generically (for example, "a review step" or "scheduled work") without naming specific terminals, roles, or folders that do not exist yet in `TARGET_DIR`.
6. Where a document needs to state that something does not exist yet, state the mechanism by which it will be added plainly (for example, "entries are appended here as they are made"). Do not use hedge phrases that frame the absence as temporary or incomplete (for example, "for now," "not yet," "currently empty").

## Steps

1. Create `docs/` at the root of `TARGET_DIR`.

2. Create `docs/decisions.md`:
   * `## Purpose` — state that this file is the durable record of decisions that change policy, tool direction, source or data treatment, or lifecycle rules, so that reasoning is not lost to memory or chat history.
   * `## Format` — state that every entry has `Decision:`, `Rationale:`, `Tradeoffs:`, and `Status:`; that an entry whose `Status:` is `Accepted` is a frozen record whose body is never rewritten; and that when a later decision replaces one, the later entry adds a `Supersedes:` line naming the earlier entry and the earlier entry's `Status:` is updated to `Superseded` plus a `Superseded by:` line, without editing the earlier entry's body.
   * `## Log` — one sentence stating that entries are appended here as decisions are made, followed by no entries (this file starts genuinely empty).

3. Create `docs/questions.md`:
   * `## Open Questions` — one sentence stating this section holds unresolved questions that block or shape upcoming work, followed by no entries.
   * `## Answered Questions` — one sentence stating this section holds questions that have been resolved, with their answers kept for later reference, followed by no entries.
   * `## Blockers` — one sentence stating this section names anything currently preventing progress, followed by a plain statement that none are recorded.

4. Create `docs/backlog.md`:
   * `## Purpose` — state that this file holds concrete deferred work: known risks, cleanup, validation gaps, documentation gaps, and future enhancements that are real but not ready for execution, and that it is not a substitute for a decision or an open question.
   * `## Entries` — one sentence stating that items are added here as they are identified, followed by no entries.

5. Create `docs/run_log.md`:
   * `## Purpose` — state that this file records commands that were run and their results, so validation history does not depend on memory or chat transcripts.
   * `## Format` — state that each entry names its purpose, the command(s) run, and the result.
   * `## Log` — one sentence stating that entries are appended here as commands are run, followed by no entries.

6. Create `docs/asset_inventory.md`:
   * `## Purpose` — state that this file is a lightweight inventory of important assets: what exists, why, who is accountable by role, how critical it is, what it depends on, what depends on it, and how it is validated.
   * `## Conventions` — list status values (`Draft`, `Active`, `Deprecated`, `Superseded`, `Retired`, `Unknown`), criticality values (`High`, `Medium`, `Low`, `Unknown`), and state that owner/role should name an accountable role rather than necessarily an individual, using `Unknown` when unclear.
   * `## Inventory` — a Markdown table with header row `Asset ID | Type | Purpose | Owner/Role | Status | Criticality | Dependencies | Consumers | Validation | Last Reviewed | Notes` and no data rows yet.

7. Create `docs/architecture_principles.md`:
   * `## Purpose` — state that these are reusable, source-and-tool-name-generic principles that should read the same regardless of which specific source, tool, or vendor any individual project later uses.
   * A principle list, each with its own heading, a `Rationale:` line, and a `Practical implication:` line, covering at least these ideas in your own words and without naming any tool, vendor, or source:
     * Keep boundaries between different sources or systems explicit rather than merging them implicitly.
     * Never combine sources without an explicit, documented precedence rule for which one wins on conflict.
     * Validate reusable assets repeatedly rather than trusting them once and forgetting them.
     * Defer adopting new tooling or infrastructure until a repeated, demonstrated need justifies it.
     * Keep documentation close to the work it describes, version-controlled alongside it.
     * Record meaningful decisions together with their tradeoffs, not just the choice made.
     * Prefer small, reversible changes over large, hard-to-undo ones.
     * Make unknowns explicit (for example, using `Unknown` or a backlog item) rather than inventing unsupported certainty.

8. Create `docs/architecture_operating_model.md`:
   * `## Purpose` — state that this document explains how architecture-level findings and changes get routed to a durable outcome without adding heavy process.
   * `## Decision Flow` — state that a finding that changes durable policy, tool direction, or lifecycle rules gets recorded in `docs/decisions.md` using its documented format.
   * `## Backlog Entry Rules` — state when something belongs in `docs/backlog.md` instead of a decision or question: it is real, not yet ready for execution, and does not require an immediate answer.
   * `## Finding Routing` — a table routing finding types to destinations, using only documents that exist by the end of this phase: durable policy/tool/lifecycle choice → `docs/decisions.md`; unresolved blocker or question → `docs/questions.md`; concrete deferred work → `docs/backlog.md`; asset metadata correction → `docs/asset_inventory.md`; not worth acting on → a no-action note in the relevant document.
   * `## Review Cadence` — state a lightweight recurring review practice: review new or changed assets, review items marked `Unknown`, and convert findings into the appropriate durable document on a regular cadence.

9. Create `docs/analysis_output_standards.md`:
   * `## Purpose` — state that this document defines what a finished piece of analysis or reporting work should include so a future reader can understand it without reconstructing context from memory.
   * `## Change Notes` — state that a note describing a completed piece of work should include: a plain-language summary, files changed grouped by purpose, commands run and whether they passed, generated outputs and where to find them, data assumptions or cutoff definitions where relevant, known limitations, and follow-up recommendations.
   * `## Report Standards` — state that a report should state the question it answers, the data or sources used, the main result in plain language, supporting artifacts, and limitations.
   * `## Visualization Rules` — state that visuals should be added only when they reduce explanation burden or ease comparison, and that each visual needs a clear title, a metric definition, and a documented output location.

10. Create `docs/multi_project_operating_model.md`:
    * `## Purpose` — state that this document describes the target shape for running multiple independent projects on this one platform, and that this phase only documents the model; the directories it describes are physically created in a later phase.
    * `## Shape` — state: one repository; a generic platform layer at the root (this file and its sibling governance documents); isolated project directories, each owning its own code, data, documentation, and generated outputs without merging goals or history with any other project; and a staging convention for moving files into or out of a project before they are claimed or archived.
    * `## Isolation Rule` — state that a project directory must not depend on another project's code, data, or documentation, and that only the root platform layer is shared.
    * `## Not Yet Built` — state plainly that no project directories or staging convention exist yet in this repository, and that they are introduced by a later phase, without hedging language about the absence.

11. Do not run any further steps. Stop here.

## Gate 1 (must pass before this phase is reported complete)

* `docs/` exists at the root of `TARGET_DIR`, and contains exactly: `decisions.md`, `questions.md`, `backlog.md`, `run_log.md`, `asset_inventory.md`, `architecture_principles.md`, `architecture_operating_model.md`, `analysis_output_standards.md`, `multi_project_operating_model.md` — nothing else.
* Every file above `TARGET_DIR/docs/` from Phase 0 (`AGENTS.md`, `PROJECT.md`, `.gitignore`) is unchanged.
* Each of the nine files contains all of its required headings from the Steps above, each followed by non-placeholder prose.
* No file names a specific project, dataset, vendor, or product.
* No file names a terminal, role, or handoff-based workflow mechanism.
* No file contains an unresolved placeholder token (e.g. literal `[fill in]`, `TBD`, `{{...}}`, or `lorem ipsum`).
* No file uses hedge phrases ("for now," "not yet," "currently empty") to describe an intentionally empty section; each empty section instead states its append mechanism plainly.

If any condition fails, fix it within this phase and re-check the full Gate before reporting completion. Do not report success with a failing or unchecked condition.

## Validation Commands (run from this repository's command terminal, against the external `TARGET_DIR`)

```bash
test -d "$TARGET_DIR/docs" && echo "docs/ exists"
find "$TARGET_DIR/docs" -mindepth 1 -maxdepth 1 | sort
find "$TARGET_DIR" -mindepth 1 -maxdepth 1 ! -name ".git" ! -name "docs" | sort   # expect only AGENTS.md, PROJECT.md, .gitignore
for f in decisions questions backlog run_log asset_inventory architecture_principles architecture_operating_model analysis_output_standards multi_project_operating_model; do
  test -f "$TARGET_DIR/docs/$f.md" && echo "$f.md present"
done
grep -niE "\[fill in\]|TBD|\{\{|lorem ipsum" "$TARGET_DIR"/docs/*.md; echo "exit=$? (expect 1, no matches)"
grep -niE "for now|not yet|currently empty" "$TARGET_DIR"/docs/*.md; echo "exit=$? (expect 1, no matches)"
grep -niE "terminal|handoff|planning terminal|execution terminal|command terminal" "$TARGET_DIR"/docs/*.md; echo "exit=$? (expect 1, no matches)"
git status --short   # this repository: expect no output, nothing changed
```

## Expected Outputs

* `TARGET_DIR/docs/` contains exactly the nine files listed above.
* `TARGET_DIR`'s Phase 0 files are untouched.
* This repository shows no changes in `git status`.

## Stop Conditions

Stop if:

* This handoff is still `Status: Draft` and has not been explicitly approved and moved to `docs/handoffs/approved/`.
* `TARGET_DIR` does not already contain exactly Phase 0's four items at the start.
* Completing the Gate would require adding any file or directory not listed in the Steps above — that means a later phase's work is being pulled forward; stop and report rather than expanding scope.
* Any file ends up naming a specific project, dataset, vendor, terminal, or handoff mechanism, or contains an unresolved placeholder or hedge phrase — fix it before reporting completion; if it cannot be fixed without adding out-of-scope content, stop and report why.

## What To Report Back

* Full contents of all nine generated files.
* Gate 1 command outputs, condition by condition.
* Confirmation this repository was not modified.
* Anything that required a judgment call not explicitly covered by the Steps above (so it can be tightened before Phase 2 is drafted).
