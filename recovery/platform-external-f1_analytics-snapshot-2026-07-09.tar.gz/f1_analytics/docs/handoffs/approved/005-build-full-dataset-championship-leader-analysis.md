# Handoff 005: Build Full Dataset And Championship Leader Analysis

Status: Completed

## Goal

Build the first simple, reusable F1 analytics dataset and produce the first deliverable: a time-analysis report answering how often the driver and constructor leading at this point in the season went on to win the championship.

## Success Criteria

* Raw Kaggle CSVs are loaded from `data/raw/f1_complete_dataset/`.
* A local DuckDB database is created under `data/processed/`.
* Clean, reusable tables are created for races, results, drivers, constructors, cumulative driver standings, and cumulative constructor standings.
* A first report is written under `outputs/reports/`.
* Supporting CSV outputs are written under `outputs/tables/`.
* The analysis clearly states the cutoff point used for "this point in the season."
* The analysis covers both drivers and constructors.
* The implementation stays simple: pandas plus DuckDB, no dbt, Airflow, dashboard, notebook, or ML.

## Relevant Project Context

Version 1 should prove an end-to-end pattern:

1. Ingest Formula 1 data.
2. Build reusable cleaned tables.
3. Run basic analysis.
4. Validate important assumptions.
5. Produce one clear insight story.

The first insight question is:

* How many times has the driver or drivers in first place at this point in the season gone on to win the drivers' championship?
* How many times has the constructor or constructors in first place at this point in the season gone on to win the constructors' championship?

As of this planning pass, local raw files include the selected Kaggle dataset in `data/raw/f1_complete_dataset/`. A quick inspection showed results for the 2026 season through round 3, while `f1_races.csv` includes future 2026 scheduled races. The analysis must therefore define "this point in the season" from completed results available in `f1_results.csv`, not from scheduled future races.

## Decisions Already Made

* Use KaggleHub for dataset access.
* Keep raw data out of Git.
* Keep Version 1 lightweight and locally runnable.
* Use simple, elegant data preparation before adding heavier tools.
* Defer dbt, Airflow, dashboards, and ML until the local workflow is stable.

## Files Expected To Change

* `.gitignore`, only if needed for processed data or output ignores.
* `docs/active_context.md`
* `docs/questions.md`
* `docs/run_log.md`
* `docs/implementation_notes/005-build-full-dataset-championship-leader-analysis.md`
* `scripts/build_f1_dataset.py`
* `scripts/analyze_championship_leaders.py`

## Directories Expected To Be Created

* `outputs/reports/`
* `outputs/tables/`

## Files Expected To Be Generated

These files should be ignored by Git unless a later decision says curated outputs should be tracked:

* `data/processed/f1_analytics.duckdb`
* `outputs/reports/championship_leader_conversion.md`
* `outputs/tables/driver_leader_conversion.csv`
* `outputs/tables/constructor_leader_conversion.csv`
* `outputs/tables/current_season_leaders.csv`
* `outputs/tables/data_coverage_summary.csv`

## Files That Should Not Change

* `AGENTS.md`
* `PROJECT.md`
* `docs/project_profile.md`
* `docs/terminal_protocol.md`
* `docs/terminal_roles/*`
* Existing approved handoffs

## Assumptions Not To Revisit

* Use the local Kaggle dataset already downloaded into `data/raw/f1_complete_dataset/`.
* Use the `points` field in `f1_results.csv` as the source for race-level championship points.
* Build cumulative standings from race results instead of relying on final standings files for in-season standings.
* Use final championship standings files only to identify final champions and validate final-season totals where useful.
* Treat tied leaders at the cutoff round as co-leaders; the question asks about the driver or drivers in first place.

## Implementation Steps

1. Read `AGENTS.md`, `PROJECT.md`, `docs/active_context.md`, `docs/questions.md`, and this handoff.
2. Confirm this handoff is approved before implementing. Stop if it is still `Status: Draft` or still under `docs/handoffs/drafts/`.
3. Confirm the raw files exist under `data/raw/f1_complete_dataset/`:
   * `f1_races.csv`
   * `f1_results.csv`
   * `f1_drivers.csv`
   * `f1_constructors.csv`
   * `f1_driver_standings.csv`
   * `f1_constructor_standings.csv`
4. Create `scripts/build_f1_dataset.py`:
   * Load the raw CSV files with pandas.
   * Normalize column names only if needed; avoid unnecessary renaming.
   * Coerce key fields like `season`, `round`, `position`, and `points` to usable numeric types.
   * Write raw and curated tables into `data/processed/f1_analytics.duckdb`.
   * Build `race_results_enriched` by joining results to race dates and metadata.
   * Build `driver_standings_by_round` from cumulative driver points and wins by season and round.
   * Build `constructor_standings_by_round` from cumulative constructor points and wins by season and round.
   * Include deterministic rank fields where ties share rank 1 when points and wins are equal.
5. Create `scripts/analyze_championship_leaders.py`:
   * Read from `data/processed/f1_analytics.duckdb`.
   * Determine the target season as the maximum season with any completed results.
   * Determine the cutoff round as the maximum completed round in that target season.
   * Determine the cutoff race name and date from `f1_races.csv`.
   * Create a data coverage summary that contrasts scheduled races vs completed-result races for the target season.
   * For each historical completed season before the target season, compare leaders after the same cutoff round with final champions.
   * Exclude seasons with fewer completed races than the cutoff round.
   * Produce separate driver and constructor conversion tables.
   * Report tied leaders explicitly.
   * Report the current target-season leaders separately because the championship outcome is not yet known.
6. Write a Markdown report at `outputs/reports/championship_leader_conversion.md` with:
   * The question being answered.
   * The cutoff definition.
   * Driver conversion result.
   * Constructor conversion result.
   * Current target-season leaders at the cutoff point.
   * Data limitations and next improvements.
7. Write supporting CSV outputs under `outputs/tables/`.
8. Update `docs/questions.md` so the first deliverable is marked as answered or narrowed to this time-analysis report.
9. Update `docs/active_context.md` so the next action is command-terminal validation of the dataset build and report generation.
10. Record implementation notes in `docs/implementation_notes/005-build-full-dataset-championship-leader-analysis.md`.
11. Append a concise entry to `docs/run_log.md` listing validation commands to run.

## Analysis Rules

* "This point in the season" means the latest completed round available in `f1_results.csv` for the latest season in the local dataset.
* If the latest season is incomplete, do not treat it as part of the historical conversion denominator.
* For historical seasons, use the same round number as the cutoff.
* Include all co-leaders at the cutoff round if tied for first.
* Count a season as a driver conversion if any cutoff-round driver leader became that season's drivers' champion.
* Count a season as a constructor conversion if any cutoff-round constructor leader became that season's constructors' champion.
* Constructors' championship analysis should begin only with seasons where constructor championship data exists.
* State any data coverage gap clearly, especially if the latest local results lag the real-world calendar date.

## Command Terminal Validation Commands

Run these from the project root:

```bash
pwd
source .venv/bin/activate
python scripts/build_f1_dataset.py
python scripts/analyze_championship_leaders.py
test -f data/processed/f1_analytics.duckdb && echo "duckdb built"
test -f outputs/reports/championship_leader_conversion.md && echo "report built"
find outputs -maxdepth 3 -type f | sort
python - <<'PY'
from pathlib import Path
report = Path("outputs/reports/championship_leader_conversion.md")
text = report.read_text(encoding="utf-8")
required = [
    "cutoff",
    "Drivers",
    "Constructors",
    "Current",
    "limitations",
]
missing = [word for word in required if word.lower() not in text.lower()]
if missing:
    raise SystemExit(f"report missing expected terms: {missing}")
print("report content smoke test passed")
PY
git status --short
```

## Expected Outputs

* `data/processed/f1_analytics.duckdb` exists.
* The Markdown report exists and states the cutoff round, target season, driver result, constructor result, and limitations.
* Supporting CSV tables exist under `outputs/tables/`.
* Raw and processed data remain ignored by Git.
* The repo is ready for the next handoff: refine the analysis narrative and optionally create a polished visualization.

## Stop Conditions

Stop if:

* This handoff is still in `docs/handoffs/drafts/`.
* This handoff still has `Status: Draft`.
* Raw data files are missing.
* The local dataset does not contain enough race-level results to build cumulative standings.
* The points data cannot support cumulative standings without a new scoring-system decision.
* The implementation would require dbt, Airflow, dashboarding, ML, or a broader project structure decision.

## What To Report Back

Report:

* Files changed.
* The target season and cutoff round detected.
* The generated report path.
* The generated CSV output paths.
* Any data coverage limitations.
* Exact validation commands for the command terminal.
