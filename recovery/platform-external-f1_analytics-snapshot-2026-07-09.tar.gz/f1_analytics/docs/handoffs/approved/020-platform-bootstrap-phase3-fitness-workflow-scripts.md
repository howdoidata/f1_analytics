# Handoff 020: Platform Bootstrap — Phase 3 (Fitness-Check and Workflow Scripts)

Status: Approved

Project: platform

## Goal

Add `scripts/fitness_check.py` and `scripts/workflow.py` to the existing platform scaffold (Phases 0-2 already built). These are the mechanical tools that check the Phase 2 process/documentation invariants against live repository state and route "what do I do now" by intent. Then correct every sentence in the Phases 1-2 documents that currently says this tooling "is added by a later phase" or similar, now that this phase adds it. Nothing else.

Everything from "Execution Contract" onward must be followable by a system with no access to this repository's history, decisions, or logged context — only this document and the `TARGET_DIR` parameter below.

## Success Criteria

See Gate 3 below — that checklist is the complete, sole definition of done for this phase.

## Assumptions Not To Revisit

* Do not create `projects/` or `exchange/` directories in this phase — those belong to Phase 4.
* Do not modify any Phase 0-2 file except the five files and exact sentences/sections named in Steps 3-7 below.
* `TARGET_DIR` is the same directory Phases 0-2 built into; it already contains exactly the Phase 0-2 fileset described in Step 1 before this phase starts.
* Do not consult, copy, or paraphrase this repository's own `scripts/fitness_check.py` or `scripts/workflow.py`. Write `TARGET_DIR`'s versions fresh, using this handoff's own instructions — which describe each check's purpose and exact pass/fail condition against `TARGET_DIR`'s own already-built documents — as the sole source of required content.
* Scripts must use only the Python 3 standard library. Do not add a `requirements.txt` or any third-party dependency.
* None of the new or edited files may name a specific project, dataset, vendor, or product.
* None of the new or edited files may contain an unresolved placeholder token (e.g. literal `[fill in]`, `TBD`, `{{...}}`, or `lorem ipsum`).

## Inputs (set by the user before execution)

| Parameter | Meaning | Value for this run |
|---|---|---|
| `TARGET_DIR` | Existing platform directory Phases 0-2 built into | `/Users/antonio/Documents/howdoidata/projects/platform` |

## Files Expected To Change (in this repository)

None.

## Files That Should Not Change (in this repository)

Everything. This repository is read-only for the purpose of this handoff.

---

# THE SPECIFICATION

Everything below this line is the self-contained Phase 3 build instruction. It assumes no other context.

## Execution Contract

1. Confirm `TARGET_DIR` exists and contains exactly this fileset before doing anything else. If anything is missing or anything extra is present, stop and report — do not add, remove, or modify anything to force a match.
   * Root: `.git/`, `.gitignore`, `AGENTS.md`, `PROJECT.md`, `docs/`.
   * `docs/` top level: `decisions.md`, `questions.md`, `backlog.md`, `run_log.md`, `asset_inventory.md`, `architecture_principles.md`, `architecture_operating_model.md`, `analysis_output_standards.md`, `multi_project_operating_model.md`, `active_context.md`, `terminal_protocol.md`, `workflow_guide.md`, `terminal_roles/`, `handoffs/`, `implementation_notes/`, `inbox/`, `prompts/`.
   * `docs/terminal_roles/`: `planning.md`, `execution.md`, `command.md`.
   * `docs/handoffs/`: `README.md`, empty `drafts/`, empty `approved/`.
   * `docs/implementation_notes/`: `README.md`.
   * `docs/inbox/`: `README.md`, empty `processed/`.
   * `docs/prompts/`: `planning_prompt.txt`, `execution_prompt.txt`, `command_prompt.txt`.
2. Perform the steps below in order. Do not add files or directories beyond what is listed.
3. Where this specification states a requirement in prose, write original code or text satisfying that requirement. Do not leave bracketed placeholders, "TBD," or lorem-ipsum-style filler.
4. Do not reference any specific project, product, dataset, vendor, or client anywhere in the files you write or edit.
5. Every check described below must produce a human-readable failure detail (what was wrong, not just that something failed) when it fails.

## Steps

1. Create `scripts/fitness_check.py`, an argument-free command-line script with no third-party imports. It must define and run, in this order, the following named checks, each producing a pass/fail result with an optional detail string:

   * **`required_docs_exist`** — A fixed list of the paths named in Step 1's precondition inventory above (everything under `docs/` plus `AGENTS.md` and `PROJECT.md`; directories checked for existence as directories, files as files) must all exist relative to the repository root. Fail listing whichever are missing.
   * **`required_docs_match_protocol_list`** — Read the `## Source Of Truth` section of `docs/terminal_protocol.md` and extract every backtick-quoted path it lists. Every path from the fixed list used by `required_docs_exist` must be covered by that extracted set (an entry ending in `/` covers itself and anything nested under it). Fail listing any path from the fixed list that the document's list does not cover. This check exists to catch drift between the script's notion of "required" and what the document actually states, so the two are never allowed to silently diverge.
   * **`handoff_status_validity`** — For every Markdown file under `docs/handoffs/drafts/` and `docs/handoffs/approved/`: it must contain a line matching `Status:` followed by one of exactly `Draft`, `Needs Revision`, `Approved`, `Completed`, `Rejected`, `Superseded` (as stated in `docs/handoffs/README.md`); a file in `drafts/` must have status `Draft` or `Needs Revision`; a file in `approved/` must have status `Approved`, `Completed`, `Rejected`, or `Superseded`; a file whose status is `Needs Revision` must additionally contain a heading line matching `## Revision Note` (case-sensitive on "Revision Note", tolerant of a trailing date or other text on the same line). Fail listing each violation with the filename and what was wrong.
   * **`supersede_references_valid`** — Collect the filenames of every handoff under `drafts/` and `approved/`. For every `Supersedes:` or `Superseded by:` line found in any handoff file, the filename it names must be one of the collected filenames. Separately, for every `Supersedes:`/`Superseded by:` line found in `docs/decisions.md`, the text it names must match some `###` heading title elsewhere in that same file (decision entries are written as `###` headings nested under the file's `## Log` section — see the `decision_entries_well_formed` check below for why). Fail listing each reference that points at something that does not exist.
   * **`decision_entries_well_formed`** — Under the `## Log` heading of `docs/decisions.md`, treat every `###` heading as one decision entry running until the next `###` heading or end of file. Each such entry's body must contain all four of `Decision:`, `Rationale:`, `Tradeoffs:`, `Status:`. If `## Log` contains no `###` headings yet, this check passes trivially (an empty log is valid). Fail listing each entry (by its heading text) that is missing one or more required fields.
   * **`handoff_status_enum_consistent`** — The `## Status` section of `docs/handoffs/README.md` must list exactly the six values `Draft`, `Needs Revision`, `Approved`, `Completed`, `Rejected`, `Superseded` (in any order, any formatting, as long as all six and only those six appear as the enumerated values). Separately, `docs/terminal_protocol.md` must not itself itemize that same status list a second time (its `## Decision And Handoff Status` section should describe the lifecycle in prose, not duplicate the enum) — fail if it does, since the enum's one canonical location is `docs/handoffs/README.md`.
   * **`role_docs_have_required_inputs`** — Each of `docs/terminal_roles/planning.md`, `execution.md`, `command.md` must contain a section (`## Required Inputs` or `## Source of Truth`) whose body mentions `AGENTS.md`, `PROJECT.md`, and `docs/active_context.md`. Fail listing which role file is missing which reference.
   * **`prompts_point_to_role_docs`** — `docs/prompts/planning_prompt.txt` must contain the string `docs/terminal_roles/planning.md`; `execution_prompt.txt` must contain `docs/terminal_roles/execution.md`; `command_prompt.txt` must contain `docs/terminal_roles/command.md`. Fail listing which prompt file is missing its pointer.
   * **`inbox_items_triaged`** — `docs/inbox/` must contain only `README.md` and `processed/` at its top level; nothing else untriaged. Fail listing any other entry found.
   * **`completed_handoffs_not_approved`** — For every handoff under `docs/handoffs/approved/` whose filename starts with a numeric ID matching the numeric-ID prefix of a file already present under `docs/implementation_notes/` (excluding `README.md`), that handoff's `Status:` must not still read `Approved` (it should have moved on to `Completed` or another terminal status once implementation notes exist for it). Fail listing any handoff left `Approved` despite a matching implementation note existing.

   The script must print one line per check in the form `[PASS] <check_name>` or `[FAIL] <check_name> -- <detail>`, in the order listed above, followed by a summary line `Fitness checks: <n> run, <k> failed`. It must exit with status `0` if every check passed and `1` if any check failed.

   After printing results, the script must append one entry to `docs/run_log.md`, consistent with that file's own stated format (purpose, command run, result observed): the entry names its purpose as recording the standing process fitness check, shows the command `python3 scripts/fitness_check.py`, and states the timestamp, the summary line, and either "No issues." or the list of failing check names with their details. Insert the new entry directly under the `## Log` heading, above any existing entries, so the file reads newest-first.

2. Create `scripts/workflow.py`, a read-only, argument-optional command-line script with no third-party imports (it may import from `fitness_check.py` in the same directory). Running it with no arguments must:

   * Run every check from `scripts/fitness_check.py` and print the same `Fitness: <n> run, <k> failed` summary plus any failing check names and details, without re-appending a second run-log entry (only direct invocation of `fitness_check.py` self-records; `workflow.py` reads results in memory).
   * Print the current `## Current Focus` section body from `docs/active_context.md`.
   * Print the current `## Next Action` section body from `docs/active_context.md`.
   * List every file under `docs/handoffs/drafts/` whose status is `Draft` or `Needs Revision`, with its status shown.
   * List every file under `docs/handoffs/approved/` whose status is `Approved` (not yet `Completed`), with its status shown.
   * Print the filename of the implementation note with the highest numeric ID under `docs/implementation_notes/` (excluding `README.md`), or state that none exist.

   The script must also accept an optional `--intent` flag with choices `architecture`, `analysis`, `execution`, `command`, `revise`. When passed, it prints one additional line recommending a terminal: `architecture` and `analysis` both route to the planning terminal (point at `docs/terminal_roles/planning.md`); `execution` routes to the execution terminal (`docs/terminal_roles/execution.md`); `command` routes to the command terminal (`docs/terminal_roles/command.md`); `revise` points at the revise-vs-supersede procedure in `docs/terminal_protocol.md`. The script must exit `1` if any fitness check failed and `0` otherwise; it must not write to any file.

3. Edit `docs/terminal_protocol.md`. In the `## Source Of Truth` section, replace the sentence "Mechanically checking this list against repository state is added by a later phase; until then, treat it as a manual reference to confirm at the start of a session." with a sentence stating plainly that running `python3 scripts/fitness_check.py` mechanically checks this list against repository state, so it no longer needs confirming by hand.

4. Edit `docs/workflow_guide.md`. Replace the `## Manual Routing` heading and its body (which currently states a later phase adds a status-router script) with a section stating that `python3 scripts/workflow.py` reports process fitness, current focus, next action, pending draft and approved handoffs, and the latest implementation note, and that passing `--intent {architecture,analysis,execution,command,revise}` gives a direct terminal recommendation.

5. Edit `docs/active_context.md`:
   * In `## Current Repo State`, add `scripts/fitness_check.py` and `scripts/workflow.py` to the listed contents.
   * Rewrite `## Current Focus` to state plainly that the fitness-check and workflow-router scripts were just added, and that no decisions, questions, or handoffs have been recorded yet because none have been needed so far (preserve this second clause if it remains true; otherwise state the actual current state).
   * Rewrite `## Next Action` to state that running `python3 scripts/workflow.py` is now how to confirm current state, fitness, and the next action (rather than reading the documents by hand), and that the next platform-bootstrap phase adds the multi-project layer (`projects/`, a project template/generator, and the `exchange/` staging convention).

6. Edit `docs/prompts/planning_prompt.txt`. Replace the sentence "Have the command terminal run the standing fitness check first. A later phase adds a mechanical script for this; until then, manually compare repository state against the source-of-truth list in docs/terminal_protocol.md." with an instruction to have the command terminal run `python3 scripts/fitness_check.py` first and resolve any failure before proceeding, noting that this mechanically checks the source-of-truth list in `docs/terminal_protocol.md` against current repository state.

7. Edit `docs/prompts/command_prompt.txt`. In its trailing removable session-detail guide, replace the clause "The standing fitness check can also be run here once a later phase adds its script." with a statement that the standing fitness check can also be run here with `python3 scripts/fitness_check.py`.

8. Do not run any further steps. Stop here.

## Gate 3 (must pass before this phase is reported complete)

* `scripts/` exists at the root of `TARGET_DIR` and contains exactly `fitness_check.py` and `workflow.py`.
* Running `python3 scripts/fitness_check.py` from `TARGET_DIR` exits `0` and prints `[PASS]` for every check (the Phase 0-2 output must already satisfy its own invariants).
* Running `python3 scripts/fitness_check.py` a second time appends a new dated entry to `docs/run_log.md` above the previous one, and does not otherwise modify any file.
* Running `python3 scripts/workflow.py` from `TARGET_DIR` exits `0`, prints the fitness summary, `Current Focus`, `Next Action`, empty draft/approved handoff lists, and states no implementation note exists yet.
* Running `python3 scripts/workflow.py --intent architecture` (and each other `--intent` value) prints one additional route line and exits `0`.
* Neither script writes to any file other than `fitness_check.py` appending to `docs/run_log.md`.
* `docs/terminal_protocol.md`, `docs/workflow_guide.md`, `docs/active_context.md`, `docs/prompts/planning_prompt.txt`, and `docs/prompts/command_prompt.txt` no longer contain the phrase "later phase" anywhere in connection with the fitness-check or workflow-router tooling.
* Every file and directory from Phases 0-2 other than the five files edited in Steps 3-7 is byte-for-byte unchanged.
* None of the files created or edited in this phase name a specific project, dataset, vendor, or product, or contain an unresolved placeholder token.
* This repository (the one holding this handoff) shows no changes in `git status`.

If any condition fails, fix it within this phase and re-check the full Gate before reporting completion. Do not report success with a failing or unchecked condition.

## Validation Commands (run from this repository's command terminal, against the external `TARGET_DIR`)

```bash
find "$TARGET_DIR/scripts" -type f | sort   # expect fitness_check.py, workflow.py only
cd "$TARGET_DIR" && python3 scripts/fitness_check.py; echo "exit=$?"   # expect all PASS, exit=0
cd "$TARGET_DIR" && python3 scripts/fitness_check.py; echo "exit=$?"   # run twice; expect a second run_log.md entry
cd "$TARGET_DIR" && python3 scripts/workflow.py; echo "exit=$?"        # expect exit=0
cd "$TARGET_DIR" && python3 scripts/workflow.py --intent architecture; echo "exit=$?"
cd "$TARGET_DIR" && python3 scripts/workflow.py --intent execution; echo "exit=$?"
cd "$TARGET_DIR" && python3 scripts/workflow.py --intent command; echo "exit=$?"
cd "$TARGET_DIR" && python3 scripts/workflow.py --intent revise; echo "exit=$?"
grep -ni "later phase" "$TARGET_DIR/docs/terminal_protocol.md" "$TARGET_DIR/docs/workflow_guide.md" "$TARGET_DIR/docs/active_context.md" "$TARGET_DIR/docs/prompts/planning_prompt.txt" "$TARGET_DIR/docs/prompts/command_prompt.txt"; echo "exit=$? (expect 1, no matches)"
git status --short   # this repository: expect no output, nothing changed
git -C "$TARGET_DIR" status --short   # informational only; new/modified files are expected and not committed by this handoff
```

## Expected Outputs

* `TARGET_DIR/scripts/fitness_check.py` and `TARGET_DIR/scripts/workflow.py` exist and behave as specified.
* `TARGET_DIR/docs/run_log.md` gains one new entry per `fitness_check.py` invocation.
* `TARGET_DIR/docs/terminal_protocol.md`, `docs/workflow_guide.md`, `docs/active_context.md`, `docs/prompts/planning_prompt.txt`, and `docs/prompts/command_prompt.txt` are edited exactly as described in Steps 3-7; no other Phase 0-2 file changes.
* This repository shows no changes in `git status`.

## Stop Conditions

Stop if:

* This handoff is still `Status: Draft` or `Status: Needs Revision` and has not been explicitly (re-)approved and moved to `docs/handoffs/approved/`.
* `TARGET_DIR` does not already contain exactly the Phase 0-2 fileset described in Step 1 at the start.
* Any Phase 0-2 fitness-equivalent check would fail before this phase's scripts are even added (this would mean Phase 2's own output was not actually gate-clean, which is outside this phase's scope to fix) — stop and report rather than silently repairing Phase 0-2 content.
* Completing the Gate would require adding any file or directory not listed in the Steps above (for example, anything under `projects/` or `exchange/`) — that means a later phase's work is being pulled forward; stop and report rather than expanding scope.
* A script would require a third-party dependency to satisfy a check as specified — stop and report rather than adding one.
* Any file ends up naming a specific project, dataset, or vendor, or contains an unresolved placeholder — fix it before reporting completion; if it cannot be fixed without adding out-of-scope content, stop and report why.

## What To Report Back

* Full contents of `scripts/fitness_check.py` and `scripts/workflow.py`.
* A diff (or before/after excerpt) of each of the five edited files.
* Gate 3 command outputs, condition by condition.
* Confirmation this repository was not modified.
* Anything that required a judgment call not explicitly covered by the Steps above — in particular, whether decision entries in `docs/decisions.md` are in fact being written as `###` headings nested under `## Log` (this handoff assumes that nesting since Phase 1 left the exact heading level for future entries unstated; if a different convention was actually used, `decision_entries_well_formed` and `supersede_references_valid` need to be corrected before Phase 4 is drafted).
