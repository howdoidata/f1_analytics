# Handoff 007: Jolpica/Ergast Integration And Kaggle Schema Validation

Status: Completed

## Goal

Treat Jolpica/Ergast as a fully loaded, separate data source (not a future item, not a backfill mechanism), add concrete schema/dtype validation for the Kaggle baseline, and establish a repeatable pattern for keeping both sources loaded side by side with a clear, auditable way to see where they agree, disagree, or where one has data the other lacks.

## Relevant Project Context

* Kaggle CSV is the Version 1 baseline source (`docs/decisions.md`, 2026-07-08 entry). This does not change.
* Jolpica/Ergast is documented in `docs/data_sources.md` and has a minimal client skeleton at `src/f1_analytics/data_sources/jolpica.py` (`build_endpoint_url`, `fetch_json`). No API data has been pulled or persisted yet.
* `source_registry` currently marks Jolpica as `documented_not_loaded` (`src/f1_analytics/data_sources/kaggle_csv.py:182-190`).
* `docs/backlog.md` lists "Jolpica/Ergast freshness or gap-fill checks after a specific need is identified" as deferred. A concrete need now exists (see below) — this item should move out of deferred, not stay there.

### Concrete gap identified this session

Verified directly against the raw CSVs in `data/raw/f1_complete_dataset/`:

* `f1_races.csv` lists the full 2026 calendar (22 rounds) including rounds already run as of today (2026-07-08), e.g. round 9, British Grand Prix, dated 2026-07-05.
* `f1_results.csv` and `f1_qualifying.csv` only contain 2026 data through round 3 (66 result rows = 3 races x 22 drivers).
* This means the Kaggle snapshot is stale for the current season by roughly 6 races' worth of results/qualifying data as of this session. This is the specific, present need that justifies loading Jolpica now, not deferring it.

### Additional schema/quality findings (Kaggle baseline)

* `data/raw/f1_complete_dataset/f1_circuits.csv` and `f1_qualifying.csv` exist on disk but are not in `RAW_FILES` in `src/f1_analytics/data_sources/kaggle_csv.py:25-32` and are never loaded into DuckDB. They are silently unused today.
* `f1_driver_standings.csv` has no `constructor_id` column, only a free-text `constructor` name column, unlike `f1_results.csv` and `f1_constructor_standings.csv` which key on `constructor_id`. Joining driver standings to the constructors dimension currently requires name matching, which is fragile across constructor renames/rebrands.
* `fastest_lap` / `fastest_lap_rank` in `f1_results.csv` are blank for ~66% of rows (pre-fastest-lap-tracking era). `time` in `f1_races.csv` is blank for ~62% of rows (older races). These are expected null patterns, not currently asserted anywhere.
* No row-count, null-rate, or referential-integrity checks run today. `write_dataframe` in `src/f1_analytics/database/duckdb_io.py:25-32` does a blind `CREATE OR REPLACE TABLE ... AS SELECT *` with no validation step.

## Success Criteria

* Jolpica/Ergast has a working loader that pulls current-season results/qualifying/standings data and persists it into DuckDB as `raw_jolpica_*` tables, landed the same way Kaggle raw tables are landed (via `write_dataframe`, `register_source`, `log_source_load`).
* Jolpica data is never merged into or used to overwrite `results`, `races`, or any other Kaggle-derived curated table. It lands in its own tables only.
* A coverage/comparison view or table exists showing, per season and round, whether Kaggle has results, whether Jolpica has results, and where they diverge (row counts, or presence/absence). This must surface the 2026 rounds-4-9 gap concretely.
* `docs/backlog.md` and `docs/data_sources.md` are updated so Jolpica is no longer described as deferred or "not yet used."
* Kaggle raw tables gain basic validation: null-rate assertions on columns expected to be fully populated (`season`, `round`, `driver_id`, `position`, `points` in results; `driver_id`, `constructor_id` in constructors/drivers dimension tables), and a referential check that `driver_id`/`constructor_id`/`circuit_id` values in fact tables exist in their dimension tables. Failures are logged, not silently ignored.
* A decision is recorded for `f1_circuits.csv` and `f1_qualifying.csv`: either load them as raw/curated tables or explicitly document why they remain unused.
* A decision is recorded for the `driver_standings` constructor-name-only join problem: either add a name-to-`constructor_id` reconciliation step with documented mismatches, or explicitly document the limitation.
* No dbt, Airflow, dashboard, notebook, or ML scaffold is introduced.

## Assumptions Not To Revisit

* Kaggle CSV remains the Version 1 baseline; Jolpica is additive and separate, never a silent backfill of Kaggle tables.
* DuckDB remains the local analytical database.
* Shared Python lives under `src/f1_analytics/`; reusable SQL lives under `sql/`.
* Jolpica requires no authentication; treat it as a public, rate-limited API — cache raw JSON responses to disk before transforming, and pace requests conservatively.
* Where Kaggle and Jolpica both have data for the same season/round, Kaggle remains authoritative for curated tables; Jolpica is surfaced separately for comparison, not used to mutate Kaggle-derived rows.

## Files Likely To Change

* `docs/data_sources.md`
* `docs/architecture.md`
* `docs/decisions.md`
* `docs/backlog.md`
* `docs/questions.md`
* `docs/active_context.md`
* `docs/diagrams/project_structure.mmd`
* `src/f1_analytics/data_sources/jolpica.py`
* `src/f1_analytics/data_sources/kaggle_csv.py` (only to add circuits/qualifying loading and validation hooks, not to change existing curated table logic)
* `src/f1_analytics/database/duckdb_io.py` (only to add validation/logging helpers)
* `requirements.txt`, only if a small addition is needed (e.g. `requests`, if preferred over `urllib`)

## Files/Directories Likely To Be Created

* `src/f1_analytics/data_sources/jolpica_loader.py` (or similar) for fetching and shaping Jolpica responses into DataFrames
* `src/f1_analytics/validation/` with basic null-rate and referential-integrity check helpers, or equivalent module under an existing package if a whole new package is unwarranted
* `sql/curated/` or `sql/analysis/` query for the Kaggle-vs-Jolpica coverage comparison
* `scripts/pull_jolpica_data.py` as a thin command-line wrapper, matching the existing `scripts/build_f1_dataset.py` pattern
* `data/raw/jolpica/` for cached raw JSON responses (gitignored, matching `data/raw/f1_complete_dataset/` handling)
* `docs/implementation_notes/007-jolpica-integration-and-kaggle-validation.md`

## Files That Should Not Change

* `AGENTS.md`
* `PROJECT.md`
* `docs/terminal_protocol.md`
* `docs/terminal_roles/*`
* Existing approved handoffs
* Raw Kaggle CSV files
* Curated Kaggle table logic in `build_curated_tables` (`src/f1_analytics/data_sources/kaggle_csv.py:77-156`) beyond adding circuits/qualifying and validation hooks

## Open Decisions For The User Before Approval

1. Load `f1_circuits.csv` and `f1_qualifying.csv` into DuckDB now (low effort, already present locally), or explicitly defer with a documented reason?
2. For the `driver_standings` constructor-name join gap: add a reconciliation step now, or document as a known limitation and defer?
3. Which Jolpica endpoints are in scope for this handoff — results and qualifying only (directly answers the identified gap), or also standings/laps/pitstops?
4. Should the coverage/comparison output be a DuckDB view, a materialized table, or a Markdown report under `outputs/reports/`?

## Draft Validation Commands (subject to change once approved)

```bash
pwd
source .venv/bin/activate
python -m compileall scripts src
python scripts/build_f1_dataset.py
python scripts/pull_jolpica_data.py
python scripts/analyze_championship_leaders.py
test -f data/processed/f1_analytics.duckdb && echo "duckdb built"
python - <<'PY'
import duckdb
conn = duckdb.connect("data/processed/f1_analytics.duckdb", read_only=True)
print(conn.execute("SELECT * FROM source_registry").fetchdf())
print(conn.execute("SELECT source_name, table_name, row_count FROM source_load_log ORDER BY loaded_at DESC LIMIT 20").fetchdf())
PY
git status --short
```

## Stop Conditions

Stop if:

* This handoff is still in `docs/handoffs/drafts/` or still has `Status: Draft`.
* Jolpica requires authentication, payment, or a materially different API shape than documented.
* The open decisions above are not answered before execution begins.
* Implementing this would require merging Jolpica data into Kaggle curated tables (that would violate the "separate source, not backfill" requirement and needs a new decision).
* The task would introduce dbt, Airflow, dashboarding, notebooks, or ML.

## What To Report Back

* Which Jolpica endpoints were loaded and into which DuckDB tables.
* Confirmation that no Kaggle curated table was mutated by Jolpica data.
* The coverage comparison result for the 2026 season gap specifically.
* Validation results for the new Kaggle null-rate/referential checks, including any failures found.
* Resolution recorded for `f1_circuits.csv`, `f1_qualifying.csv`, and the driver-standings constructor-name join gap.
