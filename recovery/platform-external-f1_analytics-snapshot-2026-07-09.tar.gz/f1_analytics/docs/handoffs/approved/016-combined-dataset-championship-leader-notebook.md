# Handoff 016: Combined-Dataset Championship Leader Notebook

Status: Completed

## Goal

Build the scoped combined Kaggle+Jolpica dataset defined in the 2026-07-09 decision ("Add a scoped, precedence-ruled combined dataset for current-season leader identification"), use it to find the true current-season cutoff, and answer — in a Jupyter notebook for user review — how many times the driver(s)/constructor(s) in first place at that point in the season went on to win the championship. Document any deviations between Kaggle and Jolpica for the current season.

## Relevant Project Context

The existing `championship_leader_conversion.md` / `championship_leader_followup.md` reports already answer this project's core question, but they are pinned to the Kaggle-only cutoff (round 3 for the 2026 season) because `f1_results.csv` only covers rounds 1-3. `kaggle_jolpica_coverage` already shows Jolpica has real results/qualifying through round 9 for 2026 (rounds 1-3 `match`, rounds 4-9 `jolpica_only`). "This point in the season" should reflect the most complete data available, not an artificially early cutoff, per the new decision.

## Revision Note (2026-07-09)

Checked `docs/asset_inventory.md` for an existing asset meeting this handoff's exact criteria (a scoped, precedence-ruled combined Kaggle+Jolpica dataset for current-season leader identification). None exists: `duckdb_processed_database` covers only raw/curated tables, and `jolpica_raw_source`'s own notes state Jolpica data is "Never merged into Kaggle curated tables without a future source-precedence decision." The 2026-07-09 combined-dataset decision supplies that precedence rule but no table built under it exists yet. This confirms the handoff's scope is correct as new work — `combined_results`, `combined_driver_standings_by_round`, and `combined_constructor_standings_by_round` must be created, not adapted from an existing asset.

The two insight questions (unchanged from Handoff 005):

* How many times has the driver or drivers in first place at this point in the season gone on to win the drivers' championship?
* How many times has the constructor or constructors in first place at this point in the season gone on to win the constructors' championship?

## Decisions Already Made

* 2026-07-09 — Add a scoped, precedence-ruled combined dataset for current-season leader identification (`docs/decisions.md`): Kaggle wins on any season/round overlap; Jolpica fills only season/rounds where Kaggle has zero rows; `row_count_diverges` rows are surfaced, never silently resolved; existing Kaggle-only curated tables are unchanged.
* Kaggle CSV remains the baseline/authoritative source for curated tables generally; this combined dataset is additive and scoped to current-season leader identification only.
* Notebook, dashboard, and visualization polish were previously deferred "until a later handoff" (`docs/questions.md`, "Version 1 output format"). This is that handoff for the notebook specifically; dashboard and Tableau-ready polish remain deferred.
* `docs/analysis_output_standards.md` requires chart/analysis code to live in reusable modules or scripts, not only in notebooks ("Avoid isolated notebooks" in `PROJECT.md`; "Keep chart code in analysis modules or scripts, not only in notebooks" in the standards doc).

## Assumptions Not To Revisit

* The combined tables are additive only. Do not modify `results`, `driver_standings_by_round`, `constructor_standings_by_round`, `final_driver_standings`, `final_constructor_standings`, or any existing script's current behavior/output paths.
* Reuse the existing cumulative-points/wins/standing-rank logic (currently `add_standing_rank` and the groupby/cumsum pattern in `src/f1_analytics/data_sources/kaggle_csv.py`) for the combined tables instead of writing a second, parallel implementation. Refactor it into a shared, importable location if needed to avoid duplicating it.
* Reuse the existing `kaggle_jolpica_coverage` view as the source of deviations (`row_count_diverges`, `kaggle_only`, `jolpica_only`, `no_data`). Do not build a second, duplicate coverage view.
* The notebook must import and call reusable functions from `src/f1_analytics/analysis/` (extend `championship_leaders.py` or add a new module in the same package) rather than embedding primary analysis logic inline in notebook cells.
* Keep both cutoffs visible: the existing Kaggle-only-cutoff answer (round 3, from the existing reports, unchanged) and the new combined-cutoff answer (the true current round), with any difference between them explained rather than one silently replacing the other.

## Open Decision To Resolve Before Execution

The combined tables require `raw_jolpica_results.driver_id`/`constructor_id` to line up with the Kaggle-derived `drivers`/`constructors` id conventions (Jolpica uses Ergast-style slug ids, e.g. `verstappen`; Kaggle's convention has not yet been row-level verified against it — only aggregate row counts have been compared via `kaggle_jolpica_coverage`). Before writing the combined tables, inspect a sample of `raw_jolpica_results.driver_id`/`constructor_id` against `drivers.driver_id`/`constructors.constructor_id` for season 2026, rounds 4-9:

* If ids match directly, proceed as planned.
* If ids do not match directly but a reliable name-based join is available (similar precedent: the existing `driver_standings` constructor-name reconciliation), propose the mapping in the implementation note and proceed.
* If neither holds cleanly, stop per the Stop Conditions below and report back rather than inventing an unverified id mapping.

## Files Expected To Change

* `requirements.txt` (add a notebook-execution dependency, e.g. `jupyter` plus whatever headless-execution package is used for validation, such as `nbconvert` or `papermill`)
* `docs/data_sources.md` (document the combined tables, their precedence rule, and scope)
* `docs/architecture.md`
* `docs/diagrams/project_structure.mmd` (add the new `notebooks/` directory and combined-table build step)
* `docs/questions.md` (note that this handoff delivers the first notebook)
* `docs/active_context.md`
* `docs/run_log.md`
* `docs/implementation_notes/016-combined-dataset-championship-leader-notebook.md`
* `src/f1_analytics/analysis/championship_leaders.py` or a new sibling module for combined-cutoff logic
* Possibly `src/f1_analytics/data_sources/kaggle_csv.py` only if `add_standing_rank`/cumulative logic needs to move to a shared location for reuse — do not otherwise change its existing behavior

## Files/Directories Expected To Be Created

* A new script, e.g. `scripts/build_combined_dataset.py`, that connects to the existing DuckDB file (must already contain both Kaggle curated tables and `raw_jolpica_*` tables — error clearly and stop if either is missing) and writes `combined_results`, `combined_driver_standings_by_round`, `combined_constructor_standings_by_round`.
* `notebooks/` directory with one notebook, e.g. `notebooks/championship_leader_combined_analysis.ipynb`.

## Files Expected To Be Generated (gitignored unless a later decision says otherwise)

* Combined DuckDB tables inside `data/processed/f1_analytics.duckdb`.
* Any new supporting CSVs the notebook writes under `outputs/tables/` (e.g. a combined current-season leaders table and a deviations table), following existing naming style.
* The executed notebook itself, if the project's `.gitignore` currently excludes generated notebook output — check and follow existing convention rather than assuming.

## Files That Should Not Change

* `AGENTS.md`
* `PROJECT.md`
* `docs/project_profile.md`
* `docs/terminal_protocol.md`
* `docs/terminal_roles/*`
* `docs/decisions.md` bodies of existing entries (status-line-only edits already applied by planning; execution must not further edit decision bodies)
* Existing approved/completed handoffs
* `scripts/build_f1_dataset.py`, `scripts/analyze_championship_leaders.py`, `scripts/pull_jolpica_data.py` behavior and existing output paths/content
* `outputs/reports/championship_leader_conversion.md`, `outputs/reports/championship_leader_followup.md` and their existing supporting CSVs

## Implementation Steps

1. Read `AGENTS.md`, `PROJECT.md`, `docs/active_context.md`, `docs/questions.md`, `docs/decisions.md` (both the new combined-dataset decision and the superseded Jolpica decision), `docs/data_sources.md`, `docs/analysis_output_standards.md`, and this handoff.
2. Confirm this handoff is `Status: Approved` and located under `docs/handoffs/approved/`. Stop otherwise.
3. Resolve the "Open Decision To Resolve Before Execution" above (id-convention check) before writing any combined table.
4. Rebuild the local DuckDB (`scripts/build_f1_dataset.py`) and refresh Jolpica (`scripts/pull_jolpica_data.py`) so both Kaggle curated tables and `raw_jolpica_*` tables are current.
5. Implement `combined_results`: union Kaggle `results` rows for every season/round with Jolpica `raw_jolpica_results` rows only for season/rounds where Kaggle has zero rows (per `kaggle_jolpica_coverage`); tag each row with its source (`kaggle` or `jolpica`).
6. Implement `combined_driver_standings_by_round` and `combined_constructor_standings_by_round` by recomputing cumulative points/wins/standing-rank over `combined_results`, reusing the existing cumulative-standings logic rather than re-deriving it.
7. Add a small helper (in `src/f1_analytics/analysis/`) that, given the combined tables, determines the true current-season cutoff round (max round present in `combined_driver_standings_by_round`/`combined_constructor_standings_by_round` for the target season) and the current leader(s) at that cutoff.
8. Add a helper that recomputes the historical driver/constructor conversion tables at the new combined cutoff round (same logic as `build_conversion_table`, parameterized by cutoff round) so the "how many times" answer is available at both the existing Kaggle-only cutoff (unchanged, for comparison) and the new combined cutoff.
9. Add a helper that extracts deviation rows from `kaggle_jolpica_coverage` for the current target season (any status other than `match`), for direct display in the notebook.
10. Create `notebooks/championship_leader_combined_analysis.ipynb`. It should, using only calls into the reusable functions above (no embedded primary logic):
    * State the two questions being answered.
    * Show the existing Kaggle-only-cutoff answer (round 3) for continuity.
    * Show the combined-cutoff answer (the true current round) as the up-to-date answer, and explicitly state whether it differs from the Kaggle-only answer and why.
    * Show current-season leader(s) (driver and constructor) at the combined cutoff.
    * Show the per-round deviation table between Kaggle and Jolpica for the current season, with plain-language notes on what `row_count_diverges`/`kaggle_only`/`jolpica_only`/`no_data` mean for this analysis.
    * State data sources, cutoff definitions, limitations, and follow-up directions, consistent with `docs/analysis_output_standards.md`.
11. Add `jupyter` and a headless-execution package (e.g. `nbconvert` or `papermill`) to `requirements.txt`.
12. Update `docs/data_sources.md`, `docs/architecture.md`, and `docs/diagrams/project_structure.mmd` to document the combined tables, the precedence rule, and the new `notebooks/` directory.
13. Update `docs/questions.md` to note the first notebook now exists and where.
14. Update `docs/active_context.md` with the new state and next action (command-terminal validation).
15. Write `docs/implementation_notes/016-combined-dataset-championship-leader-notebook.md` per `docs/analysis_output_standards.md`, including the id-convention check result and any deviations found for the current season.
16. Append validation commands to `docs/run_log.md`.

## Validation Commands

```bash
pwd
source .venv/bin/activate
pip install -r requirements.txt
python scripts/build_f1_dataset.py
python scripts/pull_jolpica_data.py
python scripts/build_combined_dataset.py
jupyter nbconvert --to notebook --execute --inplace notebooks/championship_leader_combined_analysis.ipynb
python - <<'PY'
import duckdb
conn = duckdb.connect("data/processed/f1_analytics.duckdb", read_only=True)
for table in ["combined_results", "combined_driver_standings_by_round", "combined_constructor_standings_by_round"]:
    print(table, conn.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0])
print(conn.execute("SELECT * FROM kaggle_jolpica_coverage WHERE season = (SELECT MAX(season) FROM combined_results) AND results_coverage_status != 'match' ORDER BY round").fetchdf())
PY
git status --short
```

## Expected Outputs

* `combined_results`, `combined_driver_standings_by_round`, `combined_constructor_standings_by_round` exist in the DuckDB file with row counts consistent with Kaggle rounds 1-3 plus Jolpica-filled rounds 4-9 (or whatever the live gap is at execution time).
* `notebooks/championship_leader_combined_analysis.ipynb` executes end-to-end headlessly and states both cutoff answers plus documented deviations.
* Existing reports/scripts are byte-for-byte unaffected.
* Implementation note and run log entries recorded.

## Stop Conditions

Stop if:

* This handoff is still in `docs/handoffs/drafts/` or still `Status: Draft`.
* `raw_jolpica_*` tables are missing or stale relative to `results` (Jolpica must actually extend past Kaggle's cutoff for this handoff to have a purpose — if Kaggle has since caught up and both sources now `match` for all rounds, report that back instead of proceeding, since the combined tables would be a no-op).
* The Jolpica/Kaggle `driver_id`/`constructor_id` convention check in "Open Decision To Resolve Before Execution" fails without a reliable, low-risk mapping.
* Executing the combined-cutoff logic would change any existing Kaggle-only report's output — that would mean the "additive only" assumption was violated; stop and report rather than accepting the change.
* The notebook cannot be executed headlessly from the command line (isolated/manual-only notebooks are out of scope per `PROJECT.md`).

## What To Report Back

Report:

* Files changed/created.
* The id-convention check result (matched directly, mapped, or blocked).
* The detected combined-cutoff round vs. the existing Kaggle-only cutoff round, and whether the "how many times" answers differ between them.
* Any deviation rows found (`row_count_diverges`, etc.) for the current season.
* Generated notebook and output paths.
* Exact validation commands for the command terminal.
