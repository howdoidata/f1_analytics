# Handoff 010: Workflow Enablement and Status Router

Status: Completed

## Goal

Give the project a repo-native answer to "which terminal do I use," "can I just edit this handoff," and "what do I do now" -- a decision-tree doc plus a small read-only status script -- and clean up the concrete drift that produced those questions: a stale bare-`python` reference left in three files from Handoff 009, a duplicated/stale `execution_prompt.txt`, and handoffs 004-008 still marked `Approved` despite being executed.

## Success Criteria

* `docs/workflow_guide.md` exists with an intent-based decision tree covering: architecture/project questions, analysis/feature questions, approved-implementation work, commands/validation, "can I edit this handoff," and "what do I do now."
* `scripts/workflow.py` exists, is read-only (no edits, no subprocess calls to other scripts), imports and reuses `scripts/fitness_check.py`'s existing `check_*` functions rather than duplicating them, and reports: fitness check summary, Current Focus/Next Action from `docs/active_context.md`, draft handoffs awaiting review, approved-but-not-completed handoffs, and the latest implementation note. It also supports `--intent {architecture,analysis,execution,command,revise}`.
* `docs/prompts/execution_prompt.txt` contains exactly one `<HANDOFF_FILENAME>`-style template (not two concatenated handoff-specific blocks), with a fill-in legend matching the pattern already used in `docs/prompts/command_prompt.txt`.
* No file outside `docs/run_log.md` and `docs/decisions.md` still contains a bare `python scripts/fitness_check.py` reference (those two files are historical evidence and must not be rewritten).
* All three prompt templates (planning, execution, command) link to `docs/workflow_guide.md`.
* Handoffs 003-008 show `Status: Completed`.
* `scripts/fitness_check.py` gains a 6th check: a handoff with a matching `docs/implementation_notes/<same-id>-*.md` file must not be `Status: Approved`.
* `python3 scripts/fitness_check.py` reports `6 run, 0 failed` after all changes.
* No analytics code, data models, reports, dashboards, automated handoff approval, or git commit is introduced by this handoff.

## Files Expected To Change

* `docs/workflow_guide.md` (new)
* `scripts/workflow.py` (new)
* `docs/prompts/execution_prompt.txt`
* `docs/prompts/command_prompt.txt`
* `docs/prompts/planning/session_prompt.txt`
* `docs/terminal_protocol.md`
* `docs/active_context.md`
* `scripts/fitness_check.py`
* `docs/handoffs/approved/003-add-draft-approval.md` through `008-analysis-communication-and-comeback-factors.md` (Status line only)
* `docs/decisions.md`, `docs/questions.md`, `docs/run_log.md`
* `docs/implementation_notes/010-workflow-enablement-and-status-router.md` (new)

## Files That Should Not Change

* `docs/run_log.md` and `docs/decisions.md` entries that already exist (append new entries; do not rewrite existing ones -- they are historical evidence, including the record of the bare-`python` failure).
* Anything under `src/f1_analytics/`, `sql/`, `outputs/`, `data/`, or existing analysis scripts.
* Handoffs 001, 002, 009 (already `Completed`; out of scope here).

## Relevant Project Context

Handoff 009 established the standing fitness check, the ADR supersede convention, and the revise-vs-supersede procedure for handoffs, plus `scripts/fitness_check.py`. Running that workflow externally surfaced: `python` is not on PATH in the actual environment (only `python3`), which is now a recorded decision but wasn't yet propagated to every file that referenced the old command; `docs/prompts/execution_prompt.txt` predates the placeholder-legend cleanup done for `command_prompt.txt` and still has two hardcoded, concatenated handoff blocks; and handoffs 004-008 were never flipped from `Approved` to `Completed` even though they were executed, which is exactly the kind of status/reality drift the fitness check is meant to catch but doesn't yet check for.

## Decisions Already Made

* Use `python3`, not `python`, in all live repository documentation and prompt instructions (`docs/decisions.md`, 2026-07-08 -- "Use python3 for repository commands").
* Treat the setup-comparison check as a standing, mechanically-verified fitness function (`docs/decisions.md`, Handoff 009 decisions).
* Use the ADR supersede convention and the binary revise-vs-supersede fork for handoffs (`docs/decisions.md`, Handoff 009 decisions) -- this handoff's own status changes to 003-008 follow that same "update only the Status line" rule.
* A richer TUI or web interface is not warranted yet; a read-only CLI plus one guide is the right scope until repeated use shows people still bypass the lifecycle or can't find the next action.

## Assumptions Not To Revisit

* The three-terminal model and the draft/approved handoff folder split are not being replaced.
* `scripts/workflow.py` is read-only: it must not move files, edit Status lines, or write anything -- it only reports.
* Establishing the repo's first git commit is explicitly out of scope for this handoff.

## Implementation Steps

1. Add `docs/workflow_guide.md` with the intent-based decision tree described in Success Criteria, pointing at the existing role prompts and at the revise-vs-supersede procedure in `docs/terminal_protocol.md` rather than restating it.
2. Add `scripts/workflow.py`. Import the `check_*` functions and `CheckResult` from `fitness_check.py` (same directory) rather than reimplementing them. Parse `docs/active_context.md` for the Current Focus / Next Action sections, list `docs/handoffs/drafts/*.md` and `docs/handoffs/approved/*.md` by Status, and find the highest-numbered file in `docs/implementation_notes/`. Add the `--intent` flag with a short literal mapping mirroring the workflow guide.
3. Rewrite `docs/prompts/execution_prompt.txt` to a single `<HANDOFF_FILENAME>` template plus fill-in legend, following the exact structure already in `docs/prompts/command_prompt.txt`.
4. Replace bare `python scripts/fitness_check.py` with `python3 scripts/fitness_check.py` in `docs/terminal_protocol.md`, `docs/prompts/command_prompt.txt`, `docs/prompts/planning/session_prompt.txt`, and `docs/active_context.md`. Do not touch the historical mentions in `docs/run_log.md` or `docs/decisions.md`.
5. Add one line to each of the three prompt templates pointing at `docs/workflow_guide.md`.
6. Update `Status: Approved` to `Status: Completed` on handoffs 003-008 (each already has `docs/run_log.md` evidence of execution; 004-008 also have implementation notes).
7. Add a 6th check function to `scripts/fitness_check.py` (e.g. `check_completed_handoffs_not_approved`) that flags any handoff whose ID has a matching file in `docs/implementation_notes/` but whose Status is still `Approved`. Wire it into `main()`.
8. Add a new dated decision entry to `docs/decisions.md` for adopting the workflow guide and status router (do not edit prior entries beyond what Handoff 009 already added).
9. Mark the "Enablement" question answered in `docs/questions.md`.
10. Update `docs/active_context.md` (Current Focus, Next Action, Current Decisions, Current Repo State) and append a new entry to `docs/run_log.md` for this handoff's commands and results.
11. Write `docs/implementation_notes/010-workflow-enablement-and-status-router.md` following the standard format in `docs/implementation_notes/README.md`.

## Validation Commands

```bash
pwd
python3 scripts/fitness_check.py
python3 scripts/workflow.py
python3 scripts/workflow.py --intent architecture
grep -rn "python scripts/fitness_check.py" docs/terminal_protocol.md docs/prompts docs/active_context.md
grep -c "EXECUTION TERMINAL" docs/prompts/execution_prompt.txt
grep -n "^Status" docs/handoffs/approved/*.md
git status --short
```

## Expected Outputs

* `Fitness checks: 6 run, 0 failed`.
* `scripts/workflow.py` prints a status summary without error and without modifying any file (`git status --short` unchanged by running it).
* The `grep` for bare `python scripts/fitness_check.py` outside `run_log.md`/`decisions.md` returns nothing.
* `grep -c "EXECUTION TERMINAL" docs/prompts/execution_prompt.txt` returns `1`.
* Handoffs 003-008 show `Status: Completed`; 001, 002, 009 unchanged.

## Stop Conditions

Stop if `scripts/workflow.py` cannot be written without duplicating `fitness_check.py`'s check logic, if any of handoffs 004-008 lack the run_log/implementation-note evidence this handoff assumes, or if implementing this would require touching analytics code, data models, reports, dashboards, or creating the first git commit.

## What To Report Back

Files changed, `scripts/fitness_check.py` output before and after (expect `5 run, 0 failed` before this handoff's own check is added, `6 run, 0 failed` after), `scripts/workflow.py` sample output, and confirmation that no analytics code, data files, or git commit were touched.
