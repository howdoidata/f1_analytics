# Handoff 015: Generalize Architecture Principles Away From Named Sources

Status: Completed

## Goal

Remove Kaggle/Jolpica/Ergast source names from `docs/architecture_principles.md` so that architecture-level principles stay reusable and source-agnostic, while the concrete Kaggle/Jolpica source-treatment rule remains fully intact in `docs/decisions.md` and `docs/data_sources.md`. Record the underlying policy (principles documents stay name-generic; source/tool-specific treatment lives only in decisions and topic docs) as a new decision, and add a short clarifying note to `docs/architecture_operating_model.md` so this does not recur with the next data source.

## Success Criteria

* `docs/architecture_principles.md` contains no occurrences of `Kaggle`, `Jolpica`, or `Ergast`.
* The rationale/practical-implication text for "Keep Source Boundaries Explicit" and "Do Not Merge Sources Without Precedence Rules" still conveys the same architectural point (sources can differ in freshness/shape/provenance; do not merge without documented precedence) using generic language only.
* `docs/decisions.md` gets one new dated entry recording the policy: architecture-principles documents must remain tool/source-name-generic; concrete source, tool, or vendor treatment belongs in `docs/decisions.md` and topic-specific docs (e.g. `docs/data_sources.md`) only. Include `Decision:`, `Rationale:`, `Tradeoffs:`, `Status: Accepted`.
* `docs/architecture_operating_model.md` gets a short new section (or addition to an existing section) distinguishing architecture-level principles (reusable, name-agnostic, revised rarely) from project-specific source/tool decisions (concrete, decision-record territory, revised whenever sources or tools change).
* No content is removed from `docs/decisions.md`'s existing Kaggle/Jolpica decision pair (2026-07-08 entries) or `docs/data_sources.md`; both remain the authoritative concrete record.
* `docs/active_context.md` reflects the reworded principles doc and the new decision.
* `python3 scripts/fitness_check.py` reports `Fitness checks: 13 run, 0 failed` after all changes.
* No analytics code, data models, generated reports, dashboards, analytical datasets, or git commit is introduced by this handoff.

## Files Expected To Change

* `docs/architecture_principles.md`
* `docs/architecture_operating_model.md`
* `docs/decisions.md`
* `docs/active_context.md`
* `docs/run_log.md` (append/prepend only; do not rewrite prior entries)
* `docs/implementation_notes/015-generalize-architecture-principles.md` (new)

## Files That Should Not Change

* Anything under `src/f1_analytics/`.
* Anything under `sql/`.
* Anything under `data/`.
* Anything under `outputs/`.
* `docs/data_sources.md` (concrete source rules stay here, untouched).
* `docs/asset_inventory.md` (asset rows legitimately name Kaggle/Jolpica as data assets; not in scope).
* `PROJECT.md`, `docs/project_profile.md`, `docs/questions.md`, `docs/backlog.md` (legitimately project-specific; not in scope).
* `docs/handoffs/approved/014-add-architecture-governance-docs.md` (frozen ADR-style record; body must not be rewritten).
* Existing Kaggle/Jolpica decision entries in `docs/decisions.md` dated 2026-07-08 (frozen bodies; add a new entry, do not edit these).
* `scripts/fitness_check.py`, `scripts/workflow.py`.
* Existing handoffs 001-014.

## Relevant Project Context

`docs/architecture_principles.md` was created by handoff 014 to hold short, project-specific, reusable architecture principles. Two of its principles ("Keep Source Boundaries Explicit" and "Do Not Merge Sources Without Precedence Rules") were written using language that names Kaggle and Jolpica/Ergast directly, mirroring the concrete Kaggle/Jolpica decision pair already recorded in `docs/decisions.md`.

This created recurring confusion: a document meant to state a durable, reusable architecture rule reads instead as if it is specifically about Kaggle/Jolpica, rather than a generic rule that Kaggle/Jolpica happens to currently illustrate. A repo-wide check confirmed this is the only place in the standing fitness-check document list where source names leak into a principles-level document; `docs/decisions.md`, `docs/questions.md`, `docs/backlog.md`, `docs/data_sources.md`, `docs/asset_inventory.md`, `docs/active_context.md`, `PROJECT.md`, and `docs/project_profile.md` all name Kaggle/Jolpica appropriately because they exist specifically to record which source is used and why.

Handoff 014 is the origin of this coupling, not a fix for it — nothing in 014 established a rule that principles documents must stay source-name-generic. Handoff 014's body is `Status: Completed` and frozen per the ADR supersede convention in `docs/terminal_protocol.md`; it is not edited by this handoff.

## Decisions Already Made

* Use repo Markdown as durable project memory.
* Use the ADR supersede convention for decisions and handoffs; frozen record bodies are never rewritten.
* Kaggle CSV is the Version 1 baseline source for curated tables; Jolpica/Ergast is a fully loaded, separate, comparison-only source, never merged into Kaggle curated tables (see `docs/decisions.md`, 2026-07-08 entries, and `docs/data_sources.md`). This handoff does not change that source treatment in any way — it only relocates where the *generic architectural principle* is phrased.
* Architecture governance documentation (`docs/asset_inventory.md`, `docs/architecture_operating_model.md`, `docs/architecture_principles.md`) was adopted 2026-07-09 per handoff 014.

## Assumptions Not To Revisit

* The three-terminal model remains in place.
* This handoff does not change Kaggle/Jolpica source treatment, precedence, or the `kaggle_jolpica_coverage` view — only where the generic principle is worded.
* `docs/architecture_principles.md` is not an ADR-frozen record; its prose may be edited directly, unlike `docs/decisions.md` entries and handoff bodies.
* This handoff does not add a new fitness-check rule to detect source names in principles docs; if repeated recurrence justifies automation later, that is a backlog item, not part of this handoff's scope.
* No git commit is introduced by this handoff.

## Implementation Steps

1. Edit `docs/architecture_principles.md`.
   * In "Keep Source Boundaries Explicit", replace the Kaggle/Jolpica-specific Rationale line with a generic statement, e.g.: "Different sources may have different freshness, shape, and provenance characteristics."
   * In "Do Not Merge Sources Without Precedence Rules", replace the Jolpica-specific Practical Implication line with a generic statement, e.g.: "A newly added source stays comparison-only, separate from curated tables, until a decision explicitly defines precedence and merge rules."
   * Do not change any other principle in the file.
2. Add a new dated decision entry to `docs/decisions.md` (top of file, matching existing entry format) recording: architecture-principles documents must stay tool/source-name-generic; concrete source, tool, or vendor treatment belongs solely in `docs/decisions.md` and topic-specific docs such as `docs/data_sources.md`. Include `Decision:`, `Rationale:` (reference that this was found while trying to reproduce/extend the project and the principles doc read as if it were specifically about Kaggle/Jolpica), `Tradeoffs:`, `Status: Accepted`. Do not edit or supersede the existing 2026-07-08 Kaggle/Jolpica decision entries; this is a new, orthogonal process decision.
3. Add a short section to `docs/architecture_operating_model.md` distinguishing:
   * Architecture-level principles (`docs/architecture_principles.md`): reusable, source/tool-name-generic, revised rarely.
   * Project-specific source/tool decisions (`docs/decisions.md`, `docs/data_sources.md`): concrete, name specific vendors/sources/tools, revised whenever sources or tools change.
   * State plainly that a principle needing a specific source or tool name to make sense is a sign the content belongs in a decision or topic doc instead.
4. Update `docs/active_context.md` to reflect the reworded principles doc and the new decision (Current Decisions and/or Current Repo State, following existing style).
5. Run validation commands listed below.
6. Add a human-readable run-log entry for this handoff's implementation and validation results.
7. Write `docs/implementation_notes/015-generalize-architecture-principles.md` using the standard format in `docs/implementation_notes/README.md`.

## Validation Commands

```bash
pwd
python3 scripts/fitness_check.py
grep -niE "kaggle|jolpica|ergast" docs/architecture_principles.md
grep -n "Decision:" docs/decisions.md
sed -n '1,40p' docs/architecture_principles.md
grep -n "architecture-level principles\|principles document\|source-name-generic" docs/architecture_operating_model.md
git status --short
```

## Expected Outputs

* `python3 scripts/fitness_check.py` prints `Fitness checks: 13 run, 0 failed`.
* The `grep -niE "kaggle|jolpica|ergast" docs/architecture_principles.md` command returns no matches.
* `docs/decisions.md` has one new dated entry with `Status: Accepted` documenting the generic-principles policy.
* `docs/architecture_operating_model.md` clearly distinguishes architecture-level principles from project-specific source/tool decisions.
* `docs/active_context.md` reflects the change.
* `git status --short` shows only the expected files plus any pre-existing local untracked state.

## Stop Conditions

Stop if generalizing the two principle lines would require changing the substance of the Kaggle/Jolpica source-treatment rule itself (precedence, merge behavior, comparison-only status) — that rule must remain exactly as already decided in `docs/decisions.md` and `docs/data_sources.md`; only the principles-doc wording changes.

Stop if adding the new decision entry would require editing or superseding the existing 2026-07-08 Kaggle/Jolpica decision entries — it should not; it is a new, orthogonal entry about how principles documents are worded.

Stop if validation fails for reasons unrelated to this handoff and report the blocker.

## What To Report Back

Report:

* exact wording used for the two reworded principle lines.
* the new decision entry added to `docs/decisions.md`.
* the new section/text added to `docs/architecture_operating_model.md`.
* confirmation that `docs/decisions.md`'s existing Kaggle/Jolpica entries and `docs/data_sources.md` were left untouched.
* `python3 scripts/fitness_check.py` result.
* any issues or deviations.
