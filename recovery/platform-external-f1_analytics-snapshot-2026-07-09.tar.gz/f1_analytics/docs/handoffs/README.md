# Handoffs

This directory stores handoffs from the planning terminal.

Handoff required fields are defined in `docs/terminal_protocol.md` under `## Handoff Requirements`.

## Locations

* `docs/handoffs/drafts/`: Proposed handoffs waiting for user review, approval, or edits.
* `docs/handoffs/approved/`: Execution-ready handoffs approved by the user.

The execution terminal must only implement handoffs from `docs/handoffs/approved/`.

## Status

Every handoff must include a `Status:` line near the top.

Valid statuses:

* `Draft`
* `Needs Revision`
* `Approved`
* `Completed`
* `Rejected`
* `Superseded`

A handoff whose content is materially replaced by a later one should have its Status updated to `Superseded` plus a `Superseded by: <filename>` line (body left as originally written); the newer handoff includes a matching `Supersedes: <filename>` line. If you have a question about, or need a small change to, an approved-but-not-yet-executed handoff, see the "Revising vs. superseding a handoff" procedure in `docs/terminal_protocol.md` — it resolves the choice with one question: has any part of it already been executed?
