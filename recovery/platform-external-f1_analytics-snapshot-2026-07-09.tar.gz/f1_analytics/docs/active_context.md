# Active Context

## Project

F1 Analytics project located at:

`/Users/antonio/Documents/howdoidata/projects/f1_analytics`

## Current Repo State

The repo currently contains the initial project documentation scaffold:

* `AGENTS.md`
* `PROJECT.md`
* `docs/active_context.md`
* `docs/backlog.md`
* `docs/decisions.md`
* `docs/project_profile.md`
* `docs/questions.md`
* `docs/local_setup.md`
* `docs/run_log.md`
* `docs/terminal_protocol.md`
* `docs/asset_inventory.md`
* `docs/architecture_operating_model.md`
* `docs/architecture_principles.md`
* `docs/terminal_roles/`
* `docs/prompts/`
* `docs/handoffs/`
* `docs/handoffs/drafts/`
* `docs/handoffs/approved/`
* `docs/implementation_notes/`
* `requirements.txt`
* `scripts/download_kagglehub_f1_data.py`
* `scripts/build_f1_dataset.py`
* `scripts/analyze_championship_leaders.py`
* `scripts/pull_jolpica_data.py`
* `scripts/fitness_check.py`
* `scripts/workflow.py`
* `docs/workflow_guide.md`
* `docs/inbox/`
* `src/f1_analytics/`
* `src/f1_analytics/validation/`
* `sql/`
* `sql/analysis/kaggle_jolpica_coverage.sql`
* `docs/data_sources.md`
* `docs/architecture.md`
* `docs/diagrams/project_structure.mmd`
* `notebooks/championship_leader_combined_analysis.ipynb`

Git has been initialized for the project directory.

The repo now has minimal KaggleHub dataset access setup, reusable Python modules, SQL folders, source documentation, architecture documentation, lightweight architecture-governance docs, scripts to build the first DuckDB dataset and championship-leader analysis, a mechanically-enforced Revision Note requirement for any handoff in `Status: Needs Revision`, and role/protocol fitness checks that enforce canonical process-fact locations.

Jolpica/Ergast is now a fully loaded, separate current-season source (`raw_jolpica_*` tables via `src/f1_analytics/data_sources/jolpica_loader.py` and `scripts/pull_jolpica_data.py`), never merged into Kaggle curated tables except through the new scoped combined dataset below. A `kaggle_jolpica_coverage` DuckDB view (`sql/analysis/kaggle_jolpica_coverage.sql`) compares the two sources per season/round. Kaggle now also loads `f1_circuits.csv` and `f1_qualifying.csv`, and basic null-rate/referential-integrity validation checks run on every Kaggle build (`src/f1_analytics/validation/checks.py`), logged to `validation_results`. `final_driver_standings` now includes a reconciled `constructor_id`.

The championship-leader analysis now also writes a follow-up report on constructor comeback cases and candidate recovery features while preserving the original Kaggle-baseline cutoff report.

A scoped, precedence-ruled combined Kaggle+Jolpica dataset (`combined_results`, `combined_driver_standings_by_round`, `combined_constructor_standings_by_round`) now exists for current-season leader identification only, built by `src/f1_analytics/data_sources/combined_dataset.py` via `scripts/build_combined_dataset.py` (Handoff 016). Kaggle wins on any season/round overlap; Jolpica fills a season/round only where Kaggle has zero rows; historical (pre-current-season) rows are unchanged. The shared cumulative-points/wins/standing-rank logic previously inline in `kaggle_csv.py` now lives in `src/f1_analytics/data_sources/standings.py` and is reused by both the Kaggle-only and combined builders. `src/f1_analytics/analysis/combined_championship_leaders.py` adds the combined-cutoff detection, current-leader, conversion-table, and current-season-deviation helpers. The first notebook, `notebooks/championship_leader_combined_analysis.ipynb`, calls only these reusable functions to answer the drivers'/constructors' leader-conversion questions at both the existing Kaggle-only cutoff (round 3) and the new combined cutoff (round 9 as of this session), and executes headlessly via `jupyter nbconvert --execute --inplace`.

No dashboard, dbt, Airflow, or ML scaffold exists yet.

## Current Focus

Handoffs 011 (consolidate terminal-role and handoff-schema duplication), 012 (formalize the draft-revision evaluation stage), 013 (fix command-terminal handback ambiguity and introduce external-input intake), 014 (add architecture governance documents), 015 (generalize architecture principles away from named sources), and 016 (combined-dataset championship-leader notebook) are complete. Command-terminal validation of Handoff 016 is the immediate next step. Command-terminal validation and review of the championship-leader follow-up report from Handoff 008 remains a separate, still-open thread.

A new, separate thread: the 2026-07-09 inbox item ("Project-agnostic platform scope") went through two direction changes that day. First scoped as a phased in-place migration (six draft handoffs, 017-022), which the user withdrew before approval, restating the constraints: no reliance on this repository's history/context, strict ordered build rules, one handoff another system can strictly adhere to. That produced a single seven-phase (0-6) self-contained bootstrap specification. The user then asked to work on only the first phase so basic adherence can be verified before more is drafted, and clarified that "no history" must not mean blank/placeholder content — the specification must templatize the real architectural rationale this project already learned, just without inheriting the historical log entries themselves. That is recorded as the 2026-07-09 decision "Deliver the bootstrap specification as an incremental, phase-scoped handoff sequence starting with repository scaffold only" (superseding the all-phases-in-one-handoff decision). Phases 0-3 (`017`-`020`, all `Status: Approved`) have since been executed against the external `TARGET_DIR` (`/Users/antonio/Documents/howdoidata/projects/platform`): repository scaffold, the nine platform governance documents, the terminal-workflow layer (role contracts, protocol, workflow guide, handoff lifecycle folders, implementation-notes and inbox conventions, three session prompts, `active_context.md`), and the mechanical `scripts/fitness_check.py`/`scripts/workflow.py` pair. This was verified directly against `TARGET_DIR` on 2026-07-10: `python3 scripts/fitness_check.py` there passes 10/10 (`[PASS]` on every check), and `docs/terminal_protocol.md`'s `## Source Of Truth` list now explicitly covers `docs/handoffs/` and `docs/inbox/`. That last point was a real Phase 3 finding — the list was gapped in Phase 0-2's output and got corrected in place during execution rather than stopped-and-reported as Handoff 020's own stop conditions require — captured in the 2026-07-10 decision "Accept Phase 3's Source-Of-Truth correction; require stop-and-report, not in-place repair, for future phase-boundary fitness findings" (`docs/decisions.md`), which accepts the (verified-correct) outcome while reaffirming the stop-and-report rule for Phase 4 onward. `docs/handoffs/drafts/021-platform-bootstrap-phase4-multi-project-layer.md` is now drafted — Phase 4 (`projects/`, `exchange/`, and a stdlib-only `scripts/new_project.py` template/generator) — awaiting user review and approval. Phases 5-6 (synthetic-project verification, F1-onboarding verification with the combined-analysis notebook as the headless goal artifact) remain intentionally not drafted; each becomes its own handoff only after the previous phase is reviewed and, if approved, executed. This repository is not modified by any platform-bootstrap phase and remains read-only (it will later serve as Phase 6's source bundle). `docs/decisions.md`, `docs/questions.md`, and `docs/backlog.md` reflect this scope.

Generated local outputs, ignored by Git:

* `data/processed/f1_analytics.duckdb`
* `data/raw/jolpica/` (cached Jolpica JSON responses)
* `outputs/reports/championship_leader_conversion.md`
* `outputs/reports/championship_leader_followup.md`
* `outputs/tables/driver_leader_conversion.csv`
* `outputs/tables/constructor_leader_conversion.csv`
* `outputs/tables/current_season_leaders.csv`
* `outputs/tables/data_coverage_summary.csv`
* `outputs/tables/constructor_comeback_cases.csv`
* `outputs/tables/recovery_feature_candidates.csv`
* `outputs/figures/constructor_comeback_cases.html`

`notebooks/championship_leader_combined_analysis.ipynb` is committed with its executed cell outputs, following the existing convention that source/deliverable files (unlike `data/`, `outputs/`) are tracked in Git; `.gitignore` was not changed for it.

## Current Operating Model

The project uses three terminals:

1. Planning terminal for architecture, decisions, and draft handoffs.
2. Execution terminal for file edits and approved handoff implementation.
3. Command terminal for commands, installs, tests, and validation.

The repo is the source of truth. Chat history is not the source of truth.

Draft handoffs live in `docs/handoffs/drafts/`. Approved execution-ready handoffs live in `docs/handoffs/approved/`. The execution terminal must not run draft handoffs.

## Current Approved Documents

Required setup documents are now maintained as a single canonical, mechanically-checked list in `docs/terminal_protocol.md` ("Source of Truth / Standing Fitness Check"). Run `python3 scripts/fitness_check.py` to verify the repo matches it instead of re-reading the list here. Use `docs/workflow_guide.md` or `python3 scripts/workflow.py` to select a terminal and inspect current workflow status.

## Current Decisions

* Keep the workflow simple.
* Use durable Markdown documents for project memory.
* Separate planning, execution, and validation across three terminals.
* Use draft and approved handoff folders to separate proposed instructions from execution-ready work.
* Treat the recurring setup-comparison check as a standing fitness function (`docs/terminal_protocol.md`), validated mechanically by `scripts/fitness_check.py` rather than a duplicated prompt checklist.
* Use the standard ADR supersede convention (`Supersedes`/`Superseded by`, frozen record bodies) for both `docs/decisions.md` and handoffs.
* Use a binary revise-vs-supersede fork for handoffs: revise in place (`Status: Needs Revision`, back to `docs/handoffs/drafts/`) if nothing has executed yet; otherwise write a new handoff that supersedes the old one.
* Require a dated `## Revision Note` section on any handoff in `Status: Needs Revision`, including drafts that never left `docs/handoffs/drafts/`, and enforce that structurally inside `check_handoff_statuses()`.
* Use `docs/workflow_guide.md` and the read-only `scripts/workflow.py` status router for intent-based terminal selection and current workflow status.
* Keep duplicated process facts canonical by topic and enforce the pointers structurally with `scripts/fitness_check.py` and `scripts/workflow.py`.
* Command-terminal validation results must be recorded in `docs/run_log.md`; `python3 scripts/fitness_check.py` records itself automatically.
* Use `docs/inbox/` as supplemental intake for external files, corrections, specs, questions, and reference material that need planning or execution triage.
* Use `docs/asset_inventory.md`, `docs/architecture_operating_model.md`, and `docs/architecture_principles.md` as the lightweight architecture governance layer.
* Keep `docs/architecture_principles.md` source/tool-name-generic; concrete source, tool, or vendor treatment belongs only in `docs/decisions.md` and topic-specific docs such as `docs/data_sources.md`.
* Use KaggleHub Option 3 authentication with `/Users/antonio/.kaggle/access_token`.
* Downloaded raw data should not be committed.
* The first analysis uses the latest completed round in local `f1_results.csv` as the current-season cutoff.
* Kaggle CSV is the baseline source for curated tables; Jolpica/Ergast is a fully loaded, separate current-season source used for coverage comparison and, within the scoped combined dataset only, current-season gap-fill (2026-07-09 decision, `docs/decisions.md`).
* Shared Python lives under `src/f1_analytics/`; reusable SQL lives under `sql/`.
* `f1_circuits.csv` and `f1_qualifying.csv` are loaded as raw and curated Kaggle tables.
* `final_driver_standings.constructor_id` is reconciled from constructor name via `results`/`constructor_standings` id-name pairs.
* Kaggle curated tables get null-rate and referential-integrity validation on every build, logged to `validation_results`.
* Analysis implementation notes and generated reports should follow `docs/analysis_output_standards.md`.
* The combined Kaggle+Jolpica dataset (`combined_results` and its standings tables) is scoped to current-season leader identification only, is additive, and reuses `kaggle_jolpica_coverage` for deviations instead of a second coverage view (`docs/data_sources.md`).

## Open Questions

Current open questions are tracked in `docs/questions.md`.

## Next Action

Run `python3 scripts/workflow.py` when the next terminal or task is unclear. Check `docs/inbox/` before planning work, and use the architecture governance docs for architecture scope, asset, and operating-model questions.

The immediate next action is command-terminal validation of Handoff 016 (see `docs/implementation_notes/016-combined-dataset-championship-leader-notebook.md` for the exact commands). Command-terminal validation of the existing Handoff 008 follow-up report remains a separate, still-open thread.

On the platform-separation thread: Phase 4 (`docs/handoffs/approved/021-platform-bootstrap-phase4-multi-project-layer.md`, `Status: Completed`) executed successfully against `TARGET_DIR` on the second attempt, after a revision cycle fixed a `.DS_Store` fileset-comparison gap and a handoff-delivery/precondition conflict (see the handoff's Revision Note and Completion Note, both 2026-07-10). Directly verified against `TARGET_DIR` = `/Users/antonio/Documents/howdoidata/projects/platform`: `projects/README.md`, `exchange/README.md`, and `scripts/new_project.py` exist; `.gitignore` excludes `exchange/*` except its `README.md`; `docs/multi_project_operating_model.md` and `PROJECT.md` are edited exactly as specified; `scripts/fitness_check.py`/`scripts/workflow.py` are byte-unchanged and pass 10/10; `projects/` contains no project directory (the `smoke_test_project` create/collide/cleanup sequence left no trace). Phases 0-4 (`017`-`021`) are now all `Status: Completed` or `Approved`→verified against `TARGET_DIR`.

Phase 5 (Verification A) is complete, but it ran natively: the inbox-item test (routed through `TARGET_DIR/docs/inbox/`, not this repository's) resulted in `TARGET_DIR`'s own planning/execution terminals drafting and executing their own `docs/handoffs/approved/022-platform-bootstrap-phase5-verification-a.md`, entirely inside `TARGET_DIR`, with no handoff drafted in this repository. This is the strongest evidence yet that Phase 4 succeeded — the platform can now plan and execute its own work without this repository's involvement. Directly verified against `TARGET_DIR`: `projects/verification_project/` is kept (not cleaned up, unlike Phase 4's smoke test), with a real project-scoped task (`tools/build_summary.py` reading `data/input/numbers.txt`, writing `outputs/summary.txt`), its own project-local `docs/handoffs/{README.md,approved/001-synthetic-summary-task.md}` and `docs/implementation_notes/`, a real decision entry (`### 2026-07-10 Tiny Integer Fixture And Text Summary`) written under `## Log` in the *project-level* `docs/decisions.md` (the root platform-level `docs/decisions.md` is still an empty log — the convention was exercised at the project level, which the inbox item's ask explicitly allowed), and `exchange/` used for real staging and left clean afterward. Root `python3 scripts/fitness_check.py`/`scripts/workflow.py` still pass 10/10 with a non-empty `projects/` present, unmodified.

Two findings from Phase 5, not yet acted on: (a) `TARGET_DIR/PROJECT.md`'s `## Projects` section is stale — it still says projects are "listed here after onboarding is introduced in a later phase" even though `verification_project` now exists and is deliberately kept; (b) a third occurrence of the fix-vs-stop-and-report pattern (see the 2026-07-10 decision from Phase 3) — Handoff 022's own Gate 5 text apparently contained the literal placeholder strings its own placeholder-scan checked for, a self-referential paradox, and the executing session rewrote that wording directly in the already-approved handoff file rather than stopping and reporting it for a revision cycle (per its implementation note's "Deviation" section). Outcome is verified correct in both cases; the pattern itself is what needs a decision before Phase 6.

Next: Phase 6 (Verification B — onboarding this repository's own F1 workflow, combined-analysis notebook headless, as an external project through the generic onboarding procedure) is the last phase in the original 0-6 roadmap and has not been drafted. Given Phase 5's precedent, Phase 6 may also be best requested via `TARGET_DIR`'s own inbox rather than as a handoff drafted in this repository — this repository's role is likely just supplying the F1 source-bundle spec Phase 6 onboards, not authoring the execution instructions itself.
